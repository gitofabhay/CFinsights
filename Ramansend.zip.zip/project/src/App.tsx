import React, { useState, useEffect } from 'react';
import { Moon, Sun, UserPlus } from 'lucide-react';
import { UserInput } from './components/UserInput';
import { UserProfile } from './components/UserProfile';
import { ComparisonView } from './components/ComparisonView';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ErrorMessage } from './components/ErrorMessage';
import { Footer } from './components/Footer';
import { UpcomingContests } from './components/UpcomingContests';
import { AlphaInfoModal } from './components/AlphaInfoModal';
import { getUserInfo, getUserRating, getUserSubmissions, getUserBlogEntries, CodeforcesApiError } from './services/codeforcesApi';
import { User, RatingChange, Submission, BlogEntry } from './types/codeforces';

interface UserData {
  user: User;
  ratingHistory: RatingChange[];
  submissions: Submission[];
  blogEntries: BlogEntry[];
}

// Helper function to add delay between API calls
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

function App() {
  const [isDark, setIsDark] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('darkMode');
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      return saved ? JSON.parse(saved) : prefersDark;
    }
    return false;
  });
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [userData, setUserData] = useState<UserData[]>([]);
  const [searchedHandles, setSearchedHandles] = useState<string[]>([]);
  
  // Alpha Info Modal State
  const [showAlphaInfo, setShowAlphaInfo] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('darkMode', JSON.stringify(isDark));
      if (isDark) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  }, [isDark]);

  const fetchUserData = async (handle: string): Promise<UserData> => {
    // Fetch user data sequentially with delays to respect rate limits
    const user = await getUserInfo(handle);
    await delay(1000); // 1 second delay
    
    const ratingHistory = await getUserRating(handle);
    await delay(1000); // 1 second delay
    
    const submissions = await getUserSubmissions(handle);
    await delay(1000); // 1 second delay
    
    const blogEntries = await getUserBlogEntries(handle);

    return { user, ratingHistory, submissions, blogEntries };
  };

  const handleSubmit = async (handles: string[]) => {
    setLoading(true);
    setError(null);
    
    try {
      const results: UserData[] = [];
      
      // Fetch data for each user sequentially with delays
      for (let i = 0; i < handles.length; i++) {
        const userData = await fetchUserData(handles[i]);
        results.push(userData);
        
        // Add delay between users (except for the last one)
        if (i < handles.length - 1) {
          await delay(2000); // 2 second delay between users
        }
      }
      
      setUserData(results);
      setSearchedHandles(handles);
    } catch (err) {
      if (err instanceof CodeforcesApiError) {
        setError(err.message);
      } else {
        setError('Failed to fetch user data. Please check the usernames and try again.');
      }
      setUserData([]);
      setSearchedHandles([]);
    } finally {
      setLoading(false);
    }
  };

  const handleRetry = () => {
    if (searchedHandles.length > 0) {
      handleSubmit(searchedHandles);
    }
  };

  const toggleDarkMode = () => {
    setIsDark(!isDark);
  };

  const isComparison = userData.length === 2;

  return (
    <div className={`min-h-screen transition-all duration-500 ${
      isDark 
        ? 'bg-gradient-to-br from-dark-950 via-dark-900 to-dark-800' 
        : 'bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50'
    }`}>
      <div className="container mx-auto px-4 py-4 md:py-8">
        <div className="flex justify-between items-center mb-4 md:mb-6">
          {/* Alpha Access Button */}
          <button
            onClick={() => setShowAlphaInfo(true)}
            className="group flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl hover:from-purple-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl font-medium text-sm"
          >
            <UserPlus className="w-4 h-4" />
            <span className="hidden sm:inline">Alpha Access</span>
            <span className="sm:hidden">Alpha</span>
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={toggleDarkMode}
            className={`group p-2 md:p-3 rounded-xl backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 border ${
              isDark
                ? 'bg-dark-800/80 border-dark-700/50 hover:bg-dark-700/80'
                : 'bg-white/80 border-gray-200/50 hover:bg-white/90'
            }`}
            aria-label="Toggle dark mode"
          >
            <div className="relative w-5 h-5 md:w-6 md:h-6">
              <Sun className={`absolute inset-0 w-5 h-5 md:w-6 md:h-6 text-amber-500 transition-all duration-300 ${isDark ? 'opacity-0 rotate-90 scale-0' : 'opacity-100 rotate-0 scale-100'}`} />
              <Moon className={`absolute inset-0 w-5 h-5 md:w-6 md:h-6 text-blue-400 transition-all duration-300 ${isDark ? 'opacity-100 rotate-0 scale-100' : 'opacity-0 -rotate-90 scale-0'}`} />
            </div>
          </button>
        </div>

        <div className="max-w-7xl mx-auto">
          <UserInput onSubmit={handleSubmit} loading={loading} />
          
          {/* Show upcoming contests when no user data is loaded */}
          {userData.length === 0 && !loading && !error && (
            <div className="mt-6 md:mt-8 max-w-4xl mx-auto">
              <UpcomingContests />
            </div>
          )}
          
          <div className="mt-6 md:mt-8">
            {loading && (
              <div className="animate-fade-in">
                <LoadingSpinner 
                  message="Fetching data from Codeforces..." 
                  size="lg"
                />
              </div>
            )}
            
            {error && (
              <div className="animate-slide-up">
                <ErrorMessage 
                  message={error} 
                  onRetry={handleRetry}
                  showRetry={searchedHandles.length > 0}
                />
              </div>
            )}
            
            {userData.length > 0 && !loading && !error && (
              <div className="space-y-6 md:space-y-8 animate-fade-in">
                {isComparison ? (
                  <ComparisonView
                    users={userData.map(d => d.user)}
                    ratingHistories={userData.map(d => d.ratingHistory)}
                    submissions={userData.map(d => d.submissions)}
                    isDark={isDark}
                  />
                ) : (
                  <UserProfile
                    user={userData[0].user}
                    ratingHistory={userData[0].ratingHistory}
                    submissions={userData[0].submissions}
                    blogEntries={userData[0].blogEntries}
                    isDark={isDark}
                  />
                )}
              </div>
            )}
          </div>
        </div>
      </div>
      
      <Footer />

      {/* Alpha Info Modal */}
      {showAlphaInfo && (
        <AlphaInfoModal onClose={() => setShowAlphaInfo(false)} />
      )}
    </div>
  );
}

export default App;