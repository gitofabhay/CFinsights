import { ChartOptions } from 'chart.js';

export const defaultChartOptions: ChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: true,
      position: 'top' as const,
    },
  },
  scales: {
    x: {
      grid: {
        color: 'rgba(156, 163, 175, 0.2)',
      },
      ticks: {
        color: 'rgba(156, 163, 175, 0.8)',
      },
    },
    y: {
      grid: {
        color: 'rgba(156, 163, 175, 0.2)',
      },
      ticks: {
        color: 'rgba(156, 163, 175, 0.8)',
      },
    },
  },
};

export const darkModeChartOptions: ChartOptions = {
  ...defaultChartOptions,
  plugins: {
    ...defaultChartOptions.plugins,
    legend: {
      ...defaultChartOptions.plugins?.legend,
      labels: {
        color: 'rgba(229, 231, 235, 0.8)',
      },
    },
  },
  scales: {
    x: {
      grid: {
        color: 'rgba(75, 85, 99, 0.3)',
      },
      ticks: {
        color: 'rgba(229, 231, 235, 0.7)',
      },
    },
    y: {
      grid: {
        color: 'rgba(75, 85, 99, 0.3)',
      },
      ticks: {
        color: 'rgba(229, 231, 235, 0.7)',
      },
    },
  },
};

export function getRankColor(rank?: string): string {
  if (!rank) return '#6B7280';
  
  const colors: Record<string, string> = {
    'newbie': '#808080',
    'pupil': '#008000',
    'specialist': '#03A89E',
    'expert': '#0000FF',
    'candidate master': '#AA00AA',
    'master': '#FF8C00',
    'international master': '#FF8C00',
    'grandmaster': '#FF0000',
    'international grandmaster': '#FF0000',
    'legendary grandmaster': '#FF0000',
  };
  
  return colors[rank.toLowerCase()] || '#6B7280';
}

export function getVerdictColor(verdict?: string): string {
  if (!verdict) return '#6B7280';
  
  const colors: Record<string, string> = {
    'OK': '#10B981',
    'WRONG_ANSWER': '#EF4444',
    'TIME_LIMIT_EXCEEDED': '#F59E0B',
    'MEMORY_LIMIT_EXCEEDED': '#8B5CF6',
    'RUNTIME_ERROR': '#F97316',
    'COMPILATION_ERROR': '#EC4899',
    'PRESENTATION_ERROR': '#6366F1',
    'IDLENESS_LIMIT_EXCEEDED': '#84CC16',
    'SECURITY_VIOLATED': '#DC2626',
    'CRASHED': '#991B1B',
    'INPUT_PREPARATION_CRASHED': '#7C2D12',
    'CHALLENGED': '#92400E',
    'SKIPPED': '#6B7280',
    'TESTING': '#3B82F6',
    'REJECTED': '#374151',
  };
  
  return colors[verdict] || '#6B7280';
}