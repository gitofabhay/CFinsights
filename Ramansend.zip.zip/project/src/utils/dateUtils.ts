import { format, fromUnixTime, startOfDay, eachDayOfInterval, subYears } from 'date-fns';

export function formatUnixTime(timestamp: number, formatStr = 'MMM dd, yyyy'): string {
  try {
    return format(fromUnixTime(timestamp), formatStr);
  } catch (error) {
    console.error('Error formatting timestamp:', timestamp, error);
    return 'Invalid date';
  }
}

export function getDateFromUnix(timestamp: number): Date {
  return fromUnixTime(timestamp);
}

export function getDaysInLastYear(): Date[] {
  const today = new Date();
  const oneYearAgo = subYears(today, 1);
  
  return eachDayOfInterval({
    start: startOfDay(oneYearAgo),
    end: startOfDay(today)
  });
}

export function groupSubmissionsByDay(submissions: any[]) {
  const grouped: Record<string, number> = {};
  
  submissions.forEach(submission => {
    try {
      const date = format(fromUnixTime(submission.creationTimeSeconds), 'yyyy-MM-dd');
      grouped[date] = (grouped[date] || 0) + 1;
    } catch (error) {
      console.error('Error processing submission date:', submission.creationTimeSeconds, error);
    }
  });
  
  return grouped;
}