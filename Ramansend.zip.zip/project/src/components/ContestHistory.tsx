import React from 'react';
import { Trophy, TrendingUp, TrendingDown, Award } from 'lucide-react';
import { RatingChange } from '../types/codeforces';
import { formatUnixTime } from '../utils/dateUtils';

interface ContestHistoryProps {
  ratingHistory: RatingChange[];
}

export function ContestHistory({ ratingHistory }: ContestHistoryProps) {
  if (ratingHistory.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 md:p-6">
        <h3 className="text-base md:text-lg font-semibold text-gray-900 dark:text-white mb-4">Contest History</h3>
        <div className="text-center py-6 md:py-8 text-gray-500 dark:text-gray-400">
          No contest history found
        </div>
      </div>
    );
  }

  const sortedHistory = [...ratingHistory]
    .sort((a, b) => b.ratingUpdateTimeSeconds - a.ratingUpdateTimeSeconds)
    .slice(0, 10);

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-4 md:p-6">
      <h3 className="text-base md:text-lg font-semibold text-gray-900 dark:text-white mb-4">Recent Contests</h3>
      
      <div className="space-y-3">
        {sortedHistory.map((contest, index) => {
          const ratingChange = contest.newRating - contest.oldRating;
          const isPositive = ratingChange > 0;
          
          return (
            <div
              key={contest.contestId}
              className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-3 md:p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors gap-3 sm:gap-0"
            >
              <div className="flex items-start space-x-3 flex-1 min-w-0">
                <div className="flex-shrink-0 mt-0.5">
                  {contest.rank <= 3 ? (
                    <Award className="w-4 h-4 md:w-5 md:h-5 text-yellow-500" />
                  ) : (
                    <Trophy className="w-4 h-4 md:w-5 md:h-5 text-gray-400" />
                  )}
                </div>
                
                <div className="min-w-0 flex-1">
                  <p className="text-sm md:text-base font-medium text-gray-900 dark:text-white line-clamp-2 mb-1">
                    {contest.contestName}
                  </p>
                  <p className="text-xs md:text-sm text-gray-500 dark:text-gray-400">
                    {formatUnixTime(contest.ratingUpdateTimeSeconds)}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 md:space-x-4 text-sm w-full sm:w-auto justify-between sm:justify-end">
                <div className="text-center">
                  <div className="text-sm md:text-base text-gray-900 dark:text-white font-medium">#{contest.rank}</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">Rank</div>
                </div>
                
                <div className="text-center">
                  <div className="text-sm md:text-base text-gray-900 dark:text-white font-medium">{contest.newRating}</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">Rating</div>
                </div>
                
                <div className="flex items-center space-x-1">
                  {isPositive ? (
                    <TrendingUp className="w-3 h-3 md:w-4 md:h-4 text-green-500" />
                  ) : (
                    <TrendingDown className="w-3 h-3 md:w-4 md:h-4 text-red-500" />
                  )}
                  <span className={`font-medium text-sm md:text-base ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
                    {isPositive ? '+' : ''}{ratingChange}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      
      {ratingHistory.length > 10 && (
        <div className="mt-4 text-center">
          <span className="text-xs md:text-sm text-gray-500 dark:text-gray-400">
            Showing 10 of {ratingHistory.length} contests
          </span>
        </div>
      )}
    </div>
  );
}