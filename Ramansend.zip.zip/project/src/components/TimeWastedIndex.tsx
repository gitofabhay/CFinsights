import React from 'react';
import { Clock, AlertTriangle, TrendingDown, Target } from 'lucide-react';
import { Submission } from '../types/codeforces';
import { formatUnixTime } from '../utils/dateUtils';

interface TimeWastedIndexProps {
  submissions: Submission[];
}

interface WastedTimeAnalysis {
  problemKey: string;
  problem: any;
  attempts: Submission[];
  wastedTime: number; // in minutes
  finalVerdict: string;
  waChain: number;
  timeToSolve: number; // total time from first attempt to AC
}

export function TimeWastedIndex({ submissions }: TimeWastedIndexProps) {
  // Analyze time wasted on WA chains from last 20 submissions
  const getTimeWastedAnalysis = (): WastedTimeAnalysis[] => {
    // Get last 20 submissions sorted by creation time (most recent first)
    const last20Submissions = [...submissions]
      .sort((a, b) => b.creationTimeSeconds - a.creationTimeSeconds)
      .slice(0, 20);

    const problemAttempts = new Map<string, Submission[]>();
    
    // Group last 20 submissions by problem
    last20Submissions.forEach(submission => {
      const problemKey = `${submission.problem.contestId}-${submission.problem.index}`;
      if (!problemAttempts.has(problemKey)) {
        problemAttempts.set(problemKey, []);
      }
      problemAttempts.get(problemKey)!.push(submission);
    });

    const wastedTimeProblems: WastedTimeAnalysis[] = [];

    problemAttempts.forEach((attempts, problemKey) => {
      const sortedAttempts = attempts.sort((a, b) => a.creationTimeSeconds - b.creationTimeSeconds);
      const firstAttempt = sortedAttempts[0];
      const lastAttempt = sortedAttempts[sortedAttempts.length - 1];
      
      // Only consider problems with multiple attempts
      if (sortedAttempts.length < 2) return;

      // Count consecutive WA attempts
      let waChain = 0;
      let maxWaChain = 0;
      let currentChain = 0;
      
      sortedAttempts.forEach(attempt => {
        if (attempt.verdict === 'WRONG_ANSWER') {
          currentChain++;
          maxWaChain = Math.max(maxWaChain, currentChain);
        } else {
          if (currentChain >= 2) { // Consider chains of 2+ WAs as significant for recent submissions
            waChain = Math.max(waChain, currentChain);
          }
          currentChain = 0;
        }
      });

      // Calculate time wasted (time between first and last attempt)
      const timeToSolve = (lastAttempt.creationTimeSeconds - firstAttempt.creationTimeSeconds) / 60; // in minutes
      
      // Include problems with significant time waste (>5 minutes and multiple attempts) for recent analysis
      if (timeToSolve > 5 && (maxWaChain >= 2 || sortedAttempts.length >= 3)) {
        wastedTimeProblems.push({
          problemKey,
          problem: firstAttempt.problem,
          attempts: sortedAttempts,
          wastedTime: timeToSolve,
          finalVerdict: lastAttempt.verdict || 'UNKNOWN',
          waChain: maxWaChain,
          timeToSolve
        });
      }
    });

    return wastedTimeProblems
      .sort((a, b) => b.wastedTime - a.wastedTime)
      .slice(0, 10); // Top 10 time wasters from recent submissions
  };

  const timeWastedAnalysis = getTimeWastedAnalysis();
  
  // Calculate overall time wasted index
  const totalWastedTime = timeWastedAnalysis.reduce((sum, item) => sum + item.wastedTime, 0);
  const averageWastedTime = timeWastedAnalysis.length > 0 ? totalWastedTime / timeWastedAnalysis.length : 0;

  const getWastedTimeColor = (minutes: number) => {
    if (minutes < 30) return 'text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/30 border-green-200 dark:border-green-700';
    if (minutes < 60) return 'text-yellow-600 dark:text-yellow-400 bg-yellow-50 dark:bg-yellow-900/30 border-yellow-200 dark:border-yellow-700';
    if (minutes < 120) return 'text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-900/30 border-orange-200 dark:border-orange-700';
    return 'text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/30 border-red-200 dark:border-red-700';
  };

  const formatTime = (minutes: number) => {
    if (minutes < 60) return `${Math.round(minutes)}m`;
    const hours = Math.floor(minutes / 60);
    const mins = Math.round(minutes % 60);
    return `${hours}h ${mins}m`;
  };

  const getEfficiencyRating = () => {
    if (averageWastedTime < 15) return { rating: 'Excellent', color: 'text-green-600 dark:text-green-400', icon: '🎯' };
    if (averageWastedTime < 30) return { rating: 'Good', color: 'text-blue-600 dark:text-blue-400', icon: '👍' };
    if (averageWastedTime < 45) return { rating: 'Average', color: 'text-yellow-600 dark:text-yellow-400', icon: '⚡' };
    if (averageWastedTime < 60) return { rating: 'Needs Work', color: 'text-orange-600 dark:text-orange-400', icon: '⚠️' };
    return { rating: 'High Waste', color: 'text-red-600 dark:text-red-400', icon: '🚨' };
  };

  const efficiency = getEfficiencyRating();

  if (timeWastedAnalysis.length === 0) {
    return (
      <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-xl md:rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50">
        <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 flex items-center gap-2">
          <Clock className="w-5 h-5 md:w-6 md:h-6 text-primary-500" />
          <span className="text-sm md:text-base">Time Wasted Index</span>
        </h3>
        <div className="text-center py-6 md:py-8 text-gray-500 dark:text-dark-400">
          <Target className="w-10 h-10 md:w-12 md:h-12 mx-auto mb-3 text-green-300 dark:text-green-600" />
          <p className="text-base md:text-lg font-medium mb-1">Efficient solver! 🎯</p>
          <p className="text-xs md:text-sm">No significant time waste detected in your last 20 submissions</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-xl md:rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
      <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 md:mb-6 flex items-center gap-2">
        <Clock className="w-5 h-5 md:w-6 md:h-6 text-warning-500" />
        <span className="text-sm md:text-base">Time Wasted Index</span>
        <span className="text-xs md:text-sm font-normal text-gray-500 dark:text-dark-400 ml-2">
          (Last 20 submissions analysis)
        </span>
      </h3>

      {/* Summary Stats */}
      <div className="mb-4 md:mb-6 grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4 text-xs md:text-sm">
        <div className="text-center p-2 md:p-3 bg-warning-50 dark:bg-warning-900/30 rounded-lg border dark:border-warning-800/50">
          <div className="text-lg md:text-2xl font-bold text-warning-600 dark:text-warning-400">
            {formatTime(totalWastedTime)}
          </div>
          <div className="text-gray-600 dark:text-dark-300">Total Wasted</div>
        </div>
        <div className="text-center p-2 md:p-3 bg-error-50 dark:bg-error-900/30 rounded-lg border dark:border-error-800/50">
          <div className="text-lg md:text-2xl font-bold text-error-600 dark:text-error-400">
            {formatTime(averageWastedTime)}
          </div>
          <div className="text-gray-600 dark:text-dark-300">Avg Per Problem</div>
        </div>
        <div className="text-center p-2 md:p-3 bg-purple-50 dark:bg-purple-900/30 rounded-lg border dark:border-purple-800/50">
          <div className="text-lg md:text-2xl font-bold text-purple-600 dark:text-purple-400">
            {timeWastedAnalysis.length}
          </div>
          <div className="text-gray-600 dark:text-dark-300">Problems</div>
        </div>
        <div className={`text-center p-2 md:p-3 rounded-lg border ${getWastedTimeColor(averageWastedTime)}`}>
          <div className="text-lg md:text-2xl font-bold">
            {efficiency.icon}
          </div>
          <div className="text-gray-600 dark:text-dark-300 text-xs">{efficiency.rating}</div>
        </div>
      </div>

      <div className="space-y-3 md:space-y-4">
        {timeWastedAnalysis.map((analysis, index) => (
          <div
            key={analysis.problemKey}
            className={`${getWastedTimeColor(analysis.wastedTime)} rounded-lg md:rounded-xl p-3 md:p-4 border`}
          >
            <div className="flex items-start justify-between mb-2 md:mb-3">
              <div className="flex-1 min-w-0">
                <h4 className="text-sm md:text-lg font-semibold text-gray-900 dark:text-dark-100 mb-1 line-clamp-1">
                  {analysis.problem.contestId}{analysis.problem.index}. {analysis.problem.name}
                </h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 md:gap-3 text-xs md:text-sm">
                  <div className="flex items-center gap-1 md:gap-2">
                    <Clock className="w-3 h-3 md:w-4 md:h-4" />
                    <span className="text-gray-600 dark:text-dark-300">
                      <span className="font-semibold">{formatTime(analysis.wastedTime)}</span> wasted
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-1 md:gap-2">
                    <AlertTriangle className="w-3 h-3 md:w-4 md:h-4" />
                    <span className="text-gray-600 dark:text-dark-300">
                      <span className="font-semibold">{analysis.waChain}</span> WA chain
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-1 md:gap-2">
                    <TrendingDown className="w-3 h-3 md:w-4 md:h-4" />
                    <span className="text-gray-600 dark:text-dark-300">
                      <span className="font-semibold">{analysis.attempts.length}</span> attempts
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="text-right ml-2 md:ml-4">
                <div className="text-lg md:text-xl font-bold">
                  #{index + 1}
                </div>
                <div className="text-xs text-gray-600 dark:text-dark-300">
                  worst
                </div>
              </div>
            </div>

            {/* Submission Timeline */}
            <div className="mt-2 md:mt-3">
              <p className="text-xs md:text-sm font-medium text-gray-700 dark:text-dark-300 mb-1 md:mb-2">
                Submission Pattern:
              </p>
              <div className="flex flex-wrap gap-1">
                {analysis.attempts.slice(0, 8).map((attempt, idx) => (
                  <span
                    key={idx}
                    className={`px-1.5 md:px-2 py-0.5 md:py-1 rounded text-xs font-medium ${
                      attempt.verdict === 'OK' 
                        ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300'
                        : attempt.verdict === 'WRONG_ANSWER'
                        ? 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300'
                        : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
                    }`}
                  >
                    {attempt.verdict === 'OK' ? 'AC' : 
                     attempt.verdict === 'WRONG_ANSWER' ? 'WA' :
                     attempt.verdict === 'TIME_LIMIT_EXCEEDED' ? 'TLE' :
                     attempt.verdict?.substring(0, 3) || 'UNK'}
                  </span>
                ))}
                {analysis.attempts.length > 8 && (
                  <span className="px-1.5 md:px-2 py-0.5 md:py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded text-xs">
                    +{analysis.attempts.length - 8}
                  </span>
                )}
              </div>
            </div>

            {/* Time breakdown */}
            <div className="mt-2 md:mt-3 text-xs md:text-sm text-gray-600 dark:text-dark-300">
              <span>First attempt: {formatUnixTime(analysis.attempts[0].creationTimeSeconds, 'MMM dd, HH:mm')}</span>
              {analysis.finalVerdict === 'OK' && (
                <span className="ml-2 md:ml-4">
                  → Final AC: {formatUnixTime(analysis.attempts[analysis.attempts.length - 1].creationTimeSeconds, 'MMM dd, HH:mm')}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 md:mt-6 p-3 md:p-4 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-lg md:rounded-xl border border-blue-200/50 dark:border-blue-700/50">
        <div className="flex items-start gap-2 md:gap-3">
          <Clock className="w-4 h-4 md:w-5 md:h-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="font-semibold text-blue-700 dark:text-blue-300 mb-1 text-sm md:text-base">
              Recent Efficiency Tips:
            </h4>
            <p className="text-xs md:text-sm text-blue-600 dark:text-blue-400">
              {averageWastedTime > 45 
                ? "Your recent submissions show significant debugging time. Consider reading problems more carefully and testing edge cases before submitting."
                : averageWastedTime > 20
                ? "Recent efficiency is decent! Try to identify patterns in your WA submissions to avoid similar mistakes."
                : "Excellent recent time management! You're solving problems efficiently with minimal debugging time."
              }
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}