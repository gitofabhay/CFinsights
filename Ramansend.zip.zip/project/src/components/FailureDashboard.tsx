import React from 'react';
import { Bar } from 'react-chartjs-2';
import { AlertTriangle, TrendingDown, Bug, Clock, X, Zap, Brain } from 'lucide-react';
import { Submission } from '../types/codeforces';
import { getVerdictColor } from '../utils/chartUtils';

interface FailureDashboardProps {
  submissions: Submission[];
  isDark?: boolean;
}

export function FailureDashboard({ submissions, isDark = false }: FailureDashboardProps) {
  // Get last 50 failed submissions
  const failedSubmissions = submissions
    .filter(s => s.verdict && s.verdict !== 'OK')
    .sort((a, b) => b.creationTimeSeconds - a.creationTimeSeconds)
    .slice(0, 50);

  if (failedSubmissions.length === 0) {
    return (
      <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-6 border border-gray-200/50 dark:border-dark-700/50">
        <h3 className="text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 flex items-center gap-2">
          <AlertTriangle className="w-6 h-6 text-success-500" />
          Failure Dashboard
        </h3>
        <div className="text-center py-8 text-gray-500 dark:text-dark-400">
          <div className="w-16 h-16 mx-auto mb-4 bg-success-100 dark:bg-success-900/30 rounded-full flex items-center justify-center">
            <AlertTriangle className="w-8 h-8 text-success-500" />
          </div>
          <p className="text-lg font-medium mb-1">Excellent work!</p>
          <p className="text-sm">No recent failed submissions found</p>
        </div>
      </div>
    );
  }

  // 1. Topic-Based Failure Analysis
  const getTopicFailures = () => {
    const topicCounts = new Map<string, number>();
    
    failedSubmissions.forEach(submission => {
      submission.problem.tags.forEach(tag => {
        topicCounts.set(tag, (topicCounts.get(tag) || 0) + 1);
      });
    });

    return Array.from(topicCounts.entries())
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5);
  };

  // 2. Problem Rating Analysis
  const getRatingDistribution = () => {
    const ratingCounts = new Map<string, number>();
    
    failedSubmissions
      .filter(s => s.problem.rating)
      .forEach(submission => {
        const rating = submission.problem.rating!;
        const range = `${Math.floor(rating / 100) * 100}`;
        ratingCounts.set(range, (ratingCounts.get(range) || 0) + 1);
      });

    return Array.from(ratingCounts.entries())
      .sort(([a], [b]) => parseInt(a) - parseInt(b));
  };

  // 3. Error Type Analysis
  const getErrorTypes = () => {
    const errorCounts = new Map<string, number>();
    
    failedSubmissions.forEach(submission => {
      const verdict = submission.verdict!;
      errorCounts.set(verdict, (errorCounts.get(verdict) || 0) + 1);
    });

    return Array.from(errorCounts.entries())
      .sort(([,a], [,b]) => b - a);
  };

  const topicFailures = getTopicFailures();
  const ratingDistribution = getRatingDistribution();
  const errorTypes = getErrorTypes();

  // Chart data for topics
  const topicChartData = {
    labels: topicFailures.map(([topic]) => topic.replace(/_/g, ' ')),
    datasets: [
      {
        label: 'Failed Submissions',
        data: topicFailures.map(([, count]) => count),
        backgroundColor: [
          'rgba(239, 68, 68, 0.8)',   // Red
          'rgba(245, 158, 11, 0.8)',  // Amber
          'rgba(168, 85, 247, 0.8)',  // Purple
          'rgba(59, 130, 246, 0.8)',  // Blue
          'rgba(16, 185, 129, 0.8)',  // Emerald
        ],
        borderColor: [
          'rgba(239, 68, 68, 1)',
          'rgba(245, 158, 11, 1)',
          'rgba(168, 85, 247, 1)',
          'rgba(59, 130, 246, 1)',
          'rgba(16, 185, 129, 1)',
        ],
        borderWidth: 2,
      },
    ],
  };

  // Chart data for ratings
  const ratingChartData = {
    labels: ratingDistribution.map(([rating]) => rating),
    datasets: [
      {
        label: 'Failed Submissions',
        data: ratingDistribution.map(([, count]) => count),
        backgroundColor: 'rgba(239, 68, 68, 0.8)',
        borderColor: 'rgba(239, 68, 68, 1)',
        borderWidth: 2,
      },
    ],
  };

  // Chart data for error types
  const errorChartData = {
    labels: errorTypes.map(([error]) => error.replace(/_/g, ' ')),
    datasets: [
      {
        label: 'Frequency',
        data: errorTypes.map(([, count]) => count),
        backgroundColor: errorTypes.map(([error]) => getVerdictColor(error)),
        borderColor: errorTypes.map(([error]) => getVerdictColor(error)),
        borderWidth: 2,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: isDark ? 'rgba(15, 23, 42, 0.95)' : 'rgba(255, 255, 255, 0.95)',
        titleColor: isDark ? 'rgba(241, 245, 249, 1)' : 'rgba(17, 24, 39, 1)',
        bodyColor: isDark ? 'rgba(241, 245, 249, 0.8)' : 'rgba(17, 24, 39, 0.8)',
        borderColor: isDark ? 'rgba(51, 65, 85, 0.8)' : 'rgba(156, 163, 175, 0.3)',
        borderWidth: 1,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: isDark ? 'rgba(51, 65, 85, 0.4)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(241, 245, 249, 0.7)' : 'rgba(156, 163, 175, 0.8)',
        },
      },
      x: {
        grid: {
          color: isDark ? 'rgba(51, 65, 85, 0.4)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(241, 245, 249, 0.7)' : 'rgba(156, 163, 175, 0.8)',
          maxRotation: 45,
        },
      },
    },
  };

  const getErrorIcon = (verdict: string) => {
    switch (verdict) {
      case 'WRONG_ANSWER': return <X className="w-4 h-4" />;
      case 'TIME_LIMIT_EXCEEDED': return <Clock className="w-4 h-4" />;
      case 'MEMORY_LIMIT_EXCEEDED': return <Brain className="w-4 h-4" />;
      case 'RUNTIME_ERROR': return <Bug className="w-4 h-4" />;
      case 'COMPILATION_ERROR': return <AlertTriangle className="w-4 h-4" />;
      default: return <TrendingDown className="w-4 h-4" />;
    }
  };

  const getErrorAdvice = (verdict: string) => {
    const advice: Record<string, string> = {
      'WRONG_ANSWER': 'Double-check logic, test edge cases, and verify sample inputs',
      'TIME_LIMIT_EXCEEDED': 'Optimize algorithm complexity or implementation efficiency',
      'MEMORY_LIMIT_EXCEEDED': 'Reduce memory usage or optimize data structures',
      'RUNTIME_ERROR': 'Check array bounds, null pointers, and division by zero',
      'COMPILATION_ERROR': 'Review syntax, variable declarations, and imports',
      'PRESENTATION_ERROR': 'Check output format, spacing, and newlines',
      'IDLENESS_LIMIT_EXCEEDED': 'Ensure your program produces output within time limits',
    };
    return advice[verdict] || 'Review problem requirements and implementation carefully';
  };

  return (
    <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
      <h3 className="text-xl font-bold text-gray-900 dark:text-dark-100 mb-6 flex items-center gap-2">
        <AlertTriangle className="w-6 h-6 text-error-500" />
        Failure Dashboard
        <span className="text-sm font-normal text-gray-500 dark:text-dark-400 ml-2">
          (Last {failedSubmissions.length} failed submissions)
        </span>
      </h3>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="text-center p-4 bg-error-50 dark:bg-error-900/30 rounded-xl border border-error-200/50 dark:border-error-700/50">
          <div className="text-2xl font-bold text-error-600 dark:text-error-400">{failedSubmissions.length}</div>
          <div className="text-sm text-gray-600 dark:text-dark-300">Failed Submissions</div>
        </div>
        <div className="text-center p-4 bg-warning-50 dark:bg-warning-900/30 rounded-xl border border-warning-200/50 dark:border-warning-700/50">
          <div className="text-2xl font-bold text-warning-600 dark:text-warning-400">{topicFailures.length}</div>
          <div className="text-sm text-gray-600 dark:text-dark-300">Weak Topics</div>
        </div>
        <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/30 rounded-xl border border-purple-200/50 dark:border-purple-700/50">
          <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">{errorTypes.length}</div>
          <div className="text-sm text-gray-600 dark:text-dark-300">Error Types</div>
        </div>
        <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/30 rounded-xl border border-blue-200/50 dark:border-blue-700/50">
          <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
            {failedSubmissions.filter(s => s.problem.rating).length}
          </div>
          <div className="text-sm text-gray-600 dark:text-dark-300">Rated Problems</div>
        </div>
      </div>

      <div className="space-y-8">
        {/* Topic-Based Failure Graph */}
        <div>
          <h4 className="text-lg font-semibold text-gray-900 dark:text-dark-100 mb-4 flex items-center gap-2">
            <TrendingDown className="w-5 h-5 text-error-500" />
            Top 5 Problematic Topics
          </h4>
          <div className="h-64">
            <Bar data={topicChartData} options={chartOptions} />
          </div>
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {topicFailures.slice(0, 3).map(([topic, count]) => (
              <div key={topic} className="bg-error-50 dark:bg-error-900/20 rounded-lg p-3 border border-error-200/50 dark:border-error-700/50">
                <div className="font-medium text-error-700 dark:text-error-300">
                  {topic.replace(/_/g, ' ')}
                </div>
                <div className="text-sm text-gray-600 dark:text-dark-300">
                  {count} failed submission{count !== 1 ? 's' : ''}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Problem Rating Graph */}
        <div>
          <h4 className="text-lg font-semibold text-gray-900 dark:text-dark-100 mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5 text-warning-500" />
            Failed Problems by Rating
          </h4>
          <div className="h-64">
            <Bar data={ratingChartData} options={chartOptions} />
          </div>
          <div className="mt-4 text-center text-sm text-gray-600 dark:text-dark-300">
            Most failures occur in the {ratingDistribution.length > 0 ? ratingDistribution[0][0] : 'N/A'} rating range
          </div>
        </div>

        {/* Error Type Graph */}
        <div>
          <h4 className="text-lg font-semibold text-gray-900 dark:text-dark-100 mb-4 flex items-center gap-2">
            <Bug className="w-5 h-5 text-purple-500" />
            Error Type Distribution
          </h4>
          <div className="h-64">
            <Bar data={errorChartData} options={chartOptions} />
          </div>
          
          {/* Error Type Advice */}
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            {errorTypes.slice(0, 4).map(([error, count]) => (
              <div
                key={error}
                className="bg-gradient-to-r from-gray-50 to-red-50 dark:from-gray-900/20 dark:to-red-900/20 rounded-xl p-4 border border-gray-200/50 dark:border-gray-700/50"
              >
                <div className="flex items-start gap-3">
                  <div 
                    className="p-2 rounded-lg text-white"
                    style={{ backgroundColor: getVerdictColor(error) }}
                  >
                    {getErrorIcon(error)}
                  </div>
                  <div className="flex-1">
                    <h5 className="font-semibold text-gray-900 dark:text-dark-100 mb-1">
                      {error.replace(/_/g, ' ')} ({count})
                    </h5>
                    <p className="text-sm text-gray-600 dark:text-dark-300">
                      {getErrorAdvice(error)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Items */}
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-xl p-6 border border-blue-200/50 dark:border-blue-700/50">
          <h4 className="font-semibold text-blue-700 dark:text-blue-300 mb-4 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            Recommended Action Plan
          </h4>
          <div className="space-y-3 text-sm">
            {topicFailures.length > 0 && (
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <p className="text-blue-600 dark:text-blue-400">
                  <strong>Focus on {topicFailures[0][0].replace(/_/g, ' ')}</strong> - your most problematic topic with {topicFailures[0][1]} failures
                </p>
              </div>
            )}
            {errorTypes.length > 0 && (
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 bg-purple-500 rounded-full mt-2"></div>
                <p className="text-purple-600 dark:text-purple-400">
                  <strong>Address {errorTypes[0][0].replace(/_/g, ' ')}</strong> - your most common error type
                </p>
              </div>
            )}
            <div className="flex items-start gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
              <p className="text-green-600 dark:text-green-400">
                <strong>Practice systematically</strong> - solve 5-10 easier problems in weak topics before attempting harder ones
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}