import React from 'react';
import { Bar, Doughnut, Pie, Line } from 'react-chartjs-2';
import { Submission } from '../types/codeforces';
import { Code2, Target, Zap, TrendingUp } from 'lucide-react';

interface ProblemTypeComparisonProps {
  submissions1: Submission[];
  submissions2: Submission[];
  user1Handle: string;
  user2Handle: string;
  isDark?: boolean;
}

export function ProblemTypeComparison({ 
  submissions1, 
  submissions2, 
  user1Handle, 
  user2Handle, 
  isDark = false 
}: ProblemTypeComparisonProps) {
  
  const getTagCounts = (submissions: Submission[]) => {
    const tagCounts: Record<string, number> = {};
    const uniqueProblems = new Set<string>();

    submissions
      .filter(s => s.verdict === 'OK')
      .forEach(submission => {
        const problemKey = `${submission.problem.contestId}-${submission.problem.index}`;
        if (!uniqueProblems.has(problemKey)) {
          uniqueProblems.add(problemKey);
          submission.problem.tags.forEach(tag => {
            tagCounts[tag] = (tagCounts[tag] || 0) + 1;
          });
        }
      });

    return tagCounts;
  };

  const getLanguageCounts = (submissions: Submission[]) => {
    const languageCounts: Record<string, number> = {};
    
    submissions.forEach(submission => {
      languageCounts[submission.programmingLanguage] = (languageCounts[submission.programmingLanguage] || 0) + 1;
    });

    return languageCounts;
  };

  const getTagRatingDistribution = (submissions: Submission[], tag: string) => {
    const ratingCounts: Record<number, number> = {};
    const uniqueProblems = new Set<string>();

    submissions
      .filter(s => s.verdict === 'OK' && s.problem.rating && s.problem.tags.includes(tag))
      .forEach(submission => {
        const problemKey = `${submission.problem.contestId}-${submission.problem.index}`;
        if (!uniqueProblems.has(problemKey)) {
          uniqueProblems.add(problemKey);
          const rating = Math.floor(submission.problem.rating! / 100) * 100;
          ratingCounts[rating] = (ratingCounts[rating] || 0) + 1;
        }
      });

    return ratingCounts;
  };

  const tags1 = getTagCounts(submissions1);
  const tags2 = getTagCounts(submissions2);
  const languages1 = getLanguageCounts(submissions1);
  const languages2 = getLanguageCounts(submissions2);

  // Get top tags from both users
  const allTags = new Set([...Object.keys(tags1), ...Object.keys(tags2)]);
  const topTags = Array.from(allTags)
    .map(tag => ({
      tag,
      count1: tags1[tag] || 0,
      count2: tags2[tag] || 0,
      total: (tags1[tag] || 0) + (tags2[tag] || 0)
    }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 12);

  // Get top languages
  const allLanguages = new Set([...Object.keys(languages1), ...Object.keys(languages2)]);
  const topLanguages1 = Object.entries(languages1)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 6);
  const topLanguages2 = Object.entries(languages2)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 6);

  const tagComparisonData = {
    labels: topTags.map(({ tag }) => tag.replace(/_/g, ' ')),
    datasets: [
      {
        label: user1Handle,
        data: topTags.map(({ count1 }) => count1),
        backgroundColor: 'rgba(59, 130, 246, 0.8)', // Blue
        borderColor: 'rgba(59, 130, 246, 1)',
        borderWidth: 2,
      },
      {
        label: user2Handle,
        data: topTags.map(({ count2 }) => count2),
        backgroundColor: 'rgba(245, 158, 11, 0.8)', // Amber/Orange
        borderColor: 'rgba(245, 158, 11, 1)',
        borderWidth: 2,
      },
    ],
  };

  const languageData1 = {
    labels: topLanguages1.map(([lang]) => lang),
    datasets: [{
      data: topLanguages1.map(([,count]) => count),
      backgroundColor: [
        '#3B82F6', '#8B5CF6', '#10B981', '#F59E0B', '#EF4444', '#6366F1'
      ],
      borderWidth: 2,
      borderColor: isDark ? '#374151' : '#ffffff',
    }],
  };

  const languageData2 = {
    labels: topLanguages2.map(([lang]) => lang),
    datasets: [{
      data: topLanguages2.map(([,count]) => count),
      backgroundColor: [
        '#3B82F6', '#8B5CF6', '#10B981', '#F59E0B', '#EF4444', '#6366F1'
      ],
      borderWidth: 2,
      borderColor: isDark ? '#374151' : '#ffffff',
    }],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        labels: {
          color: isDark ? 'rgba(229, 231, 235, 0.8)' : 'rgba(17, 24, 39, 0.8)',
          usePointStyle: true,
          padding: 20,
        },
      },
      tooltip: {
        backgroundColor: isDark ? 'rgba(17, 24, 39, 0.9)' : 'rgba(255, 255, 255, 0.9)',
        titleColor: isDark ? 'rgba(229, 231, 235, 1)' : 'rgba(17, 24, 39, 1)',
        bodyColor: isDark ? 'rgba(229, 231, 235, 0.8)' : 'rgba(17, 24, 39, 0.8)',
        borderColor: isDark ? 'rgba(75, 85, 99, 0.5)' : 'rgba(156, 163, 175, 0.3)',
        borderWidth: 1,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: isDark ? 'rgba(75, 85, 99, 0.3)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(229, 231, 235, 0.7)' : 'rgba(156, 163, 175, 0.8)',
        },
      },
      x: {
        grid: {
          color: isDark ? 'rgba(75, 85, 99, 0.3)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(229, 231, 235, 0.7)' : 'rgba(156, 163, 175, 0.8)',
          maxRotation: 45,
        },
      },
    },
  };

  const pieOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          color: isDark ? 'rgba(229, 231, 235, 0.8)' : 'rgba(17, 24, 39, 0.8)',
          padding: 15,
        },
      },
      tooltip: {
        backgroundColor: isDark ? 'rgba(17, 24, 39, 0.9)' : 'rgba(255, 255, 255, 0.9)',
        titleColor: isDark ? 'rgba(229, 231, 235, 1)' : 'rgba(17, 24, 39, 1)',
        bodyColor: isDark ? 'rgba(229, 231, 235, 0.8)' : 'rgba(17, 24, 39, 0.8)',
      },
    },
  };

  // Problem difficulty analysis with new standard ranges
  const getDifficultyStats = (submissions: Submission[]) => {
    const difficulties = { 'Very Easy': 0, Easy: 0, Moderate: 0, Hard: 0, 'Very Hard': 0 };
    const uniqueProblems = new Set<string>();

    submissions
      .filter(s => s.verdict === 'OK' && s.problem.rating)
      .forEach(submission => {
        const problemKey = `${submission.problem.contestId}-${submission.problem.index}`;
        if (!uniqueProblems.has(problemKey)) {
          uniqueProblems.add(problemKey);
          const rating = submission.problem.rating!;
          if (rating < 1100) difficulties['Very Easy']++;
          else if (rating < 1400) difficulties.Easy++;
          else if (rating < 1700) difficulties.Moderate++;
          else if (rating < 2000) difficulties.Hard++;
          else difficulties['Very Hard']++;
        }
      });

    return difficulties;
  };

  const diff1 = getDifficultyStats(submissions1);
  const diff2 = getDifficultyStats(submissions2);

  const difficultyData1 = {
    labels: ['Very Easy (<1100)', 'Easy (1100-1399)', 'Moderate (1400-1699)', 'Hard (1700-1999)', 'Very Hard (≥2000)'],
    datasets: [{
      data: [diff1['Very Easy'], diff1.Easy, diff1.Moderate, diff1.Hard, diff1['Very Hard']],
      backgroundColor: [
        'rgba(34, 197, 94, 0.8)',   // Green
        'rgba(59, 130, 246, 0.8)',  // Blue
        'rgba(245, 158, 11, 0.8)',  // Amber
        'rgba(239, 68, 68, 0.8)',   // Red
        'rgba(168, 85, 247, 0.8)',  // Purple
      ],
      borderWidth: 2,
      borderColor: isDark ? '#374151' : '#ffffff',
    }],
  };

  const difficultyData2 = {
    labels: ['Very Easy (<1100)', 'Easy (1100-1399)', 'Moderate (1400-1699)', 'Hard (1700-1999)', 'Very Hard (≥2000)'],
    datasets: [{
      data: [diff2['Very Easy'], diff2.Easy, diff2.Moderate, diff2.Hard, diff2['Very Hard']],
      backgroundColor: [
        'rgba(34, 197, 94, 0.8)',   // Green
        'rgba(59, 130, 246, 0.8)',  // Blue
        'rgba(245, 158, 11, 0.8)',  // Amber
        'rgba(239, 68, 68, 0.8)',   // Red
        'rgba(168, 85, 247, 0.8)',  // Purple
      ],
      borderWidth: 2,
      borderColor: isDark ? '#374151' : '#ffffff',
    }],
  };

  // Tag rating progression for top 3 tags
  const getTagRatingProgression = (submissions: Submission[], tag: string) => {
    const solvedProblems = submissions
      .filter(s => s.verdict === 'OK' && s.problem.rating && s.problem.tags.includes(tag))
      .map(s => ({ rating: s.problem.rating!, time: s.creationTimeSeconds }))
      .sort((a, b) => a.time - b.time);

    const progression: { x: number; y: number }[] = [];
    let maxRating = 0;
    
    solvedProblems.forEach((problem, index) => {
      maxRating = Math.max(maxRating, problem.rating);
      progression.push({ x: index + 1, y: maxRating });
    });

    return progression;
  };

  const topTagsForProgression = topTags.slice(0, 3);

  return (
    <div className="space-y-6 md:space-y-8">
      <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-gray-700/50">
        <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-white mb-4 md:mb-6 text-center flex items-center justify-center gap-2">
          <Code2 className="w-5 h-5 md:w-6 md:h-6 text-primary-500" />
          <span className="text-sm md:text-base">Problem Tags Comparison</span>
        </h3>
        <div className="h-64 md:h-80">
          <Bar data={tagComparisonData} options={chartOptions} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-gray-700/50">
          <h3 className="text-base md:text-lg font-bold text-gray-900 dark:text-white mb-3 md:mb-4 text-center flex items-center justify-center gap-2">
            <Target className="w-4 h-4 md:w-5 md:h-5 text-primary-500" />
            <span className="text-sm md:text-base truncate">{user1Handle} - Difficulty</span>
          </h3>
          <div className="h-48 md:h-64">
            <Doughnut data={difficultyData1} options={pieOptions} />
          </div>
        </div>

        <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-gray-700/50">
          <h3 className="text-base md:text-lg font-bold text-gray-900 dark:text-white mb-3 md:mb-4 text-center flex items-center justify-center gap-2">
            <Target className="w-4 h-4 md:w-5 md:h-5 text-secondary-500" />
            <span className="text-sm md:text-base truncate">{user2Handle} - Difficulty</span>
          </h3>
          <div className="h-48 md:h-64">
            <Doughnut data={difficultyData2} options={pieOptions} />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-gray-700/50">
          <h3 className="text-base md:text-lg font-bold text-gray-900 dark:text-white mb-3 md:mb-4 text-center flex items-center justify-center gap-2">
            <Code2 className="w-4 h-4 md:w-5 md:h-5 text-primary-500" />
            <span className="text-sm md:text-base truncate">{user1Handle} - Languages</span>
          </h3>
          <div className="h-48 md:h-64">
            <Pie data={languageData1} options={pieOptions} />
          </div>
        </div>

        <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-gray-700/50">
          <h3 className="text-base md:text-lg font-bold text-gray-900 dark:text-white mb-3 md:mb-4 text-center flex items-center justify-center gap-2">
            <Code2 className="w-4 h-4 md:w-5 md:h-5 text-secondary-500" />
            <span className="text-sm md:text-base truncate">{user2Handle} - Languages</span>
          </h3>
          <div className="h-48 md:h-64">
            <Pie data={languageData2} options={pieOptions} />
          </div>
        </div>
      </div>

      {/* Tag Rating Progression */}
      {topTagsForProgression.map((tagData, index) => {
        const progression1 = getTagRatingProgression(submissions1, tagData.tag);
        const progression2 = getTagRatingProgression(submissions2, tagData.tag);
        
        if (progression1.length === 0 && progression2.length === 0) return null;

        const progressionData = {
          datasets: [
            {
              label: `${user1Handle} - ${tagData.tag}`,
              data: progression1,
              borderColor: '#3B82F6',
              backgroundColor: 'rgba(59, 130, 246, 0.1)',
              tension: 0.4,
              pointRadius: 3,
              borderWidth: 2,
            },
            {
              label: `${user2Handle} - ${tagData.tag}`,
              data: progression2,
              borderColor: '#F59E0B',
              backgroundColor: 'rgba(245, 158, 11, 0.1)',
              tension: 0.4,
              pointRadius: 3,
              borderWidth: 2,
            },
          ],
        };

        const progressionOptions = {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            title: {
              display: true,
              text: `${tagData.tag.replace(/_/g, ' ')} - Rating Progression`,
              color: isDark ? 'rgba(229, 231, 235, 0.9)' : 'rgba(17, 24, 39, 0.9)',
            },
            legend: {
              labels: {
                color: isDark ? 'rgba(229, 231, 235, 0.8)' : 'rgba(17, 24, 39, 0.8)',
              },
            },
          },
          scales: {
            x: {
              type: 'linear' as const,
              title: {
                display: true,
                text: 'Problems Solved',
                color: isDark ? 'rgba(229, 231, 235, 0.8)' : 'rgba(17, 24, 39, 0.8)',
              },
              grid: {
                color: isDark ? 'rgba(75, 85, 99, 0.3)' : 'rgba(156, 163, 175, 0.2)',
              },
              ticks: {
                color: isDark ? 'rgba(229, 231, 235, 0.7)' : 'rgba(156, 163, 175, 0.8)',
              },
            },
            y: {
              title: {
                display: true,
                text: 'Max Rating Solved',
                color: isDark ? 'rgba(229, 231, 235, 0.8)' : 'rgba(17, 24, 39, 0.8)',
              },
              grid: {
                color: isDark ? 'rgba(75, 85, 99, 0.3)' : 'rgba(156, 163, 175, 0.2)',
              },
              ticks: {
                color: isDark ? 'rgba(229, 231, 235, 0.7)' : 'rgba(156, 163, 175, 0.8)',
              },
            },
          },
        };

        return (
          <div key={tagData.tag} className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-gray-700/50">
            <div className="h-64 md:h-80">
              <Line data={progressionData} options={progressionOptions} />
            </div>
          </div>
        );
      })}
    </div>
  );
}