import React from 'react';
import { Line } from 'react-chartjs-2';
import { Calendar, TrendingUp, Activity, Target, Flame } from 'lucide-react';
import { Submission } from '../types/codeforces';
import { format, startOfWeek, addWeeks, isWithinInterval } from 'date-fns';

interface ConsistencyIndexProps {
  submissions: Submission[];
  isDark?: boolean;
}

interface WeeklyData {
  week: Date;
  weekLabel: string;
  acceptedCount: number;
  totalSubmissions: number;
}

export function ConsistencyIndex({ submissions, isDark = false }: ConsistencyIndexProps) {
  // Generate weekly data for the last 26 weeks (6 months)
  const getWeeklyConsistency = (): WeeklyData[] => {
    const now = new Date();
    const weeksData: WeeklyData[] = [];
    
    // Generate 26 weeks of data
    for (let i = 25; i >= 0; i--) {
      const weekStart = startOfWeek(addWeeks(now, -i), { weekStartsOn: 1 }); // Monday start
      const weekEnd = addWeeks(weekStart, 1);
      
      const weekSubmissions = submissions.filter(sub => {
        const subDate = new Date(sub.creationTimeSeconds * 1000);
        return isWithinInterval(subDate, { start: weekStart, end: weekEnd });
      });
      
      const acceptedCount = weekSubmissions.filter(sub => sub.verdict === 'OK').length;
      
      weeksData.push({
        week: weekStart,
        weekLabel: format(weekStart, 'MMM dd'),
        acceptedCount,
        totalSubmissions: weekSubmissions.length
      });
    }
    
    return weeksData;
  };

  const weeklyData = getWeeklyConsistency();
  
  // Calculate streaks and statistics
  const getCurrentStreak = (): number => {
    let streak = 0;
    for (let i = weeklyData.length - 1; i >= 0; i--) {
      if (weeklyData[i].acceptedCount > 0) {
        streak++;
      } else {
        break;
      }
    }
    return streak;
  };

  const getLongestStreak = (): number => {
    let maxStreak = 0;
    let currentStreak = 0;
    
    weeklyData.forEach(week => {
      if (week.acceptedCount > 0) {
        currentStreak++;
        maxStreak = Math.max(maxStreak, currentStreak);
      } else {
        currentStreak = 0;
      }
    });
    
    return maxStreak;
  };

  const getActiveWeeks = (): number => {
    return weeklyData.filter(week => week.acceptedCount > 0).length;
  };

  const getMostProductiveWeek = (): WeeklyData | null => {
    return weeklyData.reduce((max, week) => 
      week.acceptedCount > max.acceptedCount ? week : max, 
      weeklyData[0]
    );
  };

  const getDrySpells = (): number => {
    let drySpells = 0;
    let consecutiveZeros = 0;
    
    weeklyData.forEach(week => {
      if (week.acceptedCount === 0) {
        consecutiveZeros++;
      } else {
        if (consecutiveZeros >= 2) { // 2+ weeks of inactivity
          drySpells++;
        }
        consecutiveZeros = 0;
      }
    });
    
    // Check if we end with a dry spell
    if (consecutiveZeros >= 2) {
      drySpells++;
    }
    
    return drySpells;
  };

  const currentStreak = getCurrentStreak();
  const longestStreak = getLongestStreak();
  const activeWeeks = getActiveWeeks();
  const mostProductiveWeek = getMostProductiveWeek();
  const drySpells = getDrySpells();
  const averageACs = activeWeeks > 0 ? Math.round(weeklyData.reduce((sum, week) => sum + week.acceptedCount, 0) / activeWeeks) : 0;

  // Chart data
  const chartData = {
    labels: weeklyData.map(week => week.weekLabel),
    datasets: [
      {
        label: 'Accepted Solutions',
        data: weeklyData.map(week => week.acceptedCount),
        borderColor: '#10B981', // Green
        backgroundColor: 'rgba(16, 185, 129, 0.1)',
        tension: 0.4,
        fill: true,
        pointRadius: 4,
        pointHoverRadius: 6,
        borderWidth: 3,
        pointBackgroundColor: '#10B981',
        pointBorderColor: '#ffffff',
        pointBorderWidth: 2,
      },
      {
        label: 'Total Submissions',
        data: weeklyData.map(week => week.totalSubmissions),
        borderColor: '#3B82F6', // Blue
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        tension: 0.4,
        fill: false,
        pointRadius: 3,
        pointHoverRadius: 5,
        borderWidth: 2,
        borderDash: [5, 5],
        pointBackgroundColor: '#3B82F6',
        pointBorderColor: '#ffffff',
        pointBorderWidth: 1,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      title: {
        display: true,
        text: 'Weekly Coding Consistency (Last 6 Months)',
        color: isDark ? 'rgba(241, 245, 249, 0.9)' : 'rgba(17, 24, 39, 0.9)',
        font: {
          size: 16,
          weight: 'bold' as const,
        },
      },
      legend: {
        labels: {
          color: isDark ? 'rgba(241, 245, 249, 0.8)' : 'rgba(17, 24, 39, 0.8)',
          usePointStyle: true,
          padding: 20,
        },
      },
      tooltip: {
        backgroundColor: isDark ? 'rgba(15, 23, 42, 0.95)' : 'rgba(255, 255, 255, 0.95)',
        titleColor: isDark ? 'rgba(241, 245, 249, 1)' : 'rgba(17, 24, 39, 1)',
        bodyColor: isDark ? 'rgba(241, 245, 249, 0.8)' : 'rgba(17, 24, 39, 0.8)',
        borderColor: isDark ? 'rgba(51, 65, 85, 0.8)' : 'rgba(156, 163, 175, 0.3)',
        borderWidth: 1,
        callbacks: {
          title: (context: any) => {
            const index = context[0].dataIndex;
            return `Week of ${weeklyData[index].weekLabel}`;
          },
          afterBody: (context: any) => {
            const index = context[0].dataIndex;
            const week = weeklyData[index];
            const efficiency = week.totalSubmissions > 0 ? Math.round((week.acceptedCount / week.totalSubmissions) * 100) : 0;
            return [`Efficiency: ${efficiency}%`];
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: isDark ? 'rgba(51, 65, 85, 0.4)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(241, 245, 249, 0.7)' : 'rgba(156, 163, 175, 0.8)',
        },
        title: {
          display: true,
          text: 'Number of Problems',
          color: isDark ? 'rgba(241, 245, 249, 0.8)' : 'rgba(17, 24, 39, 0.8)',
        },
      },
      x: {
        grid: {
          color: isDark ? 'rgba(51, 65, 85, 0.4)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(241, 245, 249, 0.7)' : 'rgba(156, 163, 175, 0.8)',
          maxRotation: 45,
        },
        title: {
          display: true,
          text: 'Week',
          color: isDark ? 'rgba(241, 245, 249, 0.8)' : 'rgba(17, 24, 39, 0.8)',
        },
      },
    },
  };

  const getConsistencyRating = () => {
    const consistencyScore = (activeWeeks / 26) * 100; // Percentage of active weeks
    if (consistencyScore >= 80) return { rating: 'Excellent', color: 'text-green-600 dark:text-green-400', icon: '🔥' };
    if (consistencyScore >= 60) return { rating: 'Good', color: 'text-blue-600 dark:text-blue-400', icon: '💪' };
    if (consistencyScore >= 40) return { rating: 'Average', color: 'text-yellow-600 dark:text-yellow-400', icon: '⚡' };
    if (consistencyScore >= 20) return { rating: 'Inconsistent', color: 'text-orange-600 dark:text-orange-400', icon: '⚠️' };
    return { rating: 'Sporadic', color: 'text-red-600 dark:text-red-400', icon: '😴' };
  };

  const consistency = getConsistencyRating();

  return (
    <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-xl md:rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
      <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 md:mb-6 flex items-center gap-2">
        <Activity className="w-5 h-5 md:w-6 md:h-6 text-success-500" />
        <span className="text-sm md:text-base">Consistency Index</span>
        <span className="text-xs md:text-sm font-normal text-gray-500 dark:text-dark-400 ml-2">
          Weekly practice tracking
        </span>
      </h3>

      {/* Summary Stats */}
      <div className="mb-4 md:mb-6 grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4 text-xs md:text-sm">
        <div className="text-center p-2 md:p-3 bg-success-50 dark:bg-success-900/30 rounded-lg border dark:border-success-800/50">
          <div className="text-lg md:text-2xl font-bold text-success-600 dark:text-success-400">
            {currentStreak}
          </div>
          <div className="text-gray-600 dark:text-dark-300">Current Streak</div>
        </div>
        <div className="text-center p-2 md:p-3 bg-primary-50 dark:bg-primary-900/30 rounded-lg border dark:border-primary-800/50">
          <div className="text-lg md:text-2xl font-bold text-primary-600 dark:text-primary-400">
            {longestStreak}
          </div>
          <div className="text-gray-600 dark:text-dark-300">Longest Streak</div>
        </div>
        <div className="text-center p-2 md:p-3 bg-secondary-50 dark:bg-secondary-900/30 rounded-lg border dark:border-secondary-800/50">
          <div className="text-lg md:text-2xl font-bold text-secondary-600 dark:text-secondary-400">
            {activeWeeks}/26
          </div>
          <div className="text-gray-600 dark:text-dark-300">Active Weeks</div>
        </div>
        <div className={`text-center p-2 md:p-3 rounded-lg border ${consistency.color.includes('green') ? 'bg-green-50 dark:bg-green-900/30 border-green-200 dark:border-green-700' : 
          consistency.color.includes('blue') ? 'bg-blue-50 dark:bg-blue-900/30 border-blue-200 dark:border-blue-700' :
          consistency.color.includes('yellow') ? 'bg-yellow-50 dark:bg-yellow-900/30 border-yellow-200 dark:border-yellow-700' :
          consistency.color.includes('orange') ? 'bg-orange-50 dark:bg-orange-900/30 border-orange-200 dark:border-orange-700' :
          'bg-red-50 dark:bg-red-900/30 border-red-200 dark:border-red-700'}`}>
          <div className="text-lg md:text-2xl font-bold">
            {consistency.icon}
          </div>
          <div className="text-gray-600 dark:text-dark-300 text-xs">{consistency.rating}</div>
        </div>
      </div>

      {/* Chart */}
      <div className="h-64 md:h-80 mb-4 md:mb-6">
        <Line data={chartData} options={chartOptions} />
      </div>

      {/* Detailed Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
        <div className="space-y-3 md:space-y-4">
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-lg md:rounded-xl p-3 md:p-4 border border-green-200/50 dark:border-green-700/50">
            <h4 className="font-semibold text-green-700 dark:text-green-300 mb-2 md:mb-3 flex items-center gap-2">
              <Flame className="w-4 h-4 md:w-5 md:h-5" />
              <span className="text-sm md:text-base">Streak Analysis</span>
            </h4>
            <div className="space-y-1 md:space-y-2 text-xs md:text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-dark-300">Current streak:</span>
                <span className="font-semibold text-green-600 dark:text-green-400">
                  {currentStreak} week{currentStreak !== 1 ? 's' : ''}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-dark-300">Longest streak:</span>
                <span className="font-semibold text-green-600 dark:text-green-400">
                  {longestStreak} week{longestStreak !== 1 ? 's' : ''}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-dark-300">Dry spells:</span>
                <span className="font-semibold text-gray-900 dark:text-dark-100">
                  {drySpells}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-lg md:rounded-xl p-3 md:p-4 border border-blue-200/50 dark:border-blue-700/50">
            <h4 className="font-semibold text-blue-700 dark:text-blue-300 mb-2 md:mb-3 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 md:w-5 md:h-5" />
              <span className="text-sm md:text-base">Performance</span>
            </h4>
            <div className="space-y-1 md:space-y-2 text-xs md:text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-dark-300">Avg ACs per active week:</span>
                <span className="font-semibold text-blue-600 dark:text-blue-400">
                  {averageACs}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-dark-300">Most productive week:</span>
                <span className="font-semibold text-blue-600 dark:text-blue-400">
                  {mostProductiveWeek?.acceptedCount || 0} ACs
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-dark-300">Activity rate:</span>
                <span className="font-semibold text-blue-600 dark:text-blue-400">
                  {Math.round((activeWeeks / 26) * 100)}%
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-lg md:rounded-xl p-3 md:p-4 border border-purple-200/50 dark:border-purple-700/50">
          <h4 className="font-semibold text-purple-700 dark:text-purple-300 mb-2 md:mb-3 flex items-center gap-2">
            <Target className="w-4 h-4 md:w-5 md:h-5" />
            <span className="text-sm md:text-base">Consistency Goals</span>
          </h4>
          <div className="space-y-2 md:space-y-3 text-xs md:text-sm">
            {currentStreak === 0 ? (
              <div className="p-2 md:p-3 bg-orange-100 dark:bg-orange-900/30 rounded-lg border border-orange-200 dark:border-orange-700">
                <p className="text-orange-700 dark:text-orange-300 font-medium">
                  🎯 Start a new streak this week!
                </p>
                <p className="text-orange-600 dark:text-orange-400 text-xs mt-1">
                  Solve at least 1 problem to begin building consistency.
                </p>
              </div>
            ) : currentStreak < 4 ? (
              <div className="p-2 md:p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg border border-blue-200 dark:border-blue-700">
                <p className="text-blue-700 dark:text-blue-300 font-medium">
                  🔥 Keep the streak going!
                </p>
                <p className="text-blue-600 dark:text-blue-400 text-xs mt-1">
                  You're {4 - currentStreak} week{4 - currentStreak !== 1 ? 's' : ''} away from a month-long streak.
                </p>
              </div>
            ) : (
              <div className="p-2 md:p-3 bg-green-100 dark:bg-green-900/30 rounded-lg border border-green-200 dark:border-green-700">
                <p className="text-green-700 dark:text-green-300 font-medium">
                  🏆 Amazing consistency!
                </p>
                <p className="text-green-600 dark:text-green-400 text-xs mt-1">
                  You've maintained a {currentStreak}-week streak. Keep it up!
                </p>
              </div>
            )}
            
            <div className="space-y-1 text-purple-600 dark:text-purple-400">
              <p>• <strong>Target:</strong> Solve problems every week</p>
              <p>• <strong>Goal:</strong> Maintain 80%+ activity rate</p>
              <p>• <strong>Challenge:</strong> Beat your {longestStreak}-week record</p>
            </div>
          </div>
        </div>
      </div>

      {mostProductiveWeek && mostProductiveWeek.acceptedCount > 0 && (
        <div className="mt-4 md:mt-6 p-3 md:p-4 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 rounded-lg md:rounded-xl border border-yellow-200/50 dark:border-yellow-700/50">
          <div className="flex items-start gap-2 md:gap-3">
            <Calendar className="w-4 h-4 md:w-5 md:h-5 text-yellow-500 mt-0.5" />
            <div>
              <h4 className="font-semibold text-yellow-700 dark:text-yellow-300 mb-1 text-sm md:text-base">
                Most Productive Week:
              </h4>
              <p className="text-xs md:text-sm text-yellow-600 dark:text-yellow-400">
                Week of {mostProductiveWeek.weekLabel} - You solved <strong>{mostProductiveWeek.acceptedCount}</strong> problems! 
                {mostProductiveWeek.acceptedCount >= 10 && " That's incredible productivity! 🚀"}
                {mostProductiveWeek.acceptedCount >= 5 && mostProductiveWeek.acceptedCount < 10 && " Great work that week! 💪"}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}