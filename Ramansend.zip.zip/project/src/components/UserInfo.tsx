import React from 'react';
import { User, MapPin, Building, Calendar, Trophy, TrendingUp } from 'lucide-react';
import { User as UserType } from '../types/codeforces';
import { formatUnixTime } from '../utils/dateUtils';
import { getRankColor } from '../utils/chartUtils';

interface UserInfoProps {
  user: UserType;
}

export function UserInfo({ user }: UserInfoProps) {
  const rankColor = getRankColor(user.rank);
  const maxRankColor = getRankColor(user.maxRank);

  return (
    <div className="bg-white/90 dark:bg-dark-800/90 rounded-xl shadow-lg p-4 md:p-6 border dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
      <div className="flex flex-col sm:flex-row items-start space-y-4 sm:space-y-0 sm:space-x-4 md:space-x-6">
        <div className="relative mx-auto sm:mx-0">
          <img
            src={user.avatar || `https://ui-avatars.com/api/?name=${user.handle}&background=3B82F6&color=fff&size=128`}
            alt={user.handle}
            className="w-16 h-16 md:w-20 md:h-20 rounded-full border-4 border-white dark:border-dark-700 shadow-lg"
            onError={(e) => {
              const img = e.target as HTMLImageElement;
              img.src = `https://ui-avatars.com/api/?name=${user.handle}&background=3B82F6&color=fff&size=128`;
            }}
          />
          <div className="absolute -bottom-1 -right-1 w-5 h-5 md:w-6 md:h-6 bg-success-500 rounded-full border-2 border-white dark:border-dark-800 shadow-lg"></div>
        </div>
        
        <div className="flex-1 min-w-0 text-center sm:text-left">
          <div className="flex flex-col sm:flex-row items-center sm:items-start space-y-2 sm:space-y-0 sm:space-x-3 mb-3 md:mb-4">
            <h2 className="text-xl md:text-2xl font-bold text-gray-900 dark:text-dark-100 truncate">
              {user.handle}
            </h2>
            {user.rank && (
              <span
                className="px-2 md:px-3 py-1 rounded-full text-xs md:text-sm font-medium text-white shadow-lg"
                style={{ backgroundColor: rankColor }}
              >
                {user.rank}
              </span>
            )}
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4">
            <div className="space-y-2">
              {user.rating && (
                <div className="flex items-center justify-center sm:justify-start space-x-2 text-xs md:text-sm text-gray-600 dark:text-dark-300">
                  <TrendingUp className="w-3 h-3 md:w-4 md:h-4" />
                  <span>Rating: <span className="font-semibold text-gray-900 dark:text-dark-100">{user.rating}</span></span>
                </div>
              )}
              
              {user.maxRating && (
                <div className="flex items-center justify-center sm:justify-start space-x-2 text-xs md:text-sm text-gray-600 dark:text-dark-300">
                  <Trophy className="w-3 h-3 md:w-4 md:h-4" />
                  <span>Max Rating: <span className="font-semibold" style={{ color: maxRankColor }}>{user.maxRating}</span></span>
                </div>
              )}
              
              {user.country && (
                <div className="flex items-center justify-center sm:justify-start space-x-2 text-xs md:text-sm text-gray-600 dark:text-dark-300">
                  <MapPin className="w-3 h-3 md:w-4 md:h-4" />
                  <span className="truncate">{user.country}{user.city ? `, ${user.city}` : ''}</span>
                </div>
              )}
            </div>
            
            <div className="space-y-2">
              {user.organization && (
                <div className="flex items-center justify-center sm:justify-start space-x-2 text-xs md:text-sm text-gray-600 dark:text-dark-300">
                  <Building className="w-3 h-3 md:w-4 md:h-4" />
                  <span className="truncate">{user.organization}</span>
                </div>
              )}
              
              <div className="flex items-center justify-center sm:justify-start space-x-2 text-xs md:text-sm text-gray-600 dark:text-dark-300">
                <Calendar className="w-3 h-3 md:w-4 md:h-4" />
                <span>Joined {formatUnixTime(user.registrationTimeSeconds)}</span>
              </div>
              
              <div className="flex items-center justify-center sm:justify-start space-x-2 text-xs md:text-sm text-gray-600 dark:text-dark-300">
                <User className="w-3 h-3 md:w-4 md:h-4" />
                <span>Contribution: {user.contribution}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}