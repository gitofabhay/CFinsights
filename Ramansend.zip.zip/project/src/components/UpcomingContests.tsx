import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Trophy, ExternalLink, AlertCircle } from 'lucide-react';
import { Contest } from '../types/codeforces';
import { getUpcomingContests } from '../services/codeforcesApi';
import { formatUnixTime } from '../utils/dateUtils';

export function UpcomingContests() {
  const [contests, setContests] = useState<Contest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchContests = async () => {
      try {
        setLoading(true);
        setError(null);
        const upcomingContests = await getUpcomingContests();
        setContests(upcomingContests);
      } catch (err) {
        console.error('Error fetching contests:', err);
        setError('Unable to load upcoming contests at the moment');
        setContests([]);
      } finally {
        setLoading(false);
      }
    };

    fetchContests();
    
    // Refresh every 5 minutes
    const interval = setInterval(fetchContests, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const getTimeUntilContest = (startTime: number) => {
    const now = Math.floor(Date.now() / 1000);
    const diff = startTime - now;
    
    if (diff <= 0) return 'Started';
    
    const days = Math.floor(diff / 86400);
    const hours = Math.floor((diff % 86400) / 3600);
    const minutes = Math.floor((diff % 3600) / 60);
    
    if (days > 0) return `${days}d ${hours}h`;
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  };

  const getDurationString = (durationSeconds: number) => {
    const hours = Math.floor(durationSeconds / 3600);
    const minutes = Math.floor((durationSeconds % 3600) / 60);
    if (hours > 0) {
      return minutes > 0 ? `${hours}h ${minutes}m` : `${hours}h`;
    }
    return `${minutes}m`;
  };

  if (loading) {
    return (
      <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50">
        <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5 md:w-6 md:h-6 text-primary-500" />
          <span className="text-sm md:text-base">Upcoming Contests</span>
        </h3>
        <div className="animate-pulse space-y-3 md:space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-16 md:h-20 bg-gray-200 dark:bg-dark-700 rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50">
        <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5 md:w-6 md:h-6 text-primary-500" />
          <span className="text-sm md:text-base">Upcoming Contests</span>
        </h3>
        <div className="flex items-center justify-center py-6 md:py-8 text-gray-500 dark:text-dark-400">
          <div className="text-center">
            <AlertCircle className="w-6 h-6 md:w-8 md:h-8 mx-auto mb-2 text-warning-500" />
            <p className="text-sm md:text-base">{error}</p>
            <p className="text-xs md:text-sm mt-1">Please try refreshing the page</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
      <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 md:mb-6 flex items-center gap-2">
        <Calendar className="w-5 h-5 md:w-6 md:h-6 text-primary-500" />
        <span className="text-sm md:text-base">Upcoming Contests</span>
      </h3>
      
      {contests.length === 0 ? (
        <div className="text-center py-6 md:py-8 text-gray-500 dark:text-dark-400">
          <Trophy className="w-10 h-10 md:w-12 md:h-12 mx-auto mb-3 text-gray-300 dark:text-dark-600" />
          <p className="text-base md:text-lg font-medium mb-1">No upcoming contests</p>
          <p className="text-xs md:text-sm">Check back later for new contests!</p>
        </div>
      ) : (
        <div className="space-y-3 md:space-y-4">
          {contests.map((contest) => (
            <div
              key={contest.id}
              className="bg-gradient-to-r from-primary-50 to-secondary-50 dark:from-primary-900/20 dark:to-secondary-900/20 rounded-xl p-3 md:p-4 border border-primary-200/50 dark:border-primary-700/50 hover:shadow-lg transition-all duration-300"
            >
              <div className="flex flex-col sm:flex-row items-start justify-between gap-3">
                <div className="flex-1 min-w-0 w-full">
                  <h4 className="text-sm md:text-lg font-semibold text-gray-900 dark:text-dark-100 mb-2 md:mb-3 line-clamp-2">
                    {contest.name}
                  </h4>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 md:gap-3 text-xs md:text-sm">
                    <div className="flex items-center gap-2 text-gray-600 dark:text-dark-300">
                      <Calendar className="w-3 h-3 md:w-4 md:h-4 text-primary-500 flex-shrink-0" />
                      <span className="truncate">
                        {formatUnixTime(contest.startTimeSeconds, 'MMM dd, HH:mm')}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-2 text-gray-600 dark:text-dark-300">
                      <Clock className="w-3 h-3 md:w-4 md:h-4 text-secondary-500 flex-shrink-0" />
                      <span className="truncate">
                        Duration: {getDurationString(contest.durationSeconds)}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Trophy className="w-3 h-3 md:w-4 md:h-4 text-warning-500 flex-shrink-0" />
                      <span className="px-2 py-1 bg-warning-100 dark:bg-warning-900/30 text-warning-700 dark:text-warning-300 rounded-full text-xs font-medium whitespace-nowrap">
                        Starts in {getTimeUntilContest(contest.startTimeSeconds)}
                      </span>
                    </div>
                  </div>
                </div>
                
                <a
                  href={`https://codeforces.com/contest/${contest.id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-shrink-0 p-2 text-gray-400 hover:text-primary-500 transition-colors"
                  title="View contest"
                >
                  <ExternalLink className="w-4 h-4 md:w-5 md:h-5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
      
      <div className="mt-3 md:mt-4 text-center">
        <p className="text-xs text-gray-500 dark:text-dark-400">
          Contest times are shown in your local timezone • Updates every 5 minutes
        </p>
      </div>
    </div>
  );
}