import React from 'react';
import { Submission } from '../types/codeforces';
import { getDaysInLastYear, groupSubmissionsByDay } from '../utils/dateUtils';
import { format, getDay } from 'date-fns';

interface ActivityHeatmapProps {
  submissions: Submission[];
}

export function ActivityHeatmap({ submissions }: ActivityHeatmapProps) {
  const days = getDaysInLastYear();
  const submissionsByDay = groupSubmissionsByDay(submissions);

  const maxSubmissions = Math.max(...Object.values(submissionsByDay), 1);

  const getIntensity = (count: number) => {
    if (count === 0) return 0;
    if (count <= maxSubmissions * 0.25) return 1;
    if (count <= maxSubmissions * 0.5) return 2;
    if (count <= maxSubmissions * 0.75) return 3;
    return 4;
  };

  const getColorClass = (intensity: number) => {
    const colors = [
      'bg-gray-100 dark:bg-dark-800',
      'bg-success-200 dark:bg-success-800/60',
      'bg-success-300 dark:bg-success-700/70',
      'bg-success-400 dark:bg-success-600/80',
      'bg-success-500 dark:bg-success-500/90',
    ];
    return colors[intensity];
  };

  // Create a square grid (approximately)
  const totalDays = days.length;
  const gridSize = Math.ceil(Math.sqrt(totalDays));
  const grid: (Date | null)[][] = [];

  // Fill the grid
  let dayIndex = 0;
  for (let row = 0; row < gridSize; row++) {
    grid[row] = [];
    for (let col = 0; col < gridSize; col++) {
      if (dayIndex < totalDays) {
        grid[row][col] = days[dayIndex];
        dayIndex++;
      } else {
        grid[row][col] = null;
      }
    }
  }

  const totalSubmissions = Object.values(submissionsByDay).reduce((sum, count) => sum + count, 0);
  const activeDays = Object.keys(submissionsByDay).length;

  return (
    <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
      <h3 className="text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 flex items-center gap-2">
        <div className="w-6 h-6 bg-gradient-to-r from-success-500 to-primary-500 rounded shadow-lg"></div>
        Activity Heatmap
      </h3>
      
      <div className="mb-6 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
        <div className="text-center p-3 bg-primary-50 dark:bg-primary-900/30 rounded-lg border dark:border-primary-800/50">
          <div className="text-2xl font-bold text-primary-600 dark:text-primary-400">{totalSubmissions}</div>
          <div className="text-gray-600 dark:text-dark-300">Total Submissions</div>
        </div>
        <div className="text-center p-3 bg-success-50 dark:bg-success-900/30 rounded-lg border dark:border-success-800/50">
          <div className="text-2xl font-bold text-success-600 dark:text-success-400">{activeDays}</div>
          <div className="text-gray-600 dark:text-dark-300">Active Days</div>
        </div>
        <div className="text-center p-3 bg-secondary-50 dark:bg-secondary-900/30 rounded-lg border dark:border-secondary-800/50">
          <div className="text-2xl font-bold text-secondary-600 dark:text-secondary-400">{maxSubmissions}</div>
          <div className="text-gray-600 dark:text-dark-300">Max Per Day</div>
        </div>
      </div>

      <div className="flex justify-center mb-4">
        <div className="inline-block p-4 bg-gray-50 dark:bg-dark-900/70 rounded-xl border dark:border-dark-700/50">
          <div 
            className="grid gap-1"
            style={{ 
              gridTemplateColumns: `repeat(${gridSize}, minmax(0, 1fr))`,
              maxWidth: '400px'
            }}
          >
            {grid.map((row, rowIndex) => 
              row.map((day, colIndex) => {
                if (!day) {
                  return (
                    <div
                      key={`${rowIndex}-${colIndex}`}
                      className="w-3 h-3 bg-transparent"
                    />
                  );
                }
                
                const dateStr = format(day, 'yyyy-MM-dd');
                const count = submissionsByDay[dateStr] || 0;
                const intensity = getIntensity(count);
                
                return (
                  <div
                    key={`${rowIndex}-${colIndex}`}
                    className={`w-3 h-3 rounded-sm ${getColorClass(intensity)} hover:ring-2 hover:ring-primary-500 dark:hover:ring-primary-400 transition-all cursor-pointer hover:scale-125 shadow-sm`}
                    title={`${format(day, 'MMM dd, yyyy')}: ${count} submissions`}
                  />
                );
              })
            )}
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center gap-4 text-xs text-gray-500 dark:text-dark-400">
        <span>Less</span>
        <div className="flex gap-1">
          {[0, 1, 2, 3, 4].map(intensity => (
            <div
              key={intensity}
              className={`w-3 h-3 rounded-sm ${getColorClass(intensity)} shadow-sm`}
            />
          ))}
        </div>
        <span>More</span>
      </div>
    </div>
  );
}