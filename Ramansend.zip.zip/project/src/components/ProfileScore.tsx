import React, { useState } from 'react';
import { Star, Calculator, Eye, EyeOff, Trophy, Target, TrendingUp, Code, Calendar, Award, Zap, CheckCircle, Users, Activity, Brain } from 'lucide-react';
import { User, RatingChange, Submission } from '../types/codeforces';

interface ProfileScoreProps {
  user: User;
  ratingHistory: RatingChange[];
  submissions: Submission[];
  isDark?: boolean;
}

interface ScoreBreakdown {
  M1: { value: number; score: number; description: string; actualValue: string };
  M2: { value: number; score: number; description: string; actualValue: string };
  M3: { value: number; score: number; description: string; actualValue: string };
  M4: { value: number; score: number; description: string; actualValue: string };
  M5: { value: number; score: number; description: string; actualValue: string };
  M6: { value: number; score: number; description: string; actualValue: string };
  M7: { value: number; score: number; description: string; actualValue: string };
  M8: { value: number; score: number; description: string; actualValue: string };
  M9: { value: number; score: number; description: string; actualValue: string };
  M10: { value: number; score: number; description: string; actualValue: string };
  M11: { value: number; score: number; description: string; actualValue: string };
  totalScore: number;
  starRating: number;
  verdict: string;
  verdictIcon: string;
  tier: string;
}

export function ProfileScore({ user, ratingHistory, submissions, isDark = false }: ProfileScoreProps) {
  const [showBreakdown, setShowBreakdown] = useState(false);

  const getRatingTier = (rating: number): string => {
    if (rating >= 3000) return 'Tourist Tier';
    if (rating >= 2600) return 'International GM';
    if (rating >= 2400) return 'Grandmaster';
    if (rating >= 2300) return 'International Master';
    if (rating >= 2100) return 'Master';
    if (rating >= 1900) return 'Candidate Master';
    if (rating >= 1600) return 'Expert';
    if (rating >= 1400) return 'Specialist';
    if (rating >= 1200) return 'Pupil';
    return 'Newbie';
  };

  const getWeightsForTier = (tier: string): number[] => {
    const weights: Record<string, number[]> = {
      'Newbie': [15, 20, 15, 10, 15, 5, 8, 5, 3, 2, 2],
      'Pupil': [15, 18, 12, 12, 15, 8, 10, 5, 3, 1, 1],
      'Specialist': [12, 15, 10, 15, 12, 10, 12, 8, 4, 1, 1],
      'Expert': [10, 12, 8, 18, 10, 12, 15, 10, 3, 1, 1],
      'Candidate Master': [8, 10, 6, 20, 8, 15, 18, 10, 3, 1, 1],
      'Master': [6, 8, 5, 15, 6, 18, 20, 12, 5, 3, 2],
      'International Master': [5, 6, 4, 12, 5, 20, 22, 15, 6, 3, 2],
      'Grandmaster': [4, 5, 3, 10, 4, 18, 25, 18, 8, 3, 2],
      'International GM': [3, 4, 2, 8, 3, 15, 28, 20, 10, 4, 3],
      'Tourist Tier': [2, 3, 1, 6, 2, 12, 30, 22, 12, 5, 5]
    };
    return weights[tier] || weights['Newbie'];
  };

  const calculateProfileScore = (): ScoreBreakdown => {
    const currentRating = user.rating || 0;
    const tier = getRatingTier(currentRating);
    const weights = getWeightsForTier(tier);
    
    const acceptedSubmissions = submissions.filter(s => s.verdict === 'OK');
    const uniqueProblems = new Set(acceptedSubmissions.map(s => `${s.problem.contestId}-${s.problem.index}`));
    const ratedProblems = acceptedSubmissions.filter(s => s.problem.rating);
    
    // M1: CF Rating (normalized)
    const M1_raw = currentRating;
    const M1_score = Math.min((currentRating / 4000) * 100, 100);
    
    // M2: Contests Participated
    const contestCount = ratingHistory.length;
    const M2_raw = contestCount;
    const M2_score = Math.min((contestCount / 100) * 100, 100);
    
    // M3: Contest Frequency & Streaks
    const sortedRatings = [...ratingHistory].sort((a, b) => a.ratingUpdateTimeSeconds - b.ratingUpdateTimeSeconds);
    const recentContests = sortedRatings.filter(r => {
      const sixMonthsAgo = Date.now() / 1000 - (6 * 30 * 24 * 60 * 60);
      return r.ratingUpdateTimeSeconds >= sixMonthsAgo;
    }).length;
    const M3_raw = recentContests;
    const M3_score = Math.min((recentContests / 20) * 100, 100);
    
    // M4: Upsolve Count
    const upsolveCount = Math.floor(acceptedSubmissions.length * 0.4); // Estimate 40% as upsolves
    const M4_raw = upsolveCount;
    const M4_score = Math.min((upsolveCount / 500) * 100, 100);
    
    // M5: Total Problems Solved
    const totalProblems = uniqueProblems.size;
    const M5_raw = totalProblems;
    const M5_score = Math.min((totalProblems / 2000) * 100, 100);
    
    // M6: Average Problem Rating Solved
    const avgProblemRating = ratedProblems.length > 0 
      ? ratedProblems.reduce((sum, s) => sum + s.problem.rating!, 0) / ratedProblems.length 
      : 0;
    const M6_raw = Math.round(avgProblemRating);
    const M6_score = Math.min((avgProblemRating / 3000) * 100, 100);
    
    // M7: Dynamic Metric (Tier-Specific)
    let M7_raw = 0;
    let M7_score = 0;
    let M7_description = '';
    
    if (currentRating < 2100) {
      // Above-Rated Problem Solves
      const aboveRatedProblems = ratedProblems.filter(s => s.problem.rating! > currentRating).length;
      M7_raw = aboveRatedProblems;
      M7_score = Math.min((aboveRatedProblems / 100) * 100, 100);
      M7_description = 'Above-rated problems solved';
    } else if (currentRating < 2300) {
      // Hard Tag Mastery
      const hardTags = ['segment tree', 'dp on trees', 'flows', 'heavy-light decomposition', 'centroid decomposition'];
      const hardTagProblems = acceptedSubmissions.filter(s => 
        s.problem.tags.some(tag => hardTags.includes(tag.toLowerCase()))
      ).length;
      M7_raw = hardTagProblems;
      M7_score = Math.min((hardTagProblems / 50) * 100, 100);
      M7_description = 'Hard tag mastery';
    } else if (currentRating < 2400) {
      // Trend Problems Solved
      const recentProblems = acceptedSubmissions.filter(s => 
        s.problem.rating && s.problem.rating >= 2000
      ).length;
      M7_raw = recentProblems;
      M7_score = Math.min((recentProblems / 100) * 100, 100);
      M7_description = 'High-difficulty trend problems';
    } else if (currentRating < 2600) {
      // Elite First-Attempt Accuracy
      const eliteProblems = acceptedSubmissions.filter(s => s.problem.rating && s.problem.rating >= 2400);
      const eliteAccuracy = eliteProblems.length > 0 ? (eliteProblems.length / submissions.filter(s => s.problem.rating && s.problem.rating >= 2400).length) * 100 : 0;
      M7_raw = Math.round(eliteAccuracy);
      M7_score = eliteAccuracy;
      M7_description = 'Elite problem first-attempt accuracy';
    } else if (currentRating < 3000) {
      // Virtual Contest Accuracy
      const virtualAccuracy = 85; // Placeholder - would need virtual contest data
      M7_raw = virtualAccuracy;
      M7_score = virtualAccuracy;
      M7_description = 'Virtual contest accuracy';
    } else {
      // Impact Metric
      const impactScore = Math.min(user.contribution * 2, 100); // Based on contribution
      M7_raw = user.contribution;
      M7_score = impactScore;
      M7_description = 'Community impact metric';
    }
    
    // M8: Tags / Topic Coverage
    const uniqueTags = new Set<string>();
    acceptedSubmissions.forEach(s => {
      s.problem.tags.forEach(tag => uniqueTags.add(tag));
    });
    const M8_raw = uniqueTags.size;
    const M8_score = Math.min((uniqueTags.size / 50) * 100, 100);
    
    // M9: Accuracy
    const totalSubmissions = submissions.length;
    const accuracy = totalSubmissions > 0 ? (acceptedSubmissions.length / totalSubmissions) * 100 : 0;
    const M9_raw = Math.round(accuracy);
    const M9_score = accuracy;
    
    // M10: Virtual Contest Performance
    const virtualPerformance = totalSubmissions > 0 ? 70 : 0; // Only give score if user has submissions
    const M10_raw = virtualPerformance;
    const M10_score = virtualPerformance;
    
    // M11: Community Contribution
    const contributionScore = user.contribution > 0 ? Math.min(Math.max(user.contribution, 0) / 100 * 100, 100) : 0;
    const M11_raw = user.contribution;
    const M11_score = contributionScore;
    
    // Calculate weighted total score
    const metrics = [M1_score, M2_score, M3_score, M4_score, M5_score, M6_score, M7_score, M8_score, M9_score, M10_score, M11_score];
    const totalScore = Math.round(weights.reduce((sum, weight, index) => sum + (weight * metrics[index] / 100), 0));
    
    const starRating = Math.min(Math.round(totalScore / 20), 5);
    
    const getVerdict = (score: number) => {
      if (totalSubmissions === 0 && contestCount === 0) {
        return { verdict: '🌱 New User', icon: '🌱' };
      }
      if (score >= 81) return { verdict: '🔥 Elite Performer', icon: '🔥' };
      if (score >= 61) return { verdict: '🌟 Strong Performer', icon: '🌟' };
      if (score >= 41) return { verdict: '⚡ On the Rise', icon: '⚡' };
      if (score >= 21) return { verdict: '🛠️ Starting Up', icon: '🛠️' };
      return { verdict: '💤 Needs a Boost', icon: '💤' };
    };
    
    const { verdict, icon } = getVerdict(totalScore);
    
    return {
      M1: { 
        value: M1_raw, 
        score: Math.round(M1_score * 10) / 10, 
        description: 'CF Rating (normalized)',
        actualValue: `${M1_raw} rating`
      },
      M2: { 
        value: M2_raw, 
        score: Math.round(M2_score * 10) / 10, 
        description: 'Contests participated',
        actualValue: `${M2_raw} contests`
      },
      M3: { 
        value: M3_raw, 
        score: Math.round(M3_score * 10) / 10, 
        description: 'Contest frequency & streaks',
        actualValue: `${M3_raw} recent contests`
      },
      M4: { 
        value: M4_raw, 
        score: Math.round(M4_score * 10) / 10, 
        description: 'Upsolve count',
        actualValue: `~${M4_raw} upsolves`
      },
      M5: { 
        value: M5_raw, 
        score: Math.round(M5_score * 10) / 10, 
        description: 'Total problems solved',
        actualValue: `${M5_raw} problems`
      },
      M6: { 
        value: M6_raw, 
        score: Math.round(M6_score * 10) / 10, 
        description: 'Average problem rating',
        actualValue: `${M6_raw} avg rating`
      },
      M7: { 
        value: M7_raw, 
        score: Math.round(M7_score * 10) / 10, 
        description: M7_description,
        actualValue: `${M7_raw} ${M7_description.includes('accuracy') ? '%' : ''}`
      },
      M8: { 
        value: M8_raw, 
        score: Math.round(M8_score * 10) / 10, 
        description: 'Tags / topic coverage',
        actualValue: `${M8_raw} unique tags`
      },
      M9: { 
        value: M9_raw, 
        score: Math.round(M9_score * 10) / 10, 
        description: 'Accuracy (solved/attempted)',
        actualValue: `${M9_raw}% accuracy`
      },
      M10: { 
        value: M10_raw, 
        score: Math.round(M10_score * 10) / 10, 
        description: 'Virtual contest performance',
        actualValue: `${M10_raw}% performance`
      },
      M11: { 
        value: M11_raw, 
        score: Math.round(M11_score * 10) / 10, 
        description: 'Community contribution',
        actualValue: `${M11_raw} contribution`
      },
      totalScore,
      starRating: Math.min(starRating, 5),
      verdict,
      verdictIcon: icon,
      tier
    };
  };

  const scoreData = calculateProfileScore();

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-5 h-5 md:w-6 md:h-6 ${
          i < rating 
            ? 'text-yellow-400 fill-yellow-400' 
            : 'text-gray-300 dark:text-gray-600'
        }`}
      />
    ));
  };

  const getScoreColor = (score: number) => {
    if (score >= 81) return 'from-red-500 to-orange-500';
    if (score >= 61) return 'from-purple-500 to-pink-500';
    if (score >= 41) return 'from-blue-500 to-indigo-500';
    if (score >= 21) return 'from-green-500 to-teal-500';
    return 'from-gray-500 to-gray-600';
  };

  const getMetricIcon = (metric: string) => {
    const icons: Record<string, React.ElementType> = {
      'M1': Trophy,
      'M2': Calendar,
      'M3': Activity,
      'M4': Award,
      'M5': Target,
      'M6': TrendingUp,
      'M7': Brain,
      'M8': Code,
      'M9': CheckCircle,
      'M10': Users,
      'M11': Zap
    };
    return icons[metric] || Trophy;
  };

  const weights = getWeightsForTier(scoreData.tier);

  return (
    <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-xl md:rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
      <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 md:mb-6 flex items-center gap-2">
        <Calculator className="w-5 h-5 md:w-6 md:h-6 text-primary-500" />
        <span className="text-sm md:text-base">CFinsights Profile Score</span>
        <span className="text-xs md:text-sm font-normal text-gray-500 dark:text-dark-400 ml-2">
          ({scoreData.tier})
        </span>
      </h3>

      {/* Main Score Display */}
      <div className="text-center mb-6">
        <div className={`inline-flex items-center justify-center w-24 h-24 md:w-32 md:h-32 rounded-full bg-gradient-to-r ${getScoreColor(scoreData.totalScore)} text-white mb-4 shadow-lg`}>
          <div className="text-center">
            <div className="text-2xl md:text-3xl font-bold">{scoreData.totalScore}</div>
            <div className="text-xs md:text-sm opacity-90">/ 100</div>
          </div>
        </div>
        
        <div className="flex items-center justify-center gap-1 mb-3">
          {renderStars(scoreData.starRating)}
        </div>
        
        <div className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-2">
          {scoreData.verdict}
        </div>
        
        <p className="text-sm md:text-base text-gray-600 dark:text-dark-300">
          Based on 11 tier-specific metrics for {scoreData.tier}
        </p>
      </div>

      {/* Toggle Breakdown Button */}
      <div className="text-center mb-6">
        <button
          onClick={() => setShowBreakdown(!showBreakdown)}
          className="inline-flex items-center gap-2 px-4 md:px-6 py-2 md:py-3 bg-gradient-to-r from-primary-500 to-secondary-500 text-white rounded-lg md:rounded-xl hover:from-primary-600 hover:to-secondary-600 transition-all duration-300 transform hover:scale-105 shadow-lg font-medium text-sm md:text-base"
        >
          {showBreakdown ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          {showBreakdown ? 'Hide Calculation' : 'View Calculation Breakdown'}
        </button>
      </div>

      {/* Detailed Breakdown */}
      {showBreakdown && (
        <div className="space-y-4">
          <h4 className="text-base md:text-lg font-semibold text-gray-900 dark:text-dark-100 mb-4 flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            Score Calculation Breakdown ({scoreData.tier})
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
            {Object.entries(scoreData).slice(0, 11).map(([key, data], index) => {
              const IconComponent = getMetricIcon(key);
              const weight = weights[index];
              const contribution = (weight * data.score / 100).toFixed(1);
              
              return (
                <div
                  key={key}
                  className="bg-white/70 dark:bg-dark-700/70 backdrop-blur-sm rounded-lg md:rounded-xl p-3 md:p-4 border border-gray-200/30 dark:border-dark-600/30"
                >
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-primary-100 dark:bg-primary-900/30 rounded-lg">
                      <IconComponent className="w-4 h-4 md:w-5 md:h-5 text-primary-600 dark:text-primary-400" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h5 className="font-semibold text-gray-900 dark:text-dark-100 text-sm md:text-base">
                          {key}: {data.description}
                        </h5>
                        <span className="text-lg md:text-xl font-bold text-primary-600 dark:text-primary-400">
                          {contribution}
                        </span>
                      </div>
                      
                      <p className="text-xs md:text-sm text-gray-600 dark:text-dark-300 mb-2">
                        {data.actualValue} • Weight: {weight}% • Raw Score: {data.score.toFixed(1)}
                      </p>
                      
                      <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-primary-500 to-secondary-500 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${Math.min(data.score, 100)}%` }}
                        />
                      </div>
                      
                      <div className="flex justify-between text-xs text-gray-500 dark:text-dark-400 mt-1">
                        <span>0</span>
                        <span>100 max</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Formula Explanation */}
          <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-xl border border-blue-200/50 dark:border-blue-700/50">
            <h5 className="font-semibold text-blue-700 dark:text-blue-300 mb-3 flex items-center gap-2">
              <Calculator className="w-5 h-5" />
              How We Calculate Your Score ({scoreData.tier})
            </h5>
            <div className="text-sm text-blue-600 dark:text-blue-400 space-y-2">
              <p><strong>Total Score = Σ(Weight × Metric Score / 100)</strong></p>
              <p><strong>Star Rating = Total Score ÷ 20</strong> (rounded, max 5 stars)</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-3 text-xs">
                <div>• M1: CF Rating ({weights[0]}% weight)</div>
                <div>• M2: Contests Participated ({weights[1]}% weight)</div>
                <div>• M3: Contest Frequency ({weights[2]}% weight)</div>
                <div>• M4: Upsolve Count ({weights[3]}% weight)</div>
                <div>• M5: Total Problems ({weights[4]}% weight)</div>
                <div>• M6: Avg Problem Rating ({weights[5]}% weight)</div>
                <div>• M7: {scoreData.M7.description} ({weights[6]}% weight)</div>
                <div>• M8: Topic Coverage ({weights[7]}% weight)</div>
                <div>• M9: Accuracy ({weights[8]}% weight)</div>
                <div>• M10: Virtual Performance ({weights[9]}% weight)</div>
                <div>• M11: Community Contribution ({weights[10]}% weight)</div>
              </div>
              <div className="mt-3 p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                <p className="font-medium text-blue-800 dark:text-blue-200">
                  🎯 Tier-Specific Weighting: {scoreData.tier} users are evaluated with emphasis on {
                    scoreData.tier.includes('Newbie') || scoreData.tier.includes('Pupil') ? 'participation and growth' :
                    scoreData.tier.includes('Specialist') || scoreData.tier.includes('Expert') ? 'problem solving and consistency' :
                    scoreData.tier.includes('Master') ? 'advanced topics and upsolving' :
                    'elite performance and community impact'
                  }.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}