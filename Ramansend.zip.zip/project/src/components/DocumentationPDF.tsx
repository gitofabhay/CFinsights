import React from 'react';
import { FileText, Download, BookOpen, Star, Users, BarChart3, Activity, Target, Trophy, AlertTriangle, Clock, Zap, Brain, Award, Calendar, Code, TrendingUp, Eye, Calculator, Flame, Skull, ExternalLink } from 'lucide-react';

export function DocumentationPDF() {
  const handleDownloadPDF = () => {
    // Create the documentation content as a string
    const documentationHTML = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CFinsights - Complete Feature Documentation</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #fff;
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .header {
            text-align: center;
            margin-bottom: 40px;
            padding: 30px;
            background: linear-gradient(135deg, #3B82F6, #8B5CF6);
            color: white;
            border-radius: 15px;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            font-weight: bold;
        }
        
        .header p {
            font-size: 1.2em;
            opacity: 0.9;
        }
        
        .toc {
            background: #f8fafc;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 40px;
            border-left: 5px solid #3B82F6;
        }
        
        .toc h2 {
            color: #1e40af;
            margin-bottom: 15px;
            font-size: 1.5em;
        }
        
        .toc ul {
            list-style: none;
            padding-left: 0;
        }
        
        .toc li {
            margin: 8px 0;
            padding: 5px 0;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .toc a {
            color: #3B82F6;
            text-decoration: none;
            font-weight: 500;
        }
        
        .section {
            margin-bottom: 40px;
            page-break-inside: avoid;
        }
        
        .section h2 {
            color: #1e40af;
            font-size: 1.8em;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 3px solid #3B82F6;
        }
        
        .section h3 {
            color: #3730a3;
            font-size: 1.4em;
            margin: 25px 0 15px 0;
        }
        
        .section h4 {
            color: #4338ca;
            font-size: 1.2em;
            margin: 20px 0 10px 0;
        }
        
        .feature-card {
            background: #f1f5f9;
            padding: 20px;
            border-radius: 10px;
            margin: 15px 0;
            border-left: 4px solid #8B5CF6;
        }
        
        .feature-title {
            font-weight: bold;
            color: #4338ca;
            font-size: 1.1em;
            margin-bottom: 8px;
        }
        
        .example {
            background: #ecfdf5;
            padding: 15px;
            border-radius: 8px;
            margin: 10px 0;
            border-left: 4px solid #10b981;
        }
        
        .example-title {
            font-weight: bold;
            color: #047857;
            margin-bottom: 5px;
        }
        
        .code {
            background: #1e293b;
            color: #e2e8f0;
            padding: 10px;
            border-radius: 5px;
            font-family: 'Courier New', monospace;
            margin: 10px 0;
        }
        
        .highlight {
            background: #fef3c7;
            padding: 2px 6px;
            border-radius: 4px;
            font-weight: bold;
        }
        
        .tip {
            background: #dbeafe;
            padding: 15px;
            border-radius: 8px;
            margin: 15px 0;
            border-left: 4px solid #3B82F6;
        }
        
        .tip-title {
            font-weight: bold;
            color: #1e40af;
            margin-bottom: 5px;
        }
        
        .metric-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .metric-item {
            background: white;
            padding: 15px;
            border-radius: 8px;
            border: 2px solid #e5e7eb;
        }
        
        .metric-name {
            font-weight: bold;
            color: #374151;
            margin-bottom: 5px;
        }
        
        .metric-desc {
            font-size: 0.9em;
            color: #6b7280;
        }
        
        .tier-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 0.9em;
        }
        
        .tier-table th,
        .tier-table td {
            border: 1px solid #d1d5db;
            padding: 8px;
            text-align: center;
        }
        
        .tier-table th {
            background: #f3f4f6;
            font-weight: bold;
            color: #374151;
        }
        
        .tier-table tr:nth-child(even) {
            background: #f9fafb;
        }
        
        .footer {
            text-align: center;
            margin-top: 50px;
            padding: 20px;
            background: #f8fafc;
            border-radius: 10px;
            color: #6b7280;
        }
        
        @media print {
            body { padding: 10px; }
            .header { background: #3B82F6 !important; }
            .section { page-break-inside: avoid; }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🚀 CFinsights</h1>
        <p>Complete Feature Documentation</p>
        <p style="font-size: 1em; margin-top: 10px;">Your one stop solution for all things CF</p>
    </div>

    <div class="toc">
        <h2>📋 Table of Contents</h2>
        <ul>
            <li><a href="#overview">1. Overview & Getting Started</a></li>
            <li><a href="#profile-score">2. CFinsights 11-Metric Profile Score System</a></li>
            <li><a href="#solo-features">3. Solo Profile Analysis Features</a></li>
            <li><a href="#comparison-features">4. Comparison Mode Features</a></li>
            <li><a href="#analytics-features">5. Advanced Analytics Features</a></li>
            <li><a href="#practice-features">6. Practice & Improvement Features</a></li>
            <li><a href="#tips">7. Tips & Best Practices</a></li>
        </ul>
    </div>

    <div class="section" id="overview">
        <h2>1. 🌟 Overview & Getting Started</h2>
        
        <div class="feature-card">
            <div class="feature-title">What is CFinsights?</div>
            <p>CFinsights is a comprehensive Codeforces analytics platform that provides deep insights into your competitive programming journey. It analyzes your submissions, contest performance, and problem-solving patterns using an advanced 11-metric scoring system to help you improve.</p>
        </div>

        <h3>🎯 Key Features at a Glance</h3>
        <ul style="margin-left: 20px; margin-top: 10px;">
            <li><strong>11-Metric Profile Score System:</strong> Get a comprehensive score out of 100 based on tier-specific performance metrics</li>
            <li><strong>Solo Analysis:</strong> Deep dive into your individual performance with 25+ analytical features</li>
            <li><strong>Comparison Mode:</strong> Compare two users side-by-side across multiple dimensions</li>
            <li><strong>Practice Recommendations:</strong> Get personalized problem suggestions based on your weak areas</li>
            <li><strong>Visual Analytics:</strong> Beautiful charts and graphs to visualize your progress</li>
            <li><strong>Real-time Data:</strong> Always up-to-date information from Codeforces API</li>
        </ul>

        <h3>🚀 How to Use CFinsights</h3>
        <div class="example">
            <div class="example-title">Step-by-Step Guide:</div>
            <ol style="margin-left: 20px;">
                <li><strong>Enter Handle:</strong> Type your Codeforces username in the search box</li>
                <li><strong>Solo Analysis:</strong> Click "Analyze Profile" to see your individual stats</li>
                <li><strong>Comparison:</strong> Enable "Compare Mode" and enter two usernames to compare</li>
                <li><strong>Explore Features:</strong> Navigate through different sections to explore insights</li>
                <li><strong>Practice:</strong> Use weak topics analysis to get practice problem recommendations</li>
            </ol>
        </div>
    </div>

    <div class="section" id="profile-score">
        <h2>2. 🏆 CFinsights 11-Metric Profile Score System</h2>
        
        <div class="feature-card">
            <div class="feature-title">What is the 11-Metric Profile Score?</div>
            <p>The CFinsights Profile Score is an advanced evaluation system that analyzes your Codeforces performance across 11 comprehensive metrics with tier-specific weighting, giving you a score out of 100 and a star rating (0-5 stars). This system ensures fair evaluation across all skill levels.</p>
        </div>

        <h3>📊 The 11 Core Metrics</h3>
        <div class="metric-grid">
            <div class="metric-item">
                <div class="metric-name">M1: CF Rating (normalized)</div>
                <div class="metric-desc">Official Codeforces rating scaled to 0-100. Higher rating = more points.</div>
            </div>
            <div class="metric-item">
                <div class="metric-name">M2: Contests Participated</div>
                <div class="metric-desc">Total number of rated contests participated in.</div>
            </div>
            <div class="metric-item">
                <div class="metric-name">M3: Contest Frequency & Streaks</div>
                <div class="metric-desc">Recent contest activity and participation consistency.</div>
            </div>
            <div class="metric-item">
                <div class="metric-name">M4: Upsolve Count</div>
                <div class="metric-desc">Problems solved after contests end (practice).</div>
            </div>
            <div class="metric-item">
                <div class="metric-name">M5: Total Problems Solved</div>
                <div class="metric-desc">Combined practice and contest problems solved.</div>
            </div>
            <div class="metric-item">
                <div class="metric-name">M6: Average Problem Rating</div>
                <div class="metric-desc">Average difficulty level of problems you've mastered.</div>
            </div>
            <div class="metric-item">
                <div class="metric-name">M7: Dynamic Tier-Specific Metric</div>
                <div class="metric-desc">Changes based on your rating tier (see tier breakdown below).</div>
            </div>
            <div class="metric-item">
                <div class="metric-name">M8: Tags / Topic Coverage</div>
                <div class="metric-desc">Variety of problem types and algorithms mastered.</div>
            </div>
            <div class="metric-item">
                <div class="metric-name">M9: Accuracy</div>
                <div class="metric-desc">Solved/attempted ratio - efficiency in problem solving.</div>
            </div>
            <div class="metric-item">
                <div class="metric-name">M10: Virtual Contest Performance</div>
                <div class="metric-desc">Performance in virtual contests and practice rounds.</div>
            </div>
            <div class="metric-item">
                <div class="metric-name">M11: Community Contribution</div>
                <div class="metric-desc">Blogs, editorials, problem-setting, and community impact.</div>
            </div>
        </div>

        <h3>🎯 Tier-Specific Dynamic Metric (M7)</h3>
        <div class="example">
            <div class="example-title">M7 Definition by Rating Tier:</div>
            <ul style="margin-left: 20px;">
                <li><strong>< 2100 rating:</strong> Above-rated problems solved (problems harder than your rating)</li>
                <li><strong>2100-2299 (Master):</strong> Hard tag mastery (segment trees, DP on trees, flows)</li>
                <li><strong>2300-2399 (IM):</strong> High-difficulty trend problems (2000+ rating problems)</li>
                <li><strong>2400-2599 (GM):</strong> Elite first-attempt accuracy on 2400+ problems</li>
                <li><strong>2600-2999 (IGM):</strong> Virtual contest accuracy and performance</li>
                <li><strong>3000+ (Tourist Tier):</strong> Community impact metric (problem setting, editorials)</li>
            </ul>
        </div>

        <h3>📐 Tier-Specific Weight Distribution</h3>
        <p>Each rating tier has different weight distributions that emphasize appropriate aspects:</p>
        
        <table class="tier-table">
            <thead>
                <tr>
                    <th>Tier</th>
                    <th>M1</th>
                    <th>M2</th>
                    <th>M3</th>
                    <th>M4</th>
                    <th>M5</th>
                    <th>M6</th>
                    <th>M7</th>
                    <th>M8</th>
                    <th>M9</th>
                    <th>M10</th>
                    <th>M11</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>Newbie (0-1199)</strong></td>
                    <td>15%</td>
                    <td>20%</td>
                    <td>15%</td>
                    <td>10%</td>
                    <td>15%</td>
                    <td>5%</td>
                    <td>8%</td>
                    <td>5%</td>
                    <td>3%</td>
                    <td>2%</td>
                    <td>2%</td>
                </tr>
                <tr>
                    <td><strong>Pupil (1200-1399)</strong></td>
                    <td>15%</td>
                    <td>18%</td>
                    <td>12%</td>
                    <td>12%</td>
                    <td>15%</td>
                    <td>8%</td>
                    <td>10%</td>
                    <td>5%</td>
                    <td>3%</td>
                    <td>1%</td>
                    <td>1%</td>
                </tr>
                <tr>
                    <td><strong>Specialist (1400-1599)</strong></td>
                    <td>12%</td>
                    <td>15%</td>
                    <td>10%</td>
                    <td>15%</td>
                    <td>12%</td>
                    <td>10%</td>
                    <td>12%</td>
                    <td>8%</td>
                    <td>4%</td>
                    <td>1%</td>
                    <td>1%</td>
                </tr>
                <tr>
                    <td><strong>Expert (1600-1899)</strong></td>
                    <td>10%</td>
                    <td>12%</td>
                    <td>8%</td>
                    <td>18%</td>
                    <td>10%</td>
                    <td>12%</td>
                    <td>15%</td>
                    <td>10%</td>
                    <td>3%</td>
                    <td>1%</td>
                    <td>1%</td>
                </tr>
                <tr>
                    <td><strong>Candidate Master (1900-2099)</strong></td>
                    <td>8%</td>
                    <td>10%</td>
                    <td>6%</td>
                    <td>20%</td>
                    <td>8%</td>
                    <td>15%</td>
                    <td>18%</td>
                    <td>10%</td>
                    <td>3%</td>
                    <td>1%</td>
                    <td>1%</td>
                </tr>
                <tr>
                    <td><strong>Master (2100-2299)</strong></td>
                    <td>6%</td>
                    <td>8%</td>
                    <td>5%</td>
                    <td>15%</td>
                    <td>6%</td>
                    <td>18%</td>
                    <td>20%</td>
                    <td>12%</td>
                    <td>5%</td>
                    <td>3%</td>
                    <td>2%</td>
                </tr>
                <tr>
                    <td><strong>International Master (2300-2399)</strong></td>
                    <td>5%</td>
                    <td>6%</td>
                    <td>4%</td>
                    <td>12%</td>
                    <td>5%</td>
                    <td>20%</td>
                    <td>22%</td>
                    <td>15%</td>
                    <td>6%</td>
                    <td>3%</td>
                    <td>2%</td>
                </tr>
                <tr>
                    <td><strong>Grandmaster (2400-2599)</strong></td>
                    <td>4%</td>
                    <td>5%</td>
                    <td>3%</td>
                    <td>10%</td>
                    <td>4%</td>
                    <td>18%</td>
                    <td>25%</td>
                    <td>18%</td>
                    <td>8%</td>
                    <td>3%</td>
                    <td>2%</td>
                </tr>
                <tr>
                    <td><strong>International GM (2600-2999)</strong></td>
                    <td>3%</td>
                    <td>4%</td>
                    <td>2%</td>
                    <td>8%</td>
                    <td>3%</td>
                    <td>15%</td>
                    <td>28%</td>
                    <td>20%</td>
                    <td>10%</td>
                    <td>4%</td>
                    <td>3%</td>
                </tr>
                <tr>
                    <td><strong>Tourist Tier (3000+)</strong></td>
                    <td>2%</td>
                    <td>3%</td>
                    <td>1%</td>
                    <td>6%</td>
                    <td>2%</td>
                    <td>12%</td>
                    <td>30%</td>
                    <td>22%</td>
                    <td>12%</td>
                    <td>5%</td>
                    <td>5%</td>
                </tr>
            </tbody>
        </table>

        <h3>⭐ Star Rating System</h3>
        <div class="example">
            <div class="example-title">Score Ranges & Verdicts:</div>
            <ul style="margin-left: 20px;">
                <li><strong>81-100 points (5 stars):</strong> 🔥 Elite Performer</li>
                <li><strong>61-80 points (4 stars):</strong> 🌟 Strong Performer</li>
                <li><strong>41-60 points (3 stars):</strong> ⚡ On the Rise</li>
                <li><strong>21-40 points (2 stars):</strong> 🛠️ Starting Up</li>
                <li><strong>0-20 points (1 star):</strong> 💤 Needs a Boost</li>
            </ul>
        </div>

        <div class="tip">
            <div class="tip-title">💡 Pro Tip:</div>
            <p>Click "View Calculation Breakdown" to see exactly how each metric contributes to your score. The tier-specific weighting ensures that users are evaluated against appropriate benchmarks for their skill level, making the scoring system fair and motivating for all users!</p>
        </div>
    </div>

    <div class="section" id="solo-features">
        <h2>3. 👤 Solo Profile Analysis Features</h2>

        <h3>📈 Rating & Contest Analysis</h3>
        
        <div class="feature-card">
            <div class="feature-title">Rating Chart</div>
            <p>Visual representation of your rating progress over time with detailed contest information.</p>
            <div class="example">
                <div class="example-title">What you can see:</div>
                <ul style="margin-left: 20px;">
                    <li>Rating progression across all contests</li>
                    <li>Hover over points to see contest details</li>
                    <li>Overall statistics (contests, best rank, average change)</li>
                </ul>
            </div>
        </div>

        <div class="feature-card">
            <div class="feature-title">Contest History</div>
            <p>Detailed list of your recent contests with performance metrics.</p>
            <div class="example">
                <div class="example-title">Information displayed:</div>
                <ul style="margin-left: 20px;">
                    <li>Contest name and date</li>
                    <li>Your rank in the contest</li>
                    <li>Rating before and after</li>
                    <li>Rating change (+/-)</li>
                </ul>
            </div>
        </div>

        <h3>🎯 Problem Analysis</h3>

        <div class="feature-card">
            <div class="feature-title">Problem Rating Distribution</div>
            <p>Comprehensive analysis of the difficulty levels of problems you've solved.</p>
            <div class="example">
                <div class="example-title">Features include:</div>
                <ul style="margin-left: 20px;">
                    <li>Histogram showing problems solved by rating range</li>
                    <li>Difficulty categorization (Very Easy to Very Hard)</li>
                    <li>Comparison with your current rating</li>
                    <li>Statistics on highest solved problem rating</li>
                </ul>
            </div>
        </div>

        <div class="feature-card">
            <div class="feature-title">Problem Tags Analysis</div>
            <p>Breakdown of problem types you've solved, showing your strengths and areas for improvement.</p>
            <div class="example">
                <div class="example-title">What it shows:</div>
                <ul style="margin-left: 20px;">
                    <li>Top 15 most solved problem tags</li>
                    <li>Number of problems solved in each category</li>
                    <li>Visual bar chart representation</li>
                </ul>
            </div>
        </div>

        <h3>📊 Submission Analytics</h3>

        <div class="feature-card">
            <div class="feature-title">Submission Statistics</div>
            <p>Detailed breakdown of your submission patterns and success rates.</p>
            <div class="example">
                <div class="example-title">Metrics included:</div>
                <ul style="margin-left: 20px;">
                    <li>Total submissions vs accepted solutions</li>
                    <li>Acceptance rate percentage</li>
                    <li>Verdict distribution (OK, WA, TLE, etc.)</li>
                    <li>Programming languages used</li>
                </ul>
            </div>
        </div>

        <div class="feature-card">
            <div class="feature-title">Submission Heatmap</div>
            <p>GitHub-style activity heatmap showing your coding consistency over the past year.</p>
            <div class="example">
                <div class="example-title">Visual insights:</div>
                <ul style="margin-left: 20px;">
                    <li>Daily submission activity for 365 days</li>
                    <li>Color intensity based on submission count</li>
                    <li>Current and longest streaks</li>
                    <li>Activity rate and consistency metrics</li>
                </ul>
            </div>
        </div>

        <h3>🏅 Achievement & Progress Tracking</h3>

        <div class="feature-card">
            <div class="feature-title">Profile Badges</div>
            <p>Gamified achievement system with 8 different badges to unlock.</p>
            <div class="example">
                <div class="example-title">Available badges:</div>
                <ul style="margin-left: 20px;">
                    <li><strong>WA King:</strong> 100+ wrong answer submissions</li>
                    <li><strong>Midnight Coder:</strong> 50+ late night submissions</li>
                    <li><strong>Never Give Up:</strong> Solved a problem after 10+ attempts</li>
                    <li><strong>Speed Demon:</strong> 20+ problems solved in ≤1 minute</li>
                    <li><strong>Problem Solver:</strong> 500+ unique problems solved</li>
                    <li><strong>Contest Warrior:</strong> 50+ contest participations</li>
                    <li><strong>Consistent Coder:</strong> Active in last 30 days</li>
                    <li><strong>Rating Climber:</strong> 500+ rating point growth</li>
                </ul>
            </div>
        </div>

        <div class="feature-card">
            <div class="feature-title">Tag Clutch Moments</div>
            <p>Highlights your best performance in each problem category.</p>
            <div class="example">
                <div class="example-title">Shows your:</div>
                <ul style="margin-left: 20px;">
                    <li>Highest-rated problem solved in each topic</li>
                    <li>Peak performance moments</li>
                    <li>Strongest problem-solving areas</li>
                </ul>
            </div>
        </div>

        <h3>📅 Consistency & Time Analysis</h3>

        <div class="feature-card">
            <div class="feature-title">Consistency Index</div>
            <p>Analyzes your weekly coding consistency over the last 6 months.</p>
            <div class="example">
                <div class="example-title">Tracks:</div>
                <ul style="margin-left: 20px;">
                    <li>Weekly submission patterns</li>
                    <li>Current and longest streaks</li>
                    <li>Most productive weeks</li>
                    <li>Consistency rating and goals</li>
                </ul>
            </div>
        </div>

        <div class="feature-card">
            <div class="feature-title">Time Wasted Index</div>
            <p>Analyzes debugging time and WA chains from your last 20 submissions.</p>
            <div class="example">
                <div class="example-title">Identifies:</div>
                <ul style="margin-left: 20px;">
                    <li>Problems that took multiple attempts</li>
                    <li>Time spent on debugging</li>
                    <li>Common error patterns</li>
                    <li>Efficiency improvement suggestions</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="section" id="comparison-features">
        <h2>4. 👥 Comparison Mode Features</h2>

        <div class="feature-card">
            <div class="feature-title">How to Use Comparison Mode</div>
            <p>Enable "Compare Mode" toggle and enter two Codeforces handles to see side-by-side analysis with tier-specific scoring.</p>
        </div>

        <h3>🏆 Advanced Score Comparison</h3>

        <div class="feature-card">
            <div class="feature-title">11-Metric Profile Score Comparison</div>
            <p>Side-by-side comparison of CFinsights Profile Scores with detailed tier-specific breakdown.</p>
            <div class="example">
                <div class="example-title">Features:</div>
                <ul style="margin-left: 20px;">
                    <li>Overall score comparison with winner highlighting</li>
                    <li>Metric-by-metric breakdown showing who excels where</li>
                    <li>Tier-specific weighting explanation</li>
                    <li>Star rating comparison</li>
                    <li>Detailed calculation transparency</li>
                </ul>
            </div>
        </div>

        <h3>📊 Statistical Comparisons</h3>

        <div class="feature-card">
            <div class="feature-title">Rating Progress Comparison</div>
            <p>Visual comparison of rating progression over time.</p>
            <div class="example">
                <div class="example-title">Shows:</div>
                <ul style="margin-left: 20px;">
                    <li>Overlaid rating charts</li>
                    <li>Contest-by-contest comparison</li>
                    <li>Growth rate analysis</li>
                </ul>
            </div>
        </div>

        <div class="feature-card">
            <div class="feature-title">Detailed Statistics Comparison</div>
            <p>Comprehensive comparison across 9 key metrics.</p>
            <div class="example">
                <div class="example-title">Compares:</div>
                <ul style="margin-left: 20px;">
                    <li>Current and max ratings</li>
                    <li>Contest participation</li>
                    <li>Problems solved</li>
                    <li>Acceptance rates</li>
                    <li>Best and worst ranks</li>
                    <li>Rating growth and average changes</li>
                </ul>
            </div>
        </div>

        <h3>🎯 Advanced Comparison Features</h3>

        <div class="feature-card">
            <div class="feature-title">After X Contests Analysis</div>
            <p>Compare performance after a specific number of contests (5, 10, 15, 20, 25, 30, 50).</p>
            <div class="example">
                <div class="example-title">Analyzes:</div>
                <ul style="margin-left: 20px;">
                    <li>Rating after X contests</li>
                    <li>Problems solved in that timeframe</li>
                    <li>Acceptance rates and submission counts</li>
                    <li>Average rating changes and ranks</li>
                    <li>Rating progression charts</li>
                    <li>Comprehensive milestone summaries</li>
                </ul>
            </div>
        </div>

        <div class="feature-card">
            <div class="feature-title">Problem Type Comparison</div>
            <p>Detailed comparison of problem-solving patterns and preferences.</p>
            <div class="example">
                <div class="example-title">Includes:</div>
                <ul style="margin-left: 20px;">
                    <li>Tag-wise problem solving comparison</li>
                    <li>Difficulty distribution pie charts</li>
                    <li>Programming language preferences</li>
                    <li>Rating progression in specific topics</li>
                </ul>
            </div>
        </div>

        <div class="feature-card">
            <div class="feature-title">Difficulty Level Comparison</div>
            <p>Comprehensive table comparing performance across difficulty levels.</p>
            <div class="example">
                <div class="example-title">Shows:</div>
                <ul style="margin-left: 20px;">
                    <li>Problems solved in each difficulty range</li>
                    <li>Who leads in each category</li>
                    <li>Detailed breakdown with rating ranges</li>
                    <li>Overall assessment of strengths</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="section" id="analytics-features">
        <h2>5. 📈 Advanced Analytics Features</h2>

        <h3>🚨 Failure Analysis</h3>

        <div class="feature-card">
            <div class="feature-title">Failure Dashboard</div>
            <p>Comprehensive analysis of your failed submissions to identify improvement areas.</p>
            <div class="example">
                <div class="example-title">Analyzes:</div>
                <ul style="margin-left: 20px;">
                    <li>Topic-based failure patterns</li>
                    <li>Error type distribution (WA, TLE, MLE, etc.)</li>
                    <li>Failed problems by rating range</li>
                    <li>Specific advice for each error type</li>
                    <li>Action plan recommendations</li>
                </ul>
            </div>
        </div>

        <div class="feature-card">
            <div class="feature-title">Undefeated Problems</div>
            <p>Tracks problems you've attempted multiple times but haven't solved yet.</p>
            <div class="example">
                <div class="example-title">Identifies:</div>
                <ul style="margin-left: 20px;">
                    <li>Problems with 7+ failed attempts</li>
                    <li>Time spent fighting each problem</li>
                    <li>Most common error types</li>
                    <li>Submission patterns and strategies to try</li>
                </ul>
            </div>
        </div>

        <div class="feature-card">
            <div class="feature-title">Unsolved Problems</div>
            <p>Recent problems you attempted but haven't solved, with direct links to try again. <strong>Fixed:</strong> Now properly filters out problems that were eventually solved.</p>
            <div class="example">
                <div class="example-title">Shows only truly unsolved problems:</div>
                <ul style="margin-left: 20px;">
                    <li>Problems with failed attempts but no AC</li>
                    <li>Most recent failed attempt details</li>
                    <li>Direct links to retry the problems</li>
                    <li>Encouragement and tips for improvement</li>
                </ul>
            </div>
        </div>

        <h3>🎯 Performance Insights</h3>

        <div class="feature-card">
            <div class="feature-title">Improvement Suggestions</div>
            <p>Personalized recommendations based on your submission patterns and performance.</p>
            <div class="example">
                <div class="example-title">Provides:</div>
                <ul style="margin-left: 20px;">
                    <li>Analysis of problems requiring multiple attempts</li>
                    <li>Specific practice plans with timelines</li>
                    <li>Learning path recommendations</li>
                    <li>Strategic approach suggestions</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="section" id="practice-features">
        <h2>6. 🎯 Practice & Improvement Features</h2>

        <h3>📚 Weak Topics Analysis</h3>

        <div class="feature-card">
            <div class="feature-title">Weak Topics Identification</div>
            <p>Analyzes your last 50 failed submissions to identify topics where you struggle most.</p>
            <div class="example">
                <div class="example-title">Features:</div>
                <ul style="margin-left: 20px;">
                    <li>Top 5 problematic topics</li>
                    <li>Failure percentage in each topic</li>
                    <li>Number of failed attempts per topic</li>
                </ul>
            </div>
        </div>

        <div class="feature-card">
            <div class="feature-title">Practice Problem Recommendations</div>
            <p>Click "Practice" on any weak topic to get curated problem suggestions.</p>
            <div class="example">
                <div class="example-title">Provides:</div>
                <ul style="margin-left: 20px;">
                    <li>10 carefully selected problems (rating 800-1700)</li>
                    <li>Problems sorted by difficulty and solve count</li>
                    <li>Direct links to solve on Codeforces</li>
                    <li>Strategic practice approach</li>
                </ul>
            </div>
        </div>

        <h3>📈 Learning Path Recommendations</h3>

        <div class="feature-card">
            <div class="feature-title">Recommended Learning Path</div>
            <p>Personalized progression suggestions based on topics you've already mastered.</p>
            <div class="example">
                <div class="example-title">Suggests transitions like:</div>
                <ul style="margin-left: 20px;">
                    <li>Implementation → Greedy, Constructive Algorithms</li>
                    <li>Brute Force → Two Pointers, Binary Search</li>
                    <li>Math → Number Theory, Combinatorics</li>
                    <li>Greedy → DP, Graphs</li>
                </ul>
            </div>
        </div>

        <h3>📅 Upcoming Contests</h3>

        <div class="feature-card">
            <div class="feature-title">Contest Information</div>
            <p>Stay updated with upcoming Codeforces contests.</p>
            <div class="example">
                <div class="example-title">Shows:</div>
                <ul style="margin-left: 20px;">
                    <li>Next 5 upcoming contests</li>
                    <li>Start time in your local timezone</li>
                    <li>Contest duration</li>
                    <li>Time remaining until start</li>
                    <li>Direct links to contest pages</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="section" id="tips">
        <h2>7. 💡 Tips & Best Practices</h2>

        <h3>🎯 Getting the Most Out of CFinsights</h3>

        <div class="tip">
            <div class="tip-title">Regular Analysis</div>
            <p>Check your profile weekly to track progress and identify new weak areas. The platform updates in real-time with your latest submissions.</p>
        </div>

        <div class="tip">
            <div class="tip-title">Focus on Weak Topics</div>
            <p>Use the weak topics analysis to prioritize your practice. Solving problems in your weak areas will have the biggest impact on your overall performance.</p>
        </div>

        <div class="tip">
            <div class="tip-title">Track Your Score</div>
            <p>Monitor your CFinsights Profile Score over time. Aim to improve specific metrics rather than just the overall score. The tier-specific weighting ensures fair evaluation.</p>
        </div>

        <div class="tip">
            <div class="tip-title">Use Comparison Mode</div>
            <p>Compare yourself with friends or target users to understand where you stand and what areas need improvement. The tier-specific scoring makes comparisons fair across skill levels.</p>
        </div>

        <div class="tip">
            <div class="tip-title">Practice Consistently</div>
            <p>Use the consistency index to maintain regular coding habits. Aim for at least 3-4 active days per week.</p>
        </div>

        <h3>🚀 Improving Your 11-Metric Profile Score</h3>

        <div class="example">
            <div class="example-title">Quick Wins by Tier:</div>
            <ul style="margin-left: 20px;">
                <li><strong>Newbie/Pupil:</strong> Focus on contest participation (M2, M3) and solving more problems (M5)</li>
                <li><strong>Specialist/Expert:</strong> Emphasize upsolving (M4) and solving above-rated problems (M7)</li>
                <li><strong>Candidate Master+:</strong> Work on hard tag mastery (M7) and community contribution (M11)</li>
                <li><strong>Master+:</strong> Focus on elite problem accuracy (M7) and virtual contests (M10)</li>
            </ul>
        </div>

        <div class="example">
            <div class="example-title">Universal Improvements:</div>
            <ul style="margin-left: 20px;">
                <li><strong>M8 (Topic Coverage):</strong> Solve problems in new topics you haven't tried</li>
                <li><strong>M9 (Accuracy):</strong> Test your solutions thoroughly before submitting</li>
                <li><strong>M6 (Problem Rating):</strong> Gradually solve harder problems</li>
                <li><strong>M4 (Upsolving):</strong> Solve contest problems after contests end</li>
            </ul>
        </div>

        <h3>🔧 Troubleshooting</h3>

        <div class="tip">
            <div class="tip-title">Handle Not Found</div>
            <p>Make sure you're entering the exact Codeforces username. The system is case-sensitive and requires exact matches.</p>
        </div>

        <div class="tip">
            <div class="tip-title">Loading Issues</div>
            <p>If data takes time to load, it's because we're fetching real-time information from Codeforces. Please wait a moment for complete analysis.</p>
        </div>

        <div class="tip">
            <div class="tip-title">Missing Features</div>
            <p>Some features require minimum data (e.g., contest history for rating analysis). New accounts might not have all features available immediately.</p>
        </div>

        <div class="tip">
            <div class="tip-title">Score Calculation</div>
            <p>The 11-metric system uses tier-specific weighting, so users at different skill levels are evaluated fairly. Your score reflects performance relative to your tier's expectations.</p>
        </div>
    </div>

    <div class="footer">
        <p><strong>CFinsights</strong> - Your one stop solution for all things CF</p>
        <p>Made with ❤️ by Abhay | © 2024</p>
        <p style="margin-top: 10px; font-size: 0.9em;">
            For support: <a href="mailto:flmkzr@gmail.com" style="color: #3B82F6;">flmkzr@gmail.com</a> | 
            Follow updates: <a href="https://twitter.com/letmecodeee" style="color: #3B82F6;">@letmecodeee</a>
        </p>
        <p style="margin-top: 10px; font-size: 0.8em; color: #9ca3af;">
            <strong>Latest Update:</strong> Implemented advanced 11-metric scoring system with tier-specific weighting for fair evaluation across all skill levels.
        </p>
    </div>
</body>
</html>`;

    // Create a blob with the HTML content
    const blob = new Blob([documentationHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    
    // Open in new window
    const printWindow = window.open(url, '_blank');
    
    if (printWindow) {
      // Wait for content to load, then trigger print
      printWindow.onload = () => {
        setTimeout(() => {
          printWindow.print();
          // Clean up the blob URL after a delay
          setTimeout(() => {
            URL.revokeObjectURL(url);
          }, 1000);
        }, 500);
      };
    } else {
      // Fallback: create a downloadable file
      const link = document.createElement('a');
      link.href = url;
      link.download = 'CFinsights-Documentation.html';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-xl md:rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
      <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 md:mb-6 flex items-center gap-2">
        <BookOpen className="w-5 h-5 md:w-6 md:h-6 text-primary-500" />
        <span className="text-sm md:text-base">Complete Feature Documentation</span>
      </h3>

      <div className="text-center space-y-4">
        <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-xl border border-blue-200/50 dark:border-blue-700/50">
          <FileText className="w-12 h-12 mx-auto mb-3 text-blue-500" />
          <h4 className="text-lg font-semibold text-blue-700 dark:text-blue-300 mb-2">
            📚 Comprehensive Guide
          </h4>
          <p className="text-blue-600 dark:text-blue-400 text-sm md:text-base">
            Detailed documentation covering all 25+ features of CFinsights including the new 11-metric scoring system with tier-specific weighting, examples, and best practices.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-lg p-3 border border-green-200/50 dark:border-green-700/50">
            <h5 className="font-semibold text-green-700 dark:text-green-300 mb-2">📖 What's Included:</h5>
            <ul className="text-green-600 dark:text-green-400 space-y-1 text-xs md:text-sm">
              <li>• 11-metric scoring system explanation</li>
              <li>• Tier-specific weight distribution table</li>
              <li>• Complete feature explanations</li>
              <li>• Step-by-step usage guides</li>
              <li>• Real-world examples</li>
              <li>• Tips & best practices</li>
            </ul>
          </div>

          <div className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-lg p-3 border border-purple-200/50 dark:border-purple-700/50">
            <h5 className="font-semibold text-purple-700 dark:text-purple-300 mb-2">🎯 Perfect For:</h5>
            <ul className="text-purple-600 dark:text-purple-400 space-y-1 text-xs md:text-sm">
              <li>• Understanding the new scoring system</li>
              <li>• New users getting started</li>
              <li>• Maximizing your profile score</li>
              <li>• Understanding tier-specific metrics</li>
              <li>• Troubleshooting issues</li>
            </ul>
          </div>
        </div>

        <button
          onClick={handleDownloadPDF}
          className="inline-flex items-center gap-2 px-6 md:px-8 py-3 md:py-4 bg-gradient-to-r from-primary-500 to-secondary-500 text-white rounded-lg md:rounded-xl hover:from-primary-600 hover:to-secondary-600 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl font-semibold text-sm md:text-base"
        >
          <Download className="w-4 h-4 md:w-5 md:h-5" />
          Download Complete Documentation (PDF)
        </button>

        <div className="text-xs md:text-sm text-gray-500 dark:text-dark-400 space-y-1">
          <p>📄 Comprehensive 20+ page guide covering all features</p>
          <p>🔥 <strong>NEW:</strong> Includes detailed 11-metric scoring system documentation</p>
          <p>🖨️ Print-friendly format with detailed explanations</p>
          <p>💡 Includes tips, examples, and troubleshooting</p>
        </div>
      </div>
    </div>
  );
}