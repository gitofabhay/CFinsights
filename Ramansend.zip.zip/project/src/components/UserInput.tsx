import React, { useState } from 'react';
import { Search, Users, X, Sparkles } from 'lucide-react';

interface UserInputProps {
  onSubmit: (handles: string[]) => void;
  loading: boolean;
}

export function UserInput({ onSubmit, loading }: UserInputProps) {
  const [handles, setHandles] = useState<string[]>(['']);
  const [isComparison, setIsComparison] = useState(false);

  const handleInputChange = (index: number, value: string) => {
    const newHandles = [...handles];
    newHandles[index] = value.trim();
    setHandles(newHandles);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validHandles = handles.filter(handle => handle.length > 0);
    if (validHandles.length > 0) {
      onSubmit(validHandles);
    }
  };

  const toggleComparison = () => {
    setIsComparison(!isComparison);
    if (!isComparison) {
      if (handles.length === 1) {
        setHandles([...handles, '']);
      }
    } else {
      setHandles([handles[0] || '']);
    }
  };

  const removeHandle = (index: number) => {
    if (handles.length > 1) {
      const newHandles = handles.filter((_, i) => i !== index);
      setHandles(newHandles);
      if (newHandles.length === 1) {
        setIsComparison(false);
      }
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl md:rounded-3xl shadow-2xl p-4 md:p-8 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
        <div className="text-center mb-6 md:mb-8">
          <div className="flex items-center justify-center mb-3 md:mb-4">
            <div className="p-2 md:p-3 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-xl md:rounded-2xl shadow-lg animate-glow">
              <Sparkles className="w-6 h-6 md:w-8 md:h-8 text-white" />
            </div>
          </div>
          <h1 className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-primary-600 via-secondary-600 to-primary-600 dark:from-primary-400 dark:via-secondary-400 dark:to-primary-400 bg-clip-text text-transparent mb-2">
            CFinsights
          </h1>
          <p className="text-gray-600 dark:text-dark-300 text-sm md:text-lg px-4">
            Your one stop solution for all things CF
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 md:space-y-6">
          <div className="space-y-3 md:space-y-4">
            {handles.map((handle, index) => (
              <div key={index} className="relative group">
                <div className="flex items-center space-x-2 md:space-x-3">
                  <div className="relative flex-1">
                    <div className="absolute left-3 md:left-4 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-dark-400 z-10">
                      <Search className="w-4 h-4 md:w-5 md:h-5" />
                    </div>
                    <input
                      type="text"
                      value={handle}
                      onChange={(e) => handleInputChange(index, e.target.value)}
                      placeholder={`Enter Codeforces handle ${index + 1}${index === 0 ? ' (e.g., tourist, Benq)' : ''}`}
                      className="w-full pl-10 md:pl-12 pr-3 md:pr-4 py-3 md:py-4 border-2 border-gray-200 dark:border-dark-600 rounded-lg md:rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 dark:bg-dark-700/70 dark:text-dark-100 transition-all duration-300 text-sm md:text-lg placeholder-gray-400 dark:placeholder-dark-400 group-hover:border-primary-300 dark:group-hover:border-primary-600 dark:focus:bg-dark-700/90"
                      disabled={loading}
                    />
                    <div className="absolute inset-0 rounded-lg md:rounded-xl bg-gradient-to-r from-primary-500/10 to-secondary-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
                  </div>
                  {handles.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeHandle(index)}
                      className="p-2 md:p-3 text-error-500 hover:bg-error-50 dark:hover:bg-error-900/30 rounded-lg md:rounded-xl transition-all duration-200 hover:scale-105"
                      disabled={loading}
                    >
                      <X className="w-4 h-4 md:w-5 md:h-5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2 md:pt-4">
            <button
              type="button"
              onClick={toggleComparison}
              className={`flex items-center space-x-2 md:space-x-3 px-4 md:px-6 py-2 md:py-3 rounded-lg md:rounded-xl transition-all duration-300 font-medium text-sm md:text-base w-full sm:w-auto justify-center ${
                isComparison
                  ? 'bg-gradient-to-r from-secondary-500 to-primary-500 text-white shadow-lg hover:shadow-xl transform hover:scale-105'
                  : 'bg-gray-100 text-gray-700 dark:bg-dark-700 dark:text-dark-200 hover:bg-gray-200 dark:hover:bg-dark-600'
              }`}
              disabled={loading}
            >
              <Users className="w-4 h-4 md:w-5 md:h-5" />
              <span>{isComparison ? 'Compare Mode Active' : 'Enable Compare Mode'}</span>
            </button>

            <button
              type="submit"
              disabled={loading || handles.every(h => h.length === 0)}
              className="group relative px-6 md:px-8 py-3 md:py-4 bg-gradient-to-r from-primary-500 via-secondary-500 to-primary-500 text-white rounded-lg md:rounded-xl hover:from-primary-600 hover:via-secondary-600 hover:to-primary-600 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 shadow-lg hover:shadow-xl font-semibold text-sm md:text-lg w-full sm:w-auto"
            >
              <div className="flex items-center justify-center space-x-2">
                <Search className="w-4 h-4 md:w-5 md:h-5" />
                <span>{loading ? 'Analyzing...' : 'Analyze Profiles'}</span>
              </div>
              {!loading && (
                <div className="absolute inset-0 rounded-lg md:rounded-xl bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}