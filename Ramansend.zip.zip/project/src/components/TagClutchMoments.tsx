import React from 'react';
import { Trophy, Star, Target, ExternalLink } from 'lucide-react';
import { Submission } from '../types/codeforces';

interface TagClutchMomentsProps {
  submissions: Submission[];
}

interface ClutchMoment {
  tag: string;
  problem: any;
  rating: number;
  contestId?: number;
  index: string;
  name: string;
}

export function TagClutchMoments({ submissions }: TagClutchMomentsProps) {
  // Get highest-rated problem solved in each tag
  const getClutchMoments = (): ClutchMoment[] => {
    const tagBestProblems = new Map<string, ClutchMoment>();
    
    submissions
      .filter(s => s.verdict === 'OK' && s.problem.rating)
      .forEach(submission => {
        submission.problem.tags.forEach(tag => {
          const current = tagBestProblems.get(tag);
          if (!current || submission.problem.rating! > current.rating) {
            tagBestProblems.set(tag, {
              tag,
              problem: submission.problem,
              rating: submission.problem.rating!,
              contestId: submission.problem.contestId,
              index: submission.problem.index,
              name: submission.problem.name
            });
          }
        });
      });

    return Array.from(tagBestProblems.values())
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 12); // Top 12 clutch moments
  };

  const clutchMoments = getClutchMoments();

  const getTagIcon = (tag: string) => {
    const iconMap: Record<string, string> = {
      'dp': '🧠',
      'greedy': '🎯',
      'math': '🧮',
      'implementation': '⚙️',
      'graphs': '🕸️',
      'data structures': '📊',
      'strings': '📝',
      'geometry': '📐',
      'number theory': '🔢',
      'combinatorics': '🎲',
      'binary search': '🔍',
      'two pointers': '👆',
      'sortings': '📈',
      'brute force': '💪',
      'constructive algorithms': '🏗️',
      'trees': '🌳',
      'dfs and similar': '🔄',
      'bfs': '🌊',
      'shortest paths': '🛤️',
      'flows': '💧'
    };
    return iconMap[tag] || '⭐';
  };

  const getRatingColor = (rating: number) => {
    if (rating < 1400) return 'text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/30 border-green-200 dark:border-green-700';
    if (rating < 1700) return 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30 border-blue-200 dark:border-blue-700';
    if (rating < 2100) return 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/30 border-amber-200 dark:border-amber-700';
    return 'text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/30 border-red-200 dark:border-red-700';
  };

  if (clutchMoments.length === 0) {
    return (
      <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-xl md:rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50">
        <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 flex items-center gap-2">
          <Trophy className="w-5 h-5 md:w-6 md:h-6 text-warning-500" />
          <span className="text-sm md:text-base">Tag Clutch Moments</span>
        </h3>
        <div className="text-center py-6 md:py-8 text-gray-500 dark:text-dark-400">
          <Star className="w-10 h-10 md:w-12 md:h-12 mx-auto mb-3 text-gray-300 dark:text-dark-600" />
          <p className="text-base md:text-lg font-medium mb-1">No clutch moments yet!</p>
          <p className="text-xs md:text-sm">Solve more problems to see your peak performance in each topic</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-xl md:rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
      <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 md:mb-6 flex items-center gap-2">
        <Trophy className="w-5 h-5 md:w-6 md:h-6 text-warning-500" />
        <span className="text-sm md:text-base">Tag Clutch Moments</span>
        <span className="text-xs md:text-sm font-normal text-gray-500 dark:text-dark-400 ml-2">
          Your highest-rated solve in each topic
        </span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
        {clutchMoments.map((moment, index) => (
          <div
            key={moment.tag}
            className={`${getRatingColor(moment.rating)} rounded-lg md:rounded-xl p-3 md:p-4 border transition-all duration-300 hover:shadow-lg hover:scale-105`}
          >
            <div className="flex items-start justify-between mb-2 md:mb-3">
              <div className="flex items-center gap-2">
                <span className="text-lg md:text-xl">{getTagIcon(moment.tag)}</span>
                <div className="min-w-0 flex-1">
                  <h4 className="font-semibold text-xs md:text-sm text-gray-900 dark:text-dark-100 truncate">
                    {moment.tag.replace(/_/g, ' ').toUpperCase()}
                  </h4>
                  {index < 3 && (
                    <div className="flex items-center gap-1 mt-1">
                      <Star className="w-3 h-3 text-yellow-500" />
                      <span className="text-xs text-yellow-600 dark:text-yellow-400 font-medium">
                        Top {index + 1}
                      </span>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="text-right">
                <div className="text-lg md:text-xl font-bold">
                  {moment.rating}
                </div>
                <div className="text-xs text-gray-600 dark:text-dark-300">
                  rating
                </div>
              </div>
            </div>

            <div className="mb-2 md:mb-3">
              <h5 className="font-medium text-xs md:text-sm text-gray-900 dark:text-dark-100 line-clamp-2 mb-1">
                {moment.contestId}{moment.index}. {moment.name}
              </h5>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1">
                <Target className="w-3 h-3 md:w-4 md:h-4" />
                <span className="text-xs text-gray-600 dark:text-dark-300">
                  Peak performance
                </span>
              </div>
              
              {moment.contestId && (
                <a
                  href={`https://codeforces.com/problemset/problem/${moment.contestId}/${moment.index}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1 text-gray-400 hover:text-primary-500 transition-colors"
                  title="View problem"
                >
                  <ExternalLink className="w-3 h-3 md:w-4 md:h-4" />
                </a>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 md:mt-6 p-3 md:p-4 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 rounded-lg md:rounded-xl border border-yellow-200/50 dark:border-yellow-700/50">
        <div className="flex items-start gap-2 md:gap-3">
          <Trophy className="w-4 h-4 md:w-5 md:h-5 text-yellow-500 mt-0.5" />
          <div>
            <h4 className="font-semibold text-yellow-700 dark:text-yellow-300 mb-1 text-sm md:text-base">
              Your Peak Moments:
            </h4>
            <p className="text-xs md:text-sm text-yellow-600 dark:text-yellow-400">
              These represent your highest-rated successful solve in each topic. 
              {clutchMoments.length > 0 && ` Your strongest area is ${clutchMoments[0].tag.replace(/_/g, ' ')} with a ${clutchMoments[0].rating} rating solve!`}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}