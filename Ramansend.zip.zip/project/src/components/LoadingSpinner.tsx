import React from 'react';
import { Loader2, Code } from 'lucide-react';

interface LoadingSpinnerProps {
  message?: string;
  size?: 'sm' | 'md' | 'lg';
}

export function LoadingSpinner({ message = 'Loading...', size = 'md' }: LoadingSpinnerProps) {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-8 h-8',
    lg: 'w-12 h-12'
  };

  return (
    <div className="flex flex-col items-center justify-center p-12 space-y-6">
      <div className="relative">
        <div className="absolute inset-0 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 opacity-20 animate-pulse-slow" />
        <div className="relative p-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-full shadow-xl">
          <Loader2 className={`${sizeClasses[size]} animate-spin text-primary-500`} />
        </div>
      </div>
      
      <div className="text-center space-y-2 max-w-md">
        <p className="text-gray-700 dark:text-gray-300 font-medium text-lg">{message}</p>
        <div className="flex items-center justify-center space-x-2 text-sm text-gray-500 dark:text-gray-400">
          <Code className="w-4 h-4" />
          <span>Fetching from Codeforces API...</span>
        </div>
      </div>
    </div>
  );
}