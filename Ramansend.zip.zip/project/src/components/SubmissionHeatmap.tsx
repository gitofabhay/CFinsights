import React, { useState } from 'react';
import { Calendar, Activity, TrendingUp, Target } from 'lucide-react';
import { Submission } from '../types/codeforces';
import { format, fromUnixTime, startOfDay, eachDayOfInterval, subYears, getDay, startOfWeek, endOfWeek, addWeeks } from 'date-fns';

interface SubmissionHeatmapProps {
  submissions: Submission[];
}

interface DayData {
  date: Date;
  count: number;
  dateStr: string;
}

export function SubmissionHeatmap({ submissions }: SubmissionHeatmapProps) {
  const [selectedDay, setSelectedDay] = useState<DayData | null>(null);

  // Get submissions from the last year
  const today = new Date();
  const oneYearAgo = subYears(today, 1);
  
  // Group submissions by day
  const submissionsByDay = new Map<string, number>();
  submissions.forEach(submission => {
    try {
      const date = format(fromUnixTime(submission.creationTimeSeconds), 'yyyy-MM-dd');
      const submissionDate = fromUnixTime(submission.creationTimeSeconds);
      
      // Only include submissions from the last year
      if (submissionDate >= oneYearAgo && submissionDate <= today) {
        submissionsByDay.set(date, (submissionsByDay.get(date) || 0) + 1);
      }
    } catch (error) {
      console.error('Error processing submission date:', submission.creationTimeSeconds, error);
    }
  });

  // Create a grid of weeks (similar to GitHub's contribution graph)
  const weeks: DayData[][] = [];
  const startDate = startOfWeek(oneYearAgo, { weekStartsOn: 0 }); // Start on Sunday
  const endDate = endOfWeek(today, { weekStartsOn: 0 });
  
  let currentWeekStart = startDate;
  
  while (currentWeekStart <= endDate) {
    const week: DayData[] = [];
    
    for (let dayOffset = 0; dayOffset < 7; dayOffset++) {
      const currentDay = new Date(currentWeekStart);
      currentDay.setDate(currentDay.getDate() + dayOffset);
      
      const dateStr = format(currentDay, 'yyyy-MM-dd');
      const count = submissionsByDay.get(dateStr) || 0;
      
      week.push({
        date: currentDay,
        count,
        dateStr
      });
    }
    
    weeks.push(week);
    currentWeekStart = addWeeks(currentWeekStart, 1);
  }

  // Calculate statistics
  const maxSubmissions = Math.max(...Array.from(submissionsByDay.values()), 1);
  const totalSubmissions = Array.from(submissionsByDay.values()).reduce((sum, count) => sum + count, 0);
  const activeDays = submissionsByDay.size;
  const currentStreak = getCurrentStreak();
  const longestStreak = getLongestStreak();

  function getCurrentStreak(): number {
    let streak = 0;
    let currentDate = new Date(today);
    
    while (currentDate >= oneYearAgo) {
      const dateStr = format(currentDate, 'yyyy-MM-dd');
      if (submissionsByDay.has(dateStr)) {
        streak++;
      } else {
        break;
      }
      currentDate.setDate(currentDate.getDate() - 1);
    }
    
    return streak;
  }

  function getLongestStreak(): number {
    let maxStreak = 0;
    let currentStreak = 0;
    let currentDate = new Date(oneYearAgo);
    
    while (currentDate <= today) {
      const dateStr = format(currentDate, 'yyyy-MM-dd');
      if (submissionsByDay.has(dateStr)) {
        currentStreak++;
        maxStreak = Math.max(maxStreak, currentStreak);
      } else {
        currentStreak = 0;
      }
      currentDate.setDate(currentDate.getDate() + 1);
    }
    
    return maxStreak;
  }

  // Get color intensity based on submission count (GitHub-style)
  const getIntensity = (count: number): number => {
    if (count === 0) return 0;
    if (count <= maxSubmissions * 0.25) return 1;
    if (count <= maxSubmissions * 0.5) return 2;
    if (count <= maxSubmissions * 0.75) return 3;
    return 4;
  };

  // Codeforces-style colors (light gray to deep green)
  const getColorClass = (intensity: number): string => {
    const colors = [
      'bg-gray-100 dark:bg-dark-800 border-gray-200 dark:border-dark-700', // No submissions
      'bg-green-100 dark:bg-green-900/40 border-green-200 dark:border-green-800', // Low
      'bg-green-300 dark:bg-green-700/60 border-green-400 dark:border-green-600', // Medium-low
      'bg-green-500 dark:bg-green-600/80 border-green-600 dark:border-green-500', // Medium-high
      'bg-green-700 dark:bg-green-500 border-green-800 dark:border-green-400', // High
    ];
    return colors[intensity];
  };

  const handleDayClick = (dayData: DayData) => {
    if (dayData.count > 0) {
      // In a real implementation, you could open a modal or navigate to show submissions for that day
      window.open(`https://codeforces.com/submissions/${dayData.dateStr}`, '_blank');
    }
  };

  const handleDayHover = (dayData: DayData) => {
    setSelectedDay(dayData);
  };

  const handleDayLeave = () => {
    setSelectedDay(null);
  };

  // Month labels
  const monthLabels = [];
  let currentMonth = new Date(startDate);
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  for (let weekIndex = 0; weekIndex < weeks.length; weekIndex += 4) {
    if (weekIndex < weeks.length) {
      const weekDate = weeks[weekIndex][0].date;
      monthLabels.push({
        index: weekIndex,
        label: monthNames[weekDate.getMonth()]
      });
    }
  }

  return (
    <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
      <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 md:mb-6 flex items-center gap-2">
        <Activity className="w-5 h-5 md:w-6 md:h-6 text-success-500" />
        <span className="text-sm md:text-base">Submission Activity</span>
      </h3>
      
      {/* Statistics */}
      <div className="mb-4 md:mb-6 grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4 text-xs md:text-sm">
        <div className="text-center p-2 md:p-3 bg-primary-50 dark:bg-primary-900/30 rounded-lg border dark:border-primary-800/50">
          <div className="text-lg md:text-2xl font-bold text-primary-600 dark:text-primary-400">{totalSubmissions}</div>
          <div className="text-gray-600 dark:text-dark-300 text-xs">Total Submissions</div>
        </div>
        <div className="text-center p-2 md:p-3 bg-success-50 dark:bg-success-900/30 rounded-lg border dark:border-success-800/50">
          <div className="text-lg md:text-2xl font-bold text-success-600 dark:text-success-400">{activeDays}</div>
          <div className="text-gray-600 dark:text-dark-300 text-xs">Active Days</div>
        </div>
        <div className="text-center p-2 md:p-3 bg-warning-50 dark:bg-warning-900/30 rounded-lg border dark:border-warning-800/50">
          <div className="text-lg md:text-2xl font-bold text-warning-600 dark:text-warning-400">{currentStreak}</div>
          <div className="text-gray-600 dark:text-dark-300 text-xs">Current Streak</div>
        </div>
        <div className="text-center p-2 md:p-3 bg-secondary-50 dark:bg-secondary-900/30 rounded-lg border dark:border-secondary-800/50">
          <div className="text-lg md:text-2xl font-bold text-secondary-600 dark:text-secondary-400">{longestStreak}</div>
          <div className="text-gray-600 dark:text-dark-300 text-xs">Longest Streak</div>
        </div>
      </div>

      {/* Heatmap */}
      <div className="relative overflow-x-auto">
        {/* Month labels */}
        <div className="flex mb-2 text-xs text-gray-500 dark:text-dark-400 min-w-max">
          {monthLabels.map((month, index) => (
            <div
              key={index}
              className="flex-shrink-0"
              style={{ 
                marginLeft: index === 0 ? '20px' : '0',
                width: '52px',
                textAlign: 'left'
              }}
            >
              {month.label}
            </div>
          ))}
        </div>

        {/* Day labels and heatmap grid */}
        <div className="flex min-w-max">
          <div className="flex flex-col text-xs text-gray-500 dark:text-dark-400 mr-2">
            <div className="h-3"></div> {/* Spacer for month labels */}
            <div className="h-3 flex items-center">Mon</div>
            <div className="h-3"></div>
            <div className="h-3 flex items-center">Wed</div>
            <div className="h-3"></div>
            <div className="h-3 flex items-center">Fri</div>
            <div className="h-3"></div>
          </div>

          {/* Heatmap grid */}
          <div className="flex gap-1">
            {weeks.map((week, weekIndex) => (
              <div key={weekIndex} className="flex flex-col gap-1">
                {week.map((day, dayIndex) => {
                  const intensity = getIntensity(day.count);
                  const isToday = format(day.date, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd');
                  const isFutureDate = day.date > today;
                  
                  return (
                    <div
                      key={`${weekIndex}-${dayIndex}`}
                      className={`
                        w-3 h-3 rounded-sm border cursor-pointer transition-all duration-200 hover:scale-125 hover:z-10 relative
                        ${isFutureDate ? 'bg-gray-50 dark:bg-dark-900 border-gray-200 dark:border-dark-700 cursor-default' : getColorClass(intensity)}
                        ${isToday ? 'ring-2 ring-primary-500 dark:ring-primary-400' : ''}
                        ${day.count > 0 && !isFutureDate ? 'hover:ring-2 hover:ring-primary-500 dark:hover:ring-primary-400' : ''}
                      `}
                      onClick={() => !isFutureDate && handleDayClick(day)}
                      onMouseEnter={() => !isFutureDate && handleDayHover(day)}
                      onMouseLeave={handleDayLeave}
                      title={
                        isFutureDate 
                          ? format(day.date, 'MMM dd, yyyy')
                          : `${format(day.date, 'MMM dd, yyyy')}: ${day.count} submission${day.count !== 1 ? 's' : ''}`
                      }
                    />
                  );
                })}
              </div>
            ))}
          </div>
        </div>

        {/* Tooltip */}
        {selectedDay && (
          <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-900 dark:bg-dark-700 text-white text-sm rounded-lg shadow-lg z-20 whitespace-nowrap">
            <div className="font-medium">
              {format(selectedDay.date, 'EEEE, MMM dd, yyyy')}
            </div>
            <div className="text-gray-300 dark:text-dark-300">
              {selectedDay.count} submission{selectedDay.count !== 1 ? 's' : ''}
            </div>
            {selectedDay.count > 0 && (
              <div className="text-xs text-gray-400 dark:text-dark-400 mt-1">
                Click to view on Codeforces
              </div>
            )}
            <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900 dark:border-t-dark-700"></div>
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="flex flex-col sm:flex-row items-center justify-between mt-4 text-xs text-gray-500 dark:text-dark-400 gap-2">
        <div className="flex items-center gap-2">
          <span>Less</span>
          <div className="flex gap-1">
            {[0, 1, 2, 3, 4].map(intensity => (
              <div
                key={intensity}
                className={`w-3 h-3 rounded-sm border ${getColorClass(intensity)}`}
              />
            ))}
          </div>
          <span>More</span>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4 text-center">
          {maxSubmissions > 0 && (
            <span>Max: {maxSubmissions} submissions/day</span>
          )}
          <span>Last 365 days</span>
        </div>
      </div>

      {/* Activity insights */}
      <div className="mt-4 md:mt-6 grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
        <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-xl p-3 md:p-4 border border-green-200/50 dark:border-green-700/50">
          <h4 className="font-semibold text-green-700 dark:text-green-300 mb-2 flex items-center gap-2 text-sm md:text-base">
            <TrendingUp className="w-4 h-4" />
            Activity Insights
          </h4>
          <div className="space-y-1 text-xs md:text-sm text-green-600 dark:text-green-400">
            <p>• Average: {activeDays > 0 ? Math.round(totalSubmissions / activeDays) : 0} submissions per active day</p>
            <p>• Most active day: {maxSubmissions} submissions</p>
            <p>• Activity rate: {Math.round((activeDays / 365) * 100)}% of days</p>
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-xl p-3 md:p-4 border border-blue-200/50 dark:border-blue-700/50">
          <h4 className="font-semibold text-blue-700 dark:text-blue-300 mb-2 flex items-center gap-2 text-sm md:text-base">
            <Target className="w-4 h-4" />
            Consistency Goals
          </h4>
          <div className="space-y-1 text-xs md:text-sm text-blue-600 dark:text-blue-400">
            {currentStreak > 0 ? (
              <p>• Keep your {currentStreak}-day streak going!</p>
            ) : (
              <p>• Start a new submission streak today</p>
            )}
            <p>• Target: Submit at least once every 3 days</p>
            <p>• Goal: Reach a 30-day streak</p>
          </div>
        </div>
      </div>
    </div>
  );
}