import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ChartOptions,
} from 'chart.js';
import { RatingChange } from '../types/codeforces';
import { formatUnixTime } from '../utils/dateUtils';
import { defaultChartOptions, darkModeChartOptions } from '../utils/chartUtils';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface RatingChartProps {
  ratingHistory: RatingChange[];
  handle: string;
  isDark?: boolean;
}

export function RatingChart({ ratingHistory, handle, isDark = false }: RatingChartProps) {
  if (ratingHistory.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Rating History</h3>
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          No rated contests found
        </div>
      </div>
    );
  }

  const sortedHistory = [...ratingHistory].sort((a, b) => a.ratingUpdateTimeSeconds - b.ratingUpdateTimeSeconds);

  const data = {
    labels: sortedHistory.map(entry => formatUnixTime(entry.ratingUpdateTimeSeconds, 'MMM yy')),
    datasets: [
      {
        label: 'Rating',
        data: sortedHistory.map(entry => entry.newRating),
        borderColor: '#3B82F6',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        tension: 0.1,
        fill: true,
        pointRadius: 4,
        pointHoverRadius: 6,
      },
    ],
  };

  const options: ChartOptions<'line'> = {
    ...(isDark ? darkModeChartOptions : defaultChartOptions),
    plugins: {
      title: {
        display: true,
        text: `${handle}'s Rating Progress`,
        color: isDark ? 'rgba(229, 231, 235, 0.8)' : 'rgba(17, 24, 39, 0.8)',
      },
      tooltip: {
        callbacks: {
          title: (context) => {
            const index = context[0].dataIndex;
            const contest = sortedHistory[index];
            return contest.contestName;
          },
          label: (context) => {
            const index = context.dataIndex;
            const contest = sortedHistory[index];
            const change = contest.newRating - contest.oldRating;
            const changeStr = change > 0 ? `+${change}` : `${change}`;
            return [
              `Rating: ${contest.newRating}`,
              `Change: ${changeStr}`,
              `Rank: ${contest.rank}`,
            ];
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: false,
        grid: {
          color: isDark ? 'rgba(75, 85, 99, 0.3)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(229, 231, 235, 0.7)' : 'rgba(156, 163, 175, 0.8)',
        },
      },
      x: {
        grid: {
          color: isDark ? 'rgba(75, 85, 99, 0.3)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(229, 231, 235, 0.7)' : 'rgba(156, 163, 175, 0.8)',
          maxTicksLimit: 10,
        },
      },
    },
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Rating History</h3>
      <div className="h-64">
        <Line data={data} options={options} />
      </div>
      <div className="mt-4 grid grid-cols-3 gap-4 text-center">
        <div>
          <div className="text-sm text-gray-500 dark:text-gray-400">Contests</div>
          <div className="text-lg font-semibold text-gray-900 dark:text-white">{ratingHistory.length}</div>
        </div>
        <div>
          <div className="text-sm text-gray-500 dark:text-gray-400">Best Rank</div>
          <div className="text-lg font-semibold text-gray-900 dark:text-white">
            {Math.min(...ratingHistory.map(r => r.rank))}
          </div>
        </div>
        <div>
          <div className="text-sm text-gray-500 dark:text-gray-400">Avg Change</div>
          <div className="text-lg font-semibold text-gray-900 dark:text-white">
            {Math.round(ratingHistory.reduce((sum, r) => sum + (r.newRating - r.oldRating), 0) / ratingHistory.length)}
          </div>
        </div>
      </div>
    </div>
  );
}