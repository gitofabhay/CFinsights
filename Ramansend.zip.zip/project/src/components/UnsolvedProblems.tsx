import React from 'react';
import { AlertTriangle, Clock, X, ExternalLink, TrendingDown } from 'lucide-react';
import { Submission } from '../types/codeforces';
import { formatUnixTime } from '../utils/dateUtils';
import { getVerdictColor } from '../utils/chartUtils';

interface UnsolvedProblemsProps {
  submissions: Submission[];
}

export function UnsolvedProblems({ submissions }: UnsolvedProblemsProps) {
  // Get truly unsolved problems - those that have failed attempts but no AC
  const getTrulyUnsolvedProblems = () => {
    // Group all submissions by problem
    const problemSubmissions = new Map<string, Submission[]>();
    
    submissions.forEach(submission => {
      const problemKey = `${submission.problem.contestId}-${submission.problem.index}`;
      if (!problemSubmissions.has(problemKey)) {
        problemSubmissions.set(problemKey, []);
      }
      problemSubmissions.get(problemKey)!.push(submission);
    });

    // Find problems that have failed attempts but no AC
    const trulyUnsolved: Submission[] = [];
    
    problemSubmissions.forEach((problemSubs, problemKey) => {
      const hasAC = problemSubs.some(sub => sub.verdict === 'OK');
      const failedAttempts = problemSubs.filter(sub => sub.verdict && sub.verdict !== 'OK');
      
      // Only include if there are failed attempts but no AC
      if (!hasAC && failedAttempts.length > 0) {
        // Get the most recent failed attempt
        const mostRecentFailed = failedAttempts.sort((a, b) => b.creationTimeSeconds - a.creationTimeSeconds)[0];
        trulyUnsolved.push(mostRecentFailed);
      }
    });

    // Sort by most recent attempt and take top 10
    return trulyUnsolved
      .sort((a, b) => b.creationTimeSeconds - a.creationTimeSeconds)
      .slice(0, 10);
  };

  const unsolvedProblems = getTrulyUnsolvedProblems();

  const getVerdictDisplayName = (verdict: string) => {
    const verdictNames: Record<string, string> = {
      'WRONG_ANSWER': 'Wrong Answer',
      'TIME_LIMIT_EXCEEDED': 'Time Limit Exceeded',
      'MEMORY_LIMIT_EXCEEDED': 'Memory Limit Exceeded',
      'RUNTIME_ERROR': 'Runtime Error',
      'COMPILATION_ERROR': 'Compilation Error',
      'PRESENTATION_ERROR': 'Presentation Error',
      'IDLENESS_LIMIT_EXCEEDED': 'Idleness Limit Exceeded',
      'SECURITY_VIOLATED': 'Security Violated',
      'CRASHED': 'Crashed',
      'INPUT_PREPARATION_CRASHED': 'Input Preparation Crashed',
      'CHALLENGED': 'Challenged',
      'SKIPPED': 'Skipped',
      'TESTING': 'Testing',
      'REJECTED': 'Rejected',
    };
    return verdictNames[verdict] || verdict.replace(/_/g, ' ');
  };

  const getVerdictIcon = (verdict: string) => {
    switch (verdict) {
      case 'WRONG_ANSWER':
        return <X className="w-4 h-4" />;
      case 'TIME_LIMIT_EXCEEDED':
      case 'IDLENESS_LIMIT_EXCEEDED':
        return <Clock className="w-4 h-4" />;
      case 'MEMORY_LIMIT_EXCEEDED':
      case 'RUNTIME_ERROR':
      case 'CRASHED':
        return <AlertTriangle className="w-4 h-4" />;
      default:
        return <TrendingDown className="w-4 h-4" />;
    }
  };

  if (unsolvedProblems.length === 0) {
    return (
      <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-6 border border-gray-200/50 dark:border-dark-700/50">
        <h3 className="text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 flex items-center gap-2">
          <AlertTriangle className="w-6 h-6 text-success-500" />
          Recent Unsolved Problems
        </h3>
        <div className="text-center py-8 text-gray-500 dark:text-dark-400">
          <div className="w-16 h-16 mx-auto mb-4 bg-success-100 dark:bg-success-900/30 rounded-full flex items-center justify-center">
            <AlertTriangle className="w-8 h-8 text-success-500" />
          </div>
          <p className="text-lg font-medium mb-1">Great job!</p>
          <p className="text-sm">No unsolved problems found - you've solved everything you've attempted recently!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
      <h3 className="text-xl font-bold text-gray-900 dark:text-dark-100 mb-6 flex items-center gap-2">
        <AlertTriangle className="w-6 h-6 text-warning-500" />
        Recent Unsolved Problems
        <span className="text-sm font-normal text-gray-500 dark:text-dark-400 ml-2">
          (Problems you haven't solved yet)
        </span>
      </h3>
      
      <div className="space-y-4">
        {unsolvedProblems.map((submission) => (
          <div
            key={`${submission.problem.contestId}-${submission.problem.index}`}
            className="bg-gradient-to-r from-error-50 to-warning-50 dark:from-error-900/20 dark:to-warning-900/20 rounded-xl p-4 border border-error-200/50 dark:border-error-700/50 hover:shadow-lg transition-all duration-300"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-2">
                  <h4 className="text-lg font-semibold text-gray-900 dark:text-dark-100 line-clamp-1">
                    {submission.problem.contestId}{submission.problem.index}. {submission.problem.name}
                  </h4>
                  {submission.problem.rating && (
                    <span className="px-2 py-1 bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 rounded-full text-xs font-medium">
                      {submission.problem.rating}
                    </span>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center gap-2">
                    <div 
                      className="flex items-center gap-1 px-2 py-1 rounded-full text-white text-xs font-medium"
                      style={{ backgroundColor: getVerdictColor(submission.verdict) }}
                    >
                      {getVerdictIcon(submission.verdict!)}
                      <span>{getVerdictDisplayName(submission.verdict!)}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 text-gray-600 dark:text-dark-300">
                    <Clock className="w-4 h-4" />
                    <span>Last attempt: {formatUnixTime(submission.creationTimeSeconds)}</span>
                  </div>
                </div>
                
                {submission.problem.tags.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1">
                    {submission.problem.tags.slice(0, 4).map((tag) => (
                      <span
                        key={tag}
                        className="px-2 py-1 bg-secondary-100 dark:bg-secondary-900/30 text-secondary-700 dark:text-secondary-300 rounded-full text-xs"
                      >
                        {tag.replace(/_/g, ' ')}
                      </span>
                    ))}
                    {submission.problem.tags.length > 4 && (
                      <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-full text-xs">
                        +{submission.problem.tags.length - 4}
                      </span>
                    )}
                  </div>
                )}
              </div>
              
              <a
                href={`https://codeforces.com/problemset/problem/${submission.problem.contestId}/${submission.problem.index}`}
                target="_blank"
                rel="noopener noreferrer"
                className="ml-4 p-2 text-gray-400 hover:text-primary-500 transition-colors"
                title="Try solving this problem"
              >
                <ExternalLink className="w-5 h-5" />
              </a>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-6 text-center">
        <p className="text-sm text-gray-500 dark:text-dark-400">
          Showing {unsolvedProblems.length} unsolved problems (problems with failed attempts but no AC)
        </p>
      </div>

      <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-xl border border-blue-200/50 dark:border-blue-700/50">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="font-semibold text-blue-700 dark:text-blue-300 mb-1">
              💡 Pro Tip:
            </h4>
            <p className="text-sm text-blue-600 dark:text-blue-400">
              These are problems you've attempted but haven't solved yet. Consider revisiting them with a fresh perspective, 
              reading editorials, or practicing similar problems to build the required skills. Each unsolved problem is a learning opportunity!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}