import React from 'react';
import { Doughnut, Pie } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Submission } from '../types/codeforces';
import { getVerdictColor } from '../utils/chartUtils';

ChartJS.register(ArcElement, Tooltip, Legend);

interface SubmissionStatsProps {
  submissions: Submission[];
  isDark?: boolean;
}

export function SubmissionStats({ submissions, isDark = false }: SubmissionStatsProps) {
  if (submissions.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Submission Statistics</h3>
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          No submissions found
        </div>
      </div>
    );
  }

  // Verdict distribution
  const verdictCounts: Record<string, number> = {};
  const languageCounts: Record<string, number> = {};

  submissions.forEach(submission => {
    const verdict = submission.verdict || 'UNKNOWN';
    verdictCounts[verdict] = (verdictCounts[verdict] || 0) + 1;
    
    languageCounts[submission.programmingLanguage] = (languageCounts[submission.programmingLanguage] || 0) + 1;
  });

  // Top verdicts
  const topVerdicts = Object.entries(verdictCounts)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 8);

  // Top languages
  const topLanguages = Object.entries(languageCounts)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 6);

  const verdictData = {
    labels: topVerdicts.map(([verdict]) => verdict.replace(/_/g, ' ')),
    datasets: [
      {
        data: topVerdicts.map(([,count]) => count),
        backgroundColor: topVerdicts.map(([verdict]) => getVerdictColor(verdict)),
        borderWidth: 2,
        borderColor: isDark ? '#374151' : '#ffffff',
      },
    ],
  };

  const languageData = {
    labels: topLanguages.map(([lang]) => lang),
    datasets: [
      {
        label: 'Submissions',
        data: topLanguages.map(([,count]) => count),
        backgroundColor: [
          '#3B82F6',
          '#8B5CF6',
          '#10B981',
          '#F59E0B',
          '#EF4444',
          '#6366F1',
        ],
        borderWidth: 2,
        borderColor: isDark ? '#374151' : '#ffffff',
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        position: 'bottom' as const,
        labels: {
          color: isDark ? 'rgba(229, 231, 235, 0.8)' : 'rgba(17, 24, 39, 0.8)',
          padding: 15,
        },
      },
      tooltip: {
        backgroundColor: isDark ? 'rgba(17, 24, 39, 0.9)' : 'rgba(255, 255, 255, 0.9)',
        titleColor: isDark ? 'rgba(229, 231, 235, 1)' : 'rgba(17, 24, 39, 1)',
        bodyColor: isDark ? 'rgba(229, 231, 235, 0.8)' : 'rgba(17, 24, 39, 0.8)',
        borderColor: isDark ? 'rgba(75, 85, 99, 0.5)' : 'rgba(156, 163, 175, 0.3)',
        borderWidth: 1,
      },
    },
  };

  const acceptedCount = verdictCounts['OK'] || 0;
  const totalSubmissions = submissions.length;
  const acceptanceRate = totalSubmissions > 0 ? (acceptedCount / totalSubmissions * 100).toFixed(1) : 0;

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Submission Overview</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-500">{acceptedCount}</div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Accepted</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900 dark:text-white">{totalSubmissions}</div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Total</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-500">{acceptanceRate}%</div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Success Rate</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-500">{topLanguages.length}</div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Languages</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Verdict Distribution</h3>
          <div className="h-64">
            <Doughnut data={verdictData} options={chartOptions} />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Programming Languages</h3>
          <div className="h-64">
            <Pie data={languageData} options={chartOptions} />
          </div>
        </div>
      </div>
    </div>
  );
}