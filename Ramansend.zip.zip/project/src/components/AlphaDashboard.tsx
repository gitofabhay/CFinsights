import React, { useState, useEffect } from 'react';
import { Calendar, Target, TrendingUp, BookOpen, LogOut, User, Settings, ExternalLink, AlertCircle } from 'lucide-react';

interface AlphaDashboardProps {
  user: any;
  token: string;
  onLogout: () => void;
}

export function AlphaDashboard({ user, token, onLogout }: AlphaDashboardProps) {
  const [activeTab, setActiveTab] = useState<'daily' | 'weekly' | 'monthly' | 'practice'>('daily');
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadDashboardData();
  }, [activeTab]);

  const loadDashboardData = async () => {
    setLoading(true);
    setError(null);
    try {
      let endpoint = '';
      switch (activeTab) {
        case 'daily':
          endpoint = '/api/dashboard/daily';
          break;
        case 'weekly':
          const weekStart = new Date();
          weekStart.setDate(weekStart.getDate() - 6);
          endpoint = `/api/dashboard/weekly/${weekStart.toISOString().split('T')[0]}`;
          break;
        case 'monthly':
          const now = new Date();
          endpoint = `/api/dashboard/monthly/${now.getFullYear()}/${now.getMonth() + 1}`;
          break;
        case 'practice':
          endpoint = '/api/practice/weak-areas';
          break;
      }

      const response = await fetch(endpoint, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to load data');
      }

      const data = await response.json();
      setDashboardData(data);
    } catch (error: any) {
      console.error('Failed to load dashboard data:', error);
      setError(error.message || 'Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const handleGeneratePractice = async (tag: string) => {
    try {
      setLoading(true);
      const response = await fetch(`/api/practice/generate/${tag}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          rating: user.rating || 1500,
          count: 10
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to generate practice problems');
      }

      const data = await response.json();
      // Handle the practice problems data
      alert(`Generated ${data.problems.length} practice problems for ${tag}`);
    } catch (error: any) {
      console.error('Failed to generate practice problems:', error);
      alert(error.message || 'Failed to generate practice problems');
    } finally {
      setLoading(false);
    }
  };

  const TabButton = ({ id, label, icon: Icon }: { id: string; label: string; icon: React.ElementType }) => (
    <button
      onClick={() => setActiveTab(id as any)}
      className={`flex items-center gap-2 px-4 py-3 rounded-lg font-medium transition-all duration-300 ${
        activeTab === id
          ? 'bg-gradient-to-r from-primary-500 to-secondary-500 text-white shadow-lg'
          : 'bg-white/70 dark:bg-dark-800/70 text-gray-700 dark:text-dark-300 hover:bg-white/90 dark:hover:bg-dark-800/90'
      }`}
    >
      <Icon className="w-5 h-5" />
      {label}
    </button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-dark-950 dark:via-dark-900 dark:to-dark-800">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary-600 to-secondary-600 dark:from-primary-400 dark:to-secondary-400 bg-clip-text text-transparent">
              CFInsights Alpha
            </h1>
            <p className="text-gray-600 dark:text-dark-300">
              Welcome back, <span className="font-semibold">{user.username}</span> ({user.cfHandle})
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            <button className="p-2 text-gray-600 hover:text-gray-800 dark:text-dark-400 dark:hover:text-dark-200">
              <Settings className="w-5 h-5" />
            </button>
            <button
              onClick={onLogout}
              className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-4 mb-8">
          <TabButton id="daily" label="Daily Dashboard" icon={Calendar} />
          <TabButton id="weekly" label="Weekly Report" icon={TrendingUp} />
          <TabButton id="monthly" label="Monthly Report" icon={Target} />
          <TabButton id="practice" label="Practice Areas" icon={BookOpen} />
        </div>

        {/* Content */}
        <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-6 border border-gray-200/50 dark:border-dark-700/50">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="w-8 h-8 border-4 border-primary-500/30 border-t-primary-500 rounded-full animate-spin"></div>
            </div>
          ) : error ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <AlertCircle className="w-12 h-12 text-red-500 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 dark:text-dark-100 mb-2">
                Error Loading Data
              </h3>
              <p className="text-gray-600 dark:text-dark-300 mb-4">
                {error}
              </p>
              <button 
                onClick={loadDashboardData}
                className="px-4 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600 transition-colors"
              >
                Try Again
              </button>
            </div>
          ) : (
            <div>
              {activeTab === 'daily' && dashboardData && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-dark-100 mb-6">
                    Today's Dashboard
                  </h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div className="text-center p-4 bg-primary-50 dark:bg-primary-900/30 rounded-xl border dark:border-primary-800/50">
                      <div className="text-3xl font-bold text-primary-600 dark:text-primary-400">
                        {dashboardData.problemsAttempted || 0}
                      </div>
                      <div className="text-gray-600 dark:text-dark-300">Problems Attempted</div>
                    </div>
                    
                    <div className="text-center p-4 bg-success-50 dark:bg-success-900/30 rounded-xl border dark:border-success-800/50">
                      <div className="text-3xl font-bold text-success-600 dark:text-success-400">
                        {dashboardData.problemsSolved || 0}
                      </div>
                      <div className="text-gray-600 dark:text-dark-300">Problems Solved</div>
                    </div>
                    
                    <div className="text-center p-4 bg-warning-50 dark:bg-warning-900/30 rounded-xl border dark:border-warning-800/50">
                      <div className="text-3xl font-bold text-warning-600 dark:text-warning-400">
                        {(dashboardData.score || 0).toFixed(1)}
                      </div>
                      <div className="text-gray-600 dark:text-dark-300">Score / 10</div>
                    </div>
                    
                    <div className="text-center p-4 bg-secondary-50 dark:bg-secondary-900/30 rounded-xl border dark:border-secondary-800/50">
                      <div className="text-3xl font-bold text-secondary-600 dark:text-secondary-400">
                        {dashboardData.unsolvedProblems?.length || 0}
                      </div>
                      <div className="text-gray-600 dark:text-dark-300">Unsolved Problems</div>
                    </div>
                  </div>

                  {dashboardData.unsolvedProblems && dashboardData.unsolvedProblems.length > 0 && (
                    <div className="mb-8">
                      <h3 className="text-xl font-semibold text-gray-900 dark:text-dark-100 mb-4">
                        Unsolved Problems (Max 6)
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {dashboardData.unsolvedProblems.map((problem: any, index: number) => (
                          <div key={index} className="p-4 bg-red-50 dark:bg-red-900/30 rounded-lg border border-red-200 dark:border-red-700">
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="font-semibold text-gray-900 dark:text-dark-100">
                                  {problem.contestId}{problem.index}. {problem.name}
                                </h4>
                                <div className="flex items-center gap-2 mt-2">
                                  {problem.rating && (
                                    <span className="px-2 py-1 bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 rounded text-xs">
                                      {problem.rating}
                                    </span>
                                  )}
                                  <span className="px-2 py-1 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 rounded text-xs">
                                    {problem.verdict}
                                  </span>
                                </div>
                              </div>
                              <a
                                href={`https://codeforces.com/problemset/problem/${problem.contestId}/${problem.index}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-gray-400 hover:text-primary-500 transition-colors"
                              >
                                <ExternalLink className="w-4 h-4" />
                              </a>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {dashboardData.topicAccuracy && Object.keys(dashboardData.topicAccuracy).length > 0 && (
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 dark:text-dark-100 mb-4">
                        Topic-wise Accuracy
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {Object.entries(dashboardData.topicAccuracy).map(([topic, data]: [string, any]) => (
                          <div key={topic} className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-lg border border-blue-200 dark:border-blue-700">
                            <h4 className="font-semibold text-gray-900 dark:text-dark-100 capitalize">
                              {topic.replace(/_/g, ' ')}
                            </h4>
                            <div className="mt-2">
                              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                                {Math.round((data.solved / data.attempted) * 100)}%
                              </div>
                              <div className="text-sm text-gray-600 dark:text-dark-300">
                                {data.solved}/{data.attempted} solved
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {(!dashboardData.unsolvedProblems || dashboardData.unsolvedProblems.length === 0) && 
                   (!dashboardData.topicAccuracy || Object.keys(dashboardData.topicAccuracy).length === 0) && (
                    <div className="text-center py-12">
                      <div className="text-6xl mb-4">🎯</div>
                      <h3 className="text-xl font-semibold text-gray-900 dark:text-dark-100 mb-2">
                        No Activity Today
                      </h3>
                      <p className="text-gray-600 dark:text-dark-300">
                        Solve some problems on Codeforces to see your daily dashboard!
                      </p>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'practice' && dashboardData && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-dark-100 mb-6">
                    Weak Areas Analysis
                  </h2>
                  
                  {dashboardData.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {dashboardData.map((area: any, index: number) => (
                        <div key={index} className="p-6 bg-red-50 dark:bg-red-900/30 rounded-xl border border-red-200 dark:border-red-700">
                          <h3 className="text-lg font-semibold text-gray-900 dark:text-dark-100 mb-2">
                            {area.tag.replace(/_/g, ' ').toUpperCase()}
                          </h3>
                          <div className="text-3xl font-bold text-red-600 dark:text-red-400 mb-2">
                            {area.percentage}%
                          </div>
                          <div className="text-sm text-gray-600 dark:text-dark-300 mb-4">
                            {area.failures} failures in recent submissions
                          </div>
                          <button 
                            onClick={() => handleGeneratePractice(area.tag)}
                            disabled={loading}
                            className="w-full bg-primary-500 text-white py-2 rounded-lg hover:bg-primary-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                          >
                            {loading ? (
                              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            ) : (
                              <>Generate Practice Problems</>
                            )}
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <div className="text-6xl mb-4">🎯</div>
                      <h3 className="text-xl font-semibold text-gray-900 dark:text-dark-100 mb-2">
                        No Weak Areas Detected
                      </h3>
                      <p className="text-gray-600 dark:text-dark-300">
                        Great job! Your recent submissions show consistent performance across all topics.
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Placeholder for other tabs */}
              {(activeTab === 'weekly' || activeTab === 'monthly') && (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">🚧</div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-dark-100 mb-2">
                    Coming Soon
                  </h3>
                  <p className="text-gray-600 dark:text-dark-300">
                    {activeTab === 'weekly' ? 'Weekly' : 'Monthly'} reports are being generated. Check back soon!
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Alpha Mode Info */}
        <div className="mt-8 p-6 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-xl border border-purple-200/50 dark:border-purple-700/50">
          <h3 className="text-xl font-semibold text-purple-700 dark:text-purple-300 mb-4">
            About CFInsights Alpha
          </h3>
          <p className="text-purple-600 dark:text-purple-400 mb-4">
            You're using the Alpha version of CFInsights with exclusive features:
          </p>
          <ul className="list-disc list-inside space-y-2 text-purple-600 dark:text-purple-400">
            <li>Daily performance tracking and analytics</li>
            <li>Personalized practice problem recommendations</li>
            <li>Weak areas identification and improvement suggestions</li>
            <li>Problem bookmarking and notes</li>
            <li>Weekly and monthly performance reports (coming soon)</li>
          </ul>
          <p className="mt-4 text-sm text-purple-500 dark:text-purple-400">
            Thank you for being an early tester! Your feedback helps us improve.
          </p>
        </div>
      </div>
    </div>
  );
}