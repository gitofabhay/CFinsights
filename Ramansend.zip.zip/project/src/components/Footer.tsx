import React from 'react';
import { Heart, Code, Mail, Twitter, Coffee, BookOpen } from 'lucide-react';

export function Footer() {
  return (
    <footer className="mt-16 py-8 border-t border-gray-200/50 dark:border-dark-700/50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center space-y-4 md:space-y-6">
          <div className="flex items-center space-x-2 text-gray-600 dark:text-dark-300">
            <span className="text-xs sm:text-sm md:text-base">Made with</span>
            <Heart className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 text-red-500 animate-pulse" />
            <span className="text-xs sm:text-sm md:text-base">by</span>
            <span className="font-bold text-primary-600 dark:text-primary-400 text-xs sm:text-sm md:text-base">Abhay</span>
          </div>
          
          <div className="flex items-center space-x-2 sm:space-x-4 text-gray-500 dark:text-dark-400">
            <div className="flex items-center space-x-1">
              <Code className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="text-xs sm:text-sm">CFinsights</span>
            </div>
            <span className="text-xs">•</span>
            <span className="text-xs sm:text-sm">© 2024</span>
          </div>
          
          <div className="text-center text-xs sm:text-sm text-gray-400 dark:text-dark-500 max-w-xs sm:max-w-md px-2">
            <p className="font-medium text-primary-600 dark:text-primary-400 mb-2">
              Your one stop solution for all things CF
            </p>
          </div>

          {/* Contact and Support Links */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-3 md:gap-4 w-full max-w-lg">
            <a
              href="mailto:flmkzr@gmail.com"
              className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1.5 sm:py-2 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-all duration-200 text-xs sm:text-sm w-full sm:w-auto justify-center"
            >
              <Mail className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>Doubts or Help</span>
            </a>
            
            <a
              href="https://twitter.com/letmecodeee"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1.5 sm:py-2 bg-sky-50 dark:bg-sky-900/30 text-sky-600 dark:text-sky-400 rounded-lg hover:bg-sky-100 dark:hover:bg-sky-900/50 transition-all duration-200 text-xs sm:text-sm w-full sm:w-auto justify-center"
            >
              <Twitter className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>Follow Updates</span>
            </a>
            
            <a
              href="https://coff.ee/beingabhaya"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1.5 sm:py-2 bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-lg hover:bg-amber-100 dark:hover:bg-amber-900/50 transition-all duration-200 text-xs sm:text-sm font-medium w-full sm:w-auto justify-center"
            >
              <Coffee className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>Buy me a coffee</span>
            </a>
          </div>
          
          <div className="text-center text-xs text-gray-400 dark:text-dark-500 max-w-xs sm:max-w-lg px-2">
            <p>Analyze and compare Codeforces profiles with detailed insights and statistics</p>
          </div>
        </div>
      </div>
    </footer>
  );
}