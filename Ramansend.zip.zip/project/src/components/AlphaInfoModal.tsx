import React from 'react';
import { X, Sparkles, Calendar, Trophy, Target, BarChart3, Users, MessageSquare, Mail, ExternalLink, Star, Zap, Brain, Award, Activity, Clock, BookOpen, TrendingUp } from 'lucide-react';

interface AlphaInfoModalProps {
  onClose: () => void;
}

export function AlphaInfoModal({ onClose }: AlphaInfoModalProps) {
  const upcomingFeatures = [
    { icon: Calendar, name: "Daily & Weekly Reports", description: "Personalized performance tracking with detailed insights" },
    { icon: Trophy, name: "Contest Analysis", description: "Deep dive into your contest performance and strategies" },
    { icon: Users, name: "Daily Leaderboards", description: "Compete with friends and track daily progress" },
    { icon: BookOpen, name: "Problem Revision Tracker", description: "Track attempts and revision history for each problem" },
    { icon: Target, name: "Personalized Practice Plans", description: "AI-curated problem sets based on your weaknesses" },
    { icon: BarChart3, name: "Advanced Analytics Dashboard", description: "Real-time insights with 50+ new metrics" },
    { icon: Star, name: "Achievement System", description: "Unlock badges and milestones as you improve" },
    { icon: Zap, name: "Performance Predictions", description: "AI-powered rating and contest performance forecasts" },
    { icon: Brain, name: "Learning Path Recommendations", description: "Structured roadmaps for skill development" },
    { icon: Award, name: "Skill Assessment", description: "Comprehensive evaluation of your programming abilities" },
    { icon: Activity, name: "Real-time Notifications", description: "Get alerts for contests, milestones, and improvements" },
    { icon: Clock, name: "Time Management Insights", description: "Optimize your problem-solving efficiency" },
    { icon: TrendingUp, name: "Progress Forecasting", description: "Predict your future rating and skill growth" },
  ];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-dark-800 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 md:p-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-xl">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">
                  CFinsights Alpha
                </h2>
                <p className="text-gray-600 dark:text-gray-400 text-sm">The future of competitive programming analytics</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Main Content */}
          <div className="space-y-8">
            {/* Introduction */}
            <div className="text-center">
              <h3 className="text-xl md:text-2xl font-bold text-gray-900 dark:text-white mb-4">
                🚀 We're Building Something Amazing!
              </h3>
              <p className="text-gray-600 dark:text-gray-300 text-lg leading-relaxed max-w-3xl mx-auto">
                We're working on making CFinsights more personalized with <strong>100+ new features</strong> including 
                weekly and daily reports, advanced analytics, and many other ways to enhance your competitive programming journey.
              </p>
            </div>

            {/* Privacy Notice */}
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-xl p-6 border border-green-200/50 dark:border-green-700/50">
              <h4 className="font-semibold text-green-700 dark:text-green-300 mb-3 flex items-center gap-2">
                🔒 Privacy First Approach
              </h4>
              <p className="text-green-600 dark:text-green-400 text-sm md:text-base">
                <strong>We care about your privacy!</strong> To make it personalized, we only need your Codeforces handle and a password for your account. 
                That's it - no personal data, no tracking, just your CF handle to provide you with amazing insights.
              </p>
            </div>

            {/* Upcoming Features */}
            <div>
              <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-6 text-center">
                🎯 Upcoming Features (100+ in development)
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {upcomingFeatures.map((feature, index) => {
                  const IconComponent = feature.icon;
                  return (
                    <div
                      key={index}
                      className="bg-gradient-to-br from-primary-50 to-secondary-50 dark:from-primary-900/20 dark:to-secondary-900/20 rounded-xl p-4 border border-primary-200/50 dark:border-primary-700/50 hover:shadow-lg transition-all duration-300"
                    >
                      <div className="flex items-start gap-3">
                        <div className="p-2 bg-primary-100 dark:bg-primary-900/30 rounded-lg">
                          <IconComponent className="w-5 h-5 text-primary-600 dark:text-primary-400" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h5 className="font-semibold text-gray-900 dark:text-white text-sm mb-1">
                            {feature.name}
                          </h5>
                          <p className="text-gray-600 dark:text-gray-400 text-xs leading-relaxed">
                            {feature.description}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="text-center mt-4">
                <p className="text-gray-500 dark:text-gray-400 text-sm">
                  ...and 80+ more features in development!
                </p>
              </div>
            </div>

            {/* Feedback Section */}
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-xl p-6 border border-blue-200/50 dark:border-blue-700/50">
              <h4 className="font-semibold text-blue-700 dark:text-blue-300 mb-4 text-center text-lg">
                💭 We Want to Hear From You!
              </h4>
              <p className="text-blue-600 dark:text-blue-400 text-center mb-6">
                Help us shape the future of CFinsights! Tell us what features you'd love to see.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Twitter */}
                <a
                  href="https://twitter.com/letmecodeee"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-4 bg-sky-50 dark:bg-sky-900/30 rounded-xl border border-sky-200 dark:border-sky-700 hover:bg-sky-100 dark:hover:bg-sky-900/50 transition-all duration-200 group"
                >
                  <div className="p-2 bg-sky-500 rounded-lg">
                    <MessageSquare className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-sky-700 dark:text-sky-300">DM on X</div>
                    <div className="text-sky-600 dark:text-sky-400 text-sm">@letmecodeee</div>
                  </div>
                  <ExternalLink className="w-4 h-4 text-sky-500 group-hover:translate-x-1 transition-transform" />
                </a>

                {/* Email */}
                <a
                  href="mailto:flmkzr@gmail.com"
                  className="flex items-center gap-3 p-4 bg-green-50 dark:bg-green-900/30 rounded-xl border border-green-200 dark:border-green-700 hover:bg-green-100 dark:hover:bg-green-900/50 transition-all duration-200 group"
                >
                  <div className="p-2 bg-green-500 rounded-lg">
                    <Mail className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-green-700 dark:text-green-300">Email Us</div>
                    <div className="text-green-600 dark:text-green-400 text-sm">flmkzr@gmail.com</div>
                  </div>
                  <ExternalLink className="w-4 h-4 text-green-500 group-hover:translate-x-1 transition-transform" />
                </a>

                {/* Google Form */}
                <a
                  href="https://docs.google.com/forms/d/e/1FAIpQLSelTTausUY3D8Hv-x4bLcIwdqjtPUvj5GyBQHnZoK47d3Q66g/viewform?usp=sharing&ouid=110438784221514750589"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-4 bg-purple-50 dark:bg-purple-900/30 rounded-xl border border-purple-200 dark:border-purple-700 hover:bg-purple-100 dark:hover:bg-purple-900/50 transition-all duration-200 group"
                >
                  <div className="p-2 bg-purple-500 rounded-lg">
                    <BookOpen className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-purple-700 dark:text-purple-300">Fill Form</div>
                    <div className="text-purple-600 dark:text-purple-400 text-sm">Anonymous feedback</div>
                  </div>
                  <ExternalLink className="w-4 h-4 text-purple-500 group-hover:translate-x-1 transition-transform" />
                </a>
              </div>

              <div className="mt-4 text-center">
                <p className="text-blue-500 dark:text-blue-400 text-sm">
                  <strong>Note:</strong> The Google form doesn't require your email - completely anonymous!
                </p>
              </div>
            </div>

            {/* Timeline */}
            <div className="text-center">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-3">
                ⏰ Development Timeline
              </h4>
              <p className="text-gray-600 dark:text-gray-400">
                We're working hard to bring these features to life. This will take time as we want to ensure 
                everything is perfect and maintains our high standards for user experience and privacy.
              </p>
            </div>

            {/* Call to Action */}
            <div className="text-center">
              <button
                onClick={onClose}
                className="px-8 py-3 bg-gradient-to-r from-primary-500 to-secondary-500 text-white rounded-xl hover:from-primary-600 hover:to-secondary-600 transition-all duration-300 transform hover:scale-105 shadow-lg font-semibold"
              >
                Got it! Can't wait! 🚀
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}