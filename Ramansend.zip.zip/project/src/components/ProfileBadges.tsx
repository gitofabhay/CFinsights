import React from 'react';
import { Award, Crown, Moon, Target, Zap, Heart, Trophy, Clock, Star } from 'lucide-react';
import { Submission, User } from '../types/codeforces';

interface ProfileBadgesProps {
  submissions: Submission[];
  user: User;
}

interface Badge {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  earned: boolean;
  progress?: number;
  maxProgress?: number;
}

export function ProfileBadges({ submissions, user }: ProfileBadgesProps) {
  // Badge calculation functions
  const getWAKingBadge = (): Badge => {
    const waCount = submissions.filter(s => s.verdict === 'WRONG_ANSWER').length;
    return {
      id: 'wa-king',
      name: 'WA King',
      description: 'Master of Wrong Answers (100+ WAs)',
      icon: Crown,
      color: 'text-red-600 dark:text-red-400',
      bgColor: 'bg-red-50 dark:bg-red-900/30 border-red-200 dark:border-red-700',
      earned: waCount >= 100,
      progress: Math.min(waCount, 100),
      maxProgress: 100
    };
  };

  const getMidnightCoderBadge = (): Badge => {
    const midnightSubmissions = submissions.filter(s => {
      const hour = new Date(s.creationTimeSeconds * 1000).getHours();
      return hour >= 23 || hour <= 5; // 11 PM to 5 AM
    }).length;
    
    return {
      id: 'midnight-coder',
      name: 'Midnight Coder',
      description: 'Night owl programmer (50+ late night submissions)',
      icon: Moon,
      color: 'text-indigo-600 dark:text-indigo-400',
      bgColor: 'bg-indigo-50 dark:bg-indigo-900/30 border-indigo-200 dark:border-indigo-700',
      earned: midnightSubmissions >= 50,
      progress: Math.min(midnightSubmissions, 50),
      maxProgress: 50
    };
  };

  const getNeverGiveUpBadge = (): Badge => {
    const problemAttempts = new Map<string, Submission[]>();
    
    submissions.forEach(submission => {
      const problemKey = `${submission.problem.contestId}-${submission.problem.index}`;
      if (!problemAttempts.has(problemKey)) {
        problemAttempts.set(problemKey, []);
      }
      problemAttempts.get(problemKey)!.push(submission);
    });

    let maxAttempts = 0;
    problemAttempts.forEach(attempts => {
      const sortedAttempts = attempts.sort((a, b) => a.creationTimeSeconds - b.creationTimeSeconds);
      const hasAC = sortedAttempts.some(a => a.verdict === 'OK');
      if (hasAC) {
        maxAttempts = Math.max(maxAttempts, sortedAttempts.length);
      }
    });

    return {
      id: 'never-give-up',
      name: 'Never Give Up',
      description: 'Solved a problem after 10+ attempts',
      icon: Heart,
      color: 'text-pink-600 dark:text-pink-400',
      bgColor: 'bg-pink-50 dark:bg-pink-900/30 border-pink-200 dark:border-pink-700',
      earned: maxAttempts >= 10,
      progress: Math.min(maxAttempts, 10),
      maxProgress: 10
    };
  };

  const getSpeedDemonBadge = (): Badge => {
    const fastSolves = submissions.filter(s => 
      s.verdict === 'OK' && s.timeConsumedMillis <= 60000 // 1 minute or less
    ).length;

    return {
      id: 'speed-demon',
      name: 'Speed Demon',
      description: 'Lightning fast solver (20+ problems in ≤1 min)',
      icon: Zap,
      color: 'text-yellow-600 dark:text-yellow-400',
      bgColor: 'bg-yellow-50 dark:bg-yellow-900/30 border-yellow-200 dark:border-yellow-700',
      earned: fastSolves >= 20,
      progress: Math.min(fastSolves, 20),
      maxProgress: 20
    };
  };

  const getProblemSolverBadge = (): Badge => {
    const uniqueProblems = new Set<string>();
    submissions.filter(s => s.verdict === 'OK').forEach(s => {
      uniqueProblems.add(`${s.problem.contestId}-${s.problem.index}`);
    });

    return {
      id: 'problem-solver',
      name: 'Problem Solver',
      description: 'Solved 500+ unique problems',
      icon: Target,
      color: 'text-green-600 dark:text-green-400',
      bgColor: 'bg-green-50 dark:bg-green-900/30 border-green-200 dark:border-green-700',
      earned: uniqueProblems.size >= 500,
      progress: Math.min(uniqueProblems.size, 500),
      maxProgress: 500
    };
  };

  const getContestWarriorBadge = (): Badge => {
    // This would need rating history data, so we'll estimate based on user rating
    const hasContestRating = user.rating && user.rating > 0;
    const estimatedContests = hasContestRating ? Math.floor((user.rating || 0) / 50) : 0;

    return {
      id: 'contest-warrior',
      name: 'Contest Warrior',
      description: 'Participated in 50+ contests',
      icon: Trophy,
      color: 'text-purple-600 dark:text-purple-400',
      bgColor: 'bg-purple-50 dark:bg-purple-900/30 border-purple-200 dark:border-purple-700',
      earned: estimatedContests >= 50,
      progress: Math.min(estimatedContests, 50),
      maxProgress: 50
    };
  };

  const getConsistentCoderBadge = (): Badge => {
    // Check if user has submissions in last 30 days
    const thirtyDaysAgo = Date.now() / 1000 - (30 * 24 * 60 * 60);
    const recentSubmissions = submissions.filter(s => s.creationTimeSeconds >= thirtyDaysAgo);
    
    return {
      id: 'consistent-coder',
      name: 'Consistent Coder',
      description: 'Active in the last 30 days (10+ submissions)',
      icon: Clock,
      color: 'text-blue-600 dark:text-blue-400',
      bgColor: 'bg-blue-50 dark:bg-blue-900/30 border-blue-200 dark:border-blue-700',
      earned: recentSubmissions.length >= 10,
      progress: Math.min(recentSubmissions.length, 10),
      maxProgress: 10
    };
  };

  const getRatingClimberBadge = (): Badge => {
    const currentRating = user.rating || 0;
    const maxRating = user.maxRating || 0;
    const ratingGrowth = maxRating - 1200; // Assuming 1200 starting rating

    return {
      id: 'rating-climber',
      name: 'Rating Climber',
      description: 'Gained 500+ rating points',
      icon: Star,
      color: 'text-orange-600 dark:text-orange-400',
      bgColor: 'bg-orange-50 dark:bg-orange-900/30 border-orange-200 dark:border-orange-700',
      earned: ratingGrowth >= 500,
      progress: Math.min(Math.max(ratingGrowth, 0), 500),
      maxProgress: 500
    };
  };

  const badges = [
    getWAKingBadge(),
    getMidnightCoderBadge(),
    getNeverGiveUpBadge(),
    getSpeedDemonBadge(),
    getProblemSolverBadge(),
    getContestWarriorBadge(),
    getConsistentCoderBadge(),
    getRatingClimberBadge(),
  ];

  const earnedBadges = badges.filter(badge => badge.earned);
  const unearnedBadges = badges.filter(badge => !badge.earned);

  return (
    <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-xl md:rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
      <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 md:mb-6 flex items-center gap-2">
        <Award className="w-5 h-5 md:w-6 md:h-6 text-warning-500" />
        <span className="text-sm md:text-base">Profile Badges</span>
        <span className="text-xs md:text-sm font-normal text-gray-500 dark:text-dark-400 ml-2">
          ({earnedBadges.length}/{badges.length} earned)
        </span>
      </h3>

      {/* Earned Badges */}
      {earnedBadges.length > 0 && (
        <div className="mb-6">
          <h4 className="text-sm md:text-base font-semibold text-gray-900 dark:text-dark-100 mb-3 flex items-center gap-2">
            <Trophy className="w-4 h-4 md:w-5 md:h-5 text-success-500" />
            Earned Badges ({earnedBadges.length})
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
            {earnedBadges.map((badge) => {
              const IconComponent = badge.icon;
              return (
                <div
                  key={badge.id}
                  className={`${badge.bgColor} rounded-lg md:rounded-xl p-3 md:p-4 border transition-all duration-300 hover:shadow-lg hover:scale-105`}
                >
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-white/70 dark:bg-dark-800/70 rounded-lg">
                      <IconComponent className={`w-4 h-4 md:w-5 md:h-5 ${badge.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h5 className="font-semibold text-gray-900 dark:text-dark-100 text-sm md:text-base mb-1">
                        {badge.name}
                      </h5>
                      <p className="text-xs md:text-sm text-gray-600 dark:text-dark-300 line-clamp-2">
                        {badge.description}
                      </p>
                      <div className="mt-2 flex items-center gap-2">
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                          <div 
                            className="bg-success-500 h-2 rounded-full transition-all duration-300"
                            style={{ width: '100%' }}
                          />
                        </div>
                        <span className="text-xs font-medium text-success-600 dark:text-success-400">
                          ✓
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Progress Badges */}
      {unearnedBadges.length > 0 && (
        <div>
          <h4 className="text-sm md:text-base font-semibold text-gray-900 dark:text-dark-100 mb-3 flex items-center gap-2">
            <Target className="w-4 h-4 md:w-5 md:h-5 text-primary-500" />
            In Progress ({unearnedBadges.length})
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
            {unearnedBadges.map((badge) => {
              const IconComponent = badge.icon;
              const progressPercentage = badge.maxProgress ? (badge.progress! / badge.maxProgress) * 100 : 0;
              
              return (
                <div
                  key={badge.id}
                  className="bg-gray-50 dark:bg-dark-700/50 rounded-lg md:rounded-xl p-3 md:p-4 border border-gray-200 dark:border-dark-600 transition-all duration-300 hover:shadow-md"
                >
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-gray-100 dark:bg-dark-600 rounded-lg opacity-60">
                      <IconComponent className="w-4 h-4 md:w-5 md:h-5 text-gray-500 dark:text-gray-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h5 className="font-semibold text-gray-700 dark:text-dark-200 text-sm md:text-base mb-1">
                        {badge.name}
                      </h5>
                      <p className="text-xs md:text-sm text-gray-500 dark:text-dark-400 line-clamp-2">
                        {badge.description}
                      </p>
                      {badge.maxProgress && (
                        <div className="mt-2">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs text-gray-600 dark:text-dark-300">
                              {badge.progress}/{badge.maxProgress}
                            </span>
                            <span className="text-xs text-gray-600 dark:text-dark-300">
                              {Math.round(progressPercentage)}%
                            </span>
                          </div>
                          <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                            <div 
                              className="bg-primary-500 h-2 rounded-full transition-all duration-300"
                              style={{ width: `${progressPercentage}%` }}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {earnedBadges.length === 0 && (
        <div className="text-center py-6 md:py-8 text-gray-500 dark:text-dark-400">
          <Award className="w-10 h-10 md:w-12 md:h-12 mx-auto mb-3 text-gray-300 dark:text-dark-600" />
          <p className="text-base md:text-lg font-medium mb-1">No badges earned yet!</p>
          <p className="text-xs md:text-sm">Keep solving problems to unlock achievements</p>
        </div>
      )}
    </div>
  );
}