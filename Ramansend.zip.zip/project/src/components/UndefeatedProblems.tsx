import React from 'react';
import { Skull, ExternalLink, AlertTriangle, Clock, Target } from 'lucide-react';
import { Submission } from '../types/codeforces';
import { formatUnixTime } from '../utils/dateUtils';

interface UndefeatedProblemsProps {
  submissions: Submission[];
}

interface UndefeatedProblem {
  problemKey: string;
  problem: any;
  attempts: Submission[];
  failedAttempts: number;
  lastAttempt: Submission;
  firstAttempt: Submission;
  mostCommonVerdict: string;
  timeSpent: number; // in days
}

export function UndefeatedProblems({ submissions }: UndefeatedProblemsProps) {
  // Find problems with 7+ failed attempts and no AC
  const getUndefeatedProblems = (): UndefeatedProblem[] => {
    const problemAttempts = new Map<string, Submission[]>();
    
    // Group submissions by problem
    submissions.forEach(submission => {
      const problemKey = `${submission.problem.contestId}-${submission.problem.index}`;
      if (!problemAttempts.has(problemKey)) {
        problemAttempts.set(problemKey, []);
      }
      problemAttempts.get(problemKey)!.push(submission);
    });

    const undefeatedProblems: UndefeatedProblem[] = [];

    problemAttempts.forEach((attempts, problemKey) => {
      const sortedAttempts = attempts.sort((a, b) => a.creationTimeSeconds - b.creationTimeSeconds);
      const hasAC = sortedAttempts.some(attempt => attempt.verdict === 'OK');
      
      // Only consider problems with no AC and 7+ attempts
      if (!hasAC && sortedAttempts.length >= 7) {
        const firstAttempt = sortedAttempts[0];
        const lastAttempt = sortedAttempts[sortedAttempts.length - 1];
        
        // Count verdict frequencies
        const verdictCount = new Map<string, number>();
        sortedAttempts.forEach(attempt => {
          if (attempt.verdict) {
            verdictCount.set(attempt.verdict, (verdictCount.get(attempt.verdict) || 0) + 1);
          }
        });
        
        let mostCommonVerdict = 'UNKNOWN';
        let maxCount = 0;
        verdictCount.forEach((count, verdict) => {
          if (count > maxCount) {
            maxCount = count;
            mostCommonVerdict = verdict;
          }
        });

        const timeSpent = (lastAttempt.creationTimeSeconds - firstAttempt.creationTimeSeconds) / (24 * 60 * 60); // in days

        undefeatedProblems.push({
          problemKey,
          problem: firstAttempt.problem,
          attempts: sortedAttempts,
          failedAttempts: sortedAttempts.length,
          lastAttempt,
          firstAttempt,
          mostCommonVerdict,
          timeSpent
        });
      }
    });

    return undefeatedProblems
      .sort((a, b) => b.failedAttempts - a.failedAttempts)
      .slice(0, 8); // Top 8 most attempted undefeated problems
  };

  const undefeatedProblems = getUndefeatedProblems();

  const getVerdictColor = (verdict: string) => {
    const colors: Record<string, string> = {
      'WRONG_ANSWER': 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300',
      'TIME_LIMIT_EXCEEDED': 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300',
      'MEMORY_LIMIT_EXCEEDED': 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300',
      'RUNTIME_ERROR': 'bg-pink-100 dark:bg-pink-900/30 text-pink-700 dark:text-pink-300',
      'COMPILATION_ERROR': 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400',
    };
    return colors[verdict] || 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400';
  };

  const getVerdictDisplayName = (verdict: string) => {
    const names: Record<string, string> = {
      'WRONG_ANSWER': 'Wrong Answer',
      'TIME_LIMIT_EXCEEDED': 'Time Limit',
      'MEMORY_LIMIT_EXCEEDED': 'Memory Limit',
      'RUNTIME_ERROR': 'Runtime Error',
      'COMPILATION_ERROR': 'Compilation Error',
    };
    return names[verdict] || verdict.replace(/_/g, ' ');
  };

  const getDifficultyColor = (rating?: number) => {
    if (!rating) return 'text-gray-600 dark:text-gray-400';
    if (rating < 1400) return 'text-green-600 dark:text-green-400';
    if (rating < 1700) return 'text-blue-600 dark:text-blue-400';
    if (rating < 2100) return 'text-amber-600 dark:text-amber-400';
    return 'text-red-600 dark:text-red-400';
  };

  if (undefeatedProblems.length === 0) {
    return (
      <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-xl md:rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50">
        <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 flex items-center gap-2">
          <Skull className="w-5 h-5 md:w-6 md:h-6 text-error-500" />
          <span className="text-sm md:text-base">Undefeated Problems</span>
        </h3>
        <div className="text-center py-6 md:py-8 text-gray-500 dark:text-dark-400">
          <Target className="w-10 h-10 md:w-12 md:h-12 mx-auto mb-3 text-green-300 dark:text-green-600" />
          <p className="text-base md:text-lg font-medium mb-1">No undefeated problems! 🎯</p>
          <p className="text-xs md:text-sm">You don't have any problems with 7+ failed attempts</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-xl md:rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
      <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 md:mb-6 flex items-center gap-2">
        <Skull className="w-5 h-5 md:w-6 md:h-6 text-error-500" />
        <span className="text-sm md:text-base">Undefeated Problems</span>
        <span className="text-xs md:text-sm font-normal text-gray-500 dark:text-dark-400 ml-2">
          Still undefeated... 💀
        </span>
      </h3>

      {/* Summary */}
      <div className="mb-4 md:mb-6 grid grid-cols-2 md:grid-cols-3 gap-2 md:gap-4 text-xs md:text-sm">
        <div className="text-center p-2 md:p-3 bg-error-50 dark:bg-error-900/30 rounded-lg border dark:border-error-800/50">
          <div className="text-lg md:text-2xl font-bold text-error-600 dark:text-error-400">
            {undefeatedProblems.length}
          </div>
          <div className="text-gray-600 dark:text-dark-300">Undefeated</div>
        </div>
        <div className="text-center p-2 md:p-3 bg-warning-50 dark:bg-warning-900/30 rounded-lg border dark:border-warning-800/50">
          <div className="text-lg md:text-2xl font-bold text-warning-600 dark:text-warning-400">
            {undefeatedProblems.reduce((sum, p) => sum + p.failedAttempts, 0)}
          </div>
          <div className="text-gray-600 dark:text-dark-300">Total Attempts</div>
        </div>
        <div className="text-center p-2 md:p-3 bg-purple-50 dark:bg-purple-900/30 rounded-lg border dark:border-purple-800/50 col-span-2 md:col-span-1">
          <div className="text-lg md:text-2xl font-bold text-purple-600 dark:text-purple-400">
            {undefeatedProblems.length > 0 ? Math.round(undefeatedProblems.reduce((sum, p) => sum + p.failedAttempts, 0) / undefeatedProblems.length) : 0}
          </div>
          <div className="text-gray-600 dark:text-dark-300">Avg Attempts</div>
        </div>
      </div>

      <div className="space-y-3 md:space-y-4">
        {undefeatedProblems.map((problem, index) => (
          <div
            key={problem.problemKey}
            className="bg-gradient-to-r from-error-50 to-warning-50 dark:from-error-900/20 dark:to-warning-900/20 rounded-lg md:rounded-xl p-3 md:p-4 border border-error-200/50 dark:border-error-700/50 hover:shadow-lg transition-all duration-300"
          >
            <div className="flex items-start justify-between mb-2 md:mb-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1 md:mb-2">
                  <Skull className="w-4 h-4 md:w-5 md:h-5 text-error-500" />
                  <h4 className="text-sm md:text-lg font-semibold text-gray-900 dark:text-dark-100 line-clamp-1">
                    {problem.problem.contestId}{problem.problem.index}. {problem.problem.name}
                  </h4>
                  {problem.problem.rating && (
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(problem.problem.rating)} bg-white/70 dark:bg-dark-800/70`}>
                      {problem.problem.rating}
                    </span>
                  )}
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 md:gap-3 text-xs md:text-sm">
                  <div className="flex items-center gap-1 md:gap-2">
                    <AlertTriangle className="w-3 h-3 md:w-4 md:h-4 text-error-500" />
                    <span className="text-gray-600 dark:text-dark-300">
                      <span className="font-semibold">{problem.failedAttempts}</span> failed attempts
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-1 md:gap-2">
                    <Clock className="w-3 h-3 md:w-4 md:h-4 text-warning-500" />
                    <span className="text-gray-600 dark:text-dark-300">
                      <span className="font-semibold">{Math.round(problem.timeSpent)}</span> days fighting
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-1 md:gap-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getVerdictColor(problem.mostCommonVerdict)}`}>
                      {getVerdictDisplayName(problem.mostCommonVerdict)}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="text-right ml-2 md:ml-4">
                <div className="text-lg md:text-xl font-bold text-error-600 dark:text-error-400">
                  #{index + 1}
                </div>
                <div className="text-xs text-gray-600 dark:text-dark-300">
                  nemesis
                </div>
              </div>
            </div>

            {/* Recent attempts pattern */}
            <div className="mb-2 md:mb-3">
              <p className="text-xs md:text-sm font-medium text-gray-700 dark:text-dark-300 mb-1 md:mb-2">
                Recent Attempts:
              </p>
              <div className="flex flex-wrap gap-1">
                {problem.attempts.slice(-8).map((attempt, idx) => (
                  <span
                    key={idx}
                    className={`px-1.5 md:px-2 py-0.5 md:py-1 rounded text-xs font-medium ${getVerdictColor(attempt.verdict || 'UNKNOWN')}`}
                  >
                    {attempt.verdict === 'WRONG_ANSWER' ? 'WA' :
                     attempt.verdict === 'TIME_LIMIT_EXCEEDED' ? 'TLE' :
                     attempt.verdict === 'MEMORY_LIMIT_EXCEEDED' ? 'MLE' :
                     attempt.verdict === 'RUNTIME_ERROR' ? 'RE' :
                     attempt.verdict === 'COMPILATION_ERROR' ? 'CE' :
                     attempt.verdict?.substring(0, 3) || 'UNK'}
                  </span>
                ))}
                {problem.attempts.length > 8 && (
                  <span className="px-1.5 md:px-2 py-0.5 md:py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded text-xs">
                    +{problem.attempts.length - 8}
                  </span>
                )}
              </div>
            </div>

            {/* Problem tags */}
            {problem.problem.tags && problem.problem.tags.length > 0 && (
              <div className="mb-2 md:mb-3">
                <div className="flex flex-wrap gap-1">
                  {problem.problem.tags.slice(0, 4).map((tag: string) => (
                    <span
                      key={tag}
                      className="px-2 py-1 bg-secondary-100 dark:bg-secondary-900/30 text-secondary-700 dark:text-secondary-300 rounded-full text-xs"
                    >
                      {tag.replace(/_/g, ' ')}
                    </span>
                  ))}
                  {problem.problem.tags.length > 4 && (
                    <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-full text-xs">
                      +{problem.problem.tags.length - 4}
                    </span>
                  )}
                </div>
              </div>
            )}

            <div className="flex items-center justify-between text-xs md:text-sm text-gray-600 dark:text-dark-300">
              <span>
                First attempt: {formatUnixTime(problem.firstAttempt.creationTimeSeconds, 'MMM dd, yyyy')}
              </span>
              <span>
                Last attempt: {formatUnixTime(problem.lastAttempt.creationTimeSeconds, 'MMM dd, yyyy')}
              </span>
              <a
                href={`https://codeforces.com/problemset/problem/${problem.problem.contestId}/${problem.problem.index}`}
                target="_blank"
                rel="noopener noreferrer"
                className="p-1 text-gray-400 hover:text-primary-500 transition-colors"
                title="Try again"
              >
                <ExternalLink className="w-3 h-3 md:w-4 md:h-4" />
              </a>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 md:mt-6 p-3 md:p-4 bg-gradient-to-r from-red-50 to-orange-50 dark:from-red-900/20 dark:to-orange-900/20 rounded-lg md:rounded-xl border border-red-200/50 dark:border-red-700/50">
        <div className="flex items-start gap-2 md:gap-3">
          <Skull className="w-4 h-4 md:w-5 md:h-5 text-red-500 mt-0.5" />
          <div>
            <h4 className="font-semibold text-red-700 dark:text-red-300 mb-1 text-sm md:text-base">
              Time to Conquer:
            </h4>
            <p className="text-xs md:text-sm text-red-600 dark:text-red-400">
              These problems have been your nemesis for a while. Consider taking a fresh approach: 
              read editorials, study similar problems, or ask for help. Sometimes a different perspective is all you need! 💪
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}