import React from 'react';
import { AlertCircle, RefreshCw, Bug } from 'lucide-react';

interface ErrorMessageProps {
  message: string;
  onRetry?: () => void;
  showRetry?: boolean;
}

export function ErrorMessage({ message, onRetry, showRetry = true }: ErrorMessageProps) {
  return (
    <div className="flex flex-col items-center justify-center p-12 space-y-6">
      <div className="relative">
        <div className="absolute inset-0 rounded-full bg-gradient-to-r from-error-500 to-warning-500 opacity-20 animate-pulse" />
        <div className="relative p-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-full shadow-xl">
          <AlertCircle className="w-12 h-12 text-error-500" />
        </div>
      </div>
      
      <div className="text-center space-y-4 max-w-md">
        <div className="flex items-center justify-center space-x-2 text-error-600 dark:text-error-400">
          <Bug className="w-5 h-5" />
          <span className="font-semibold text-lg">Something went wrong</span>
        </div>
        <p className="text-gray-600 dark:text-gray-400 leading-relaxed">{message}</p>
        
        {showRetry && onRetry && (
          <button
            onClick={onRetry}
            className="group flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-primary-500 to-secondary-500 text-white rounded-xl hover:from-primary-600 hover:to-secondary-600 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl font-medium"
          >
            <RefreshCw className="w-4 h-4 group-hover:rotate-180 transition-transform duration-500" />
            <span>Try Again</span>
          </button>
        )}
      </div>
    </div>
  );
}