import React from 'react';
import { Bar } from 'react-chartjs-2';
import { Submission } from '../types/codeforces';

interface ProblemTagsProps {
  submissions: Submission[];
  isDark?: boolean;
}

export function ProblemTags({ submissions, isDark = false }: ProblemTagsProps) {
  if (submissions.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Problem Tags</h3>
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          No submissions found
        </div>
      </div>
    );
  }

  // Count accepted submissions by tag
  const tagCounts: Record<string, number> = {};
  const uniqueProblems = new Set<string>();

  submissions
    .filter(s => s.verdict === 'OK')
    .forEach(submission => {
      const problemKey = `${submission.problem.contestId}-${submission.problem.index}`;
      if (!uniqueProblems.has(problemKey)) {
        uniqueProblems.add(problemKey);
        submission.problem.tags.forEach(tag => {
          tagCounts[tag] = (tagCounts[tag] || 0) + 1;
        });
      }
    });

  const topTags = Object.entries(tagCounts)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 15);

  if (topTags.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Problem Tags</h3>
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          No accepted problems found
        </div>
      </div>
    );
  }

  const data = {
    labels: topTags.map(([tag]) => tag.replace(/_/g, ' ')),
    datasets: [
      {
        label: 'Problems Solved',
        data: topTags.map(([,count]) => count),
        backgroundColor: [
          '#3B82F6', '#8B5CF6', '#10B981', '#F59E0B', '#EF4444',
          '#6366F1', '#EC4899', '#14B8A6', '#F97316', '#84CC16',
          '#06B6D4', '#8B5A2B', '#DC2626', '#7C3AED', '#059669'
        ],
        borderWidth: 2,
        borderColor: isDark ? '#374151' : '#ffffff',
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: isDark ? 'rgba(75, 85, 99, 0.3)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(229, 231, 235, 0.7)' : 'rgba(156, 163, 175, 0.8)',
        },
      },
      x: {
        grid: {
          color: isDark ? 'rgba(75, 85, 99, 0.3)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(229, 231, 235, 0.7)' : 'rgba(156, 163, 175, 0.8)',
          maxRotation: 45,
        },
      },
    },
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Problem Tags</h3>
      <div className="h-80">
        <Bar data={data} options={options} />
      </div>
      <div className="mt-4 text-center text-sm text-gray-500 dark:text-gray-400">
        Top tags from {uniqueProblems.size} unique problems solved
      </div>
    </div>
  );
}