import React, { useState } from 'react';
import { User, RatingChange, Submission, BlogEntry } from '../types/codeforces';
import { UserInfo } from './UserInfo';
import { RatingChart } from './RatingChart';
import { SubmissionStats } from './SubmissionStats';
import { ProblemTags } from './ProblemTags';
import { ContestHistory } from './ContestHistory';
import { UpcomingContests } from './UpcomingContests';
import { UnsolvedProblems } from './UnsolvedProblems';
import { ProblemRatingAnalysis } from './ProblemRatingAnalysis';
import { FailureDashboard } from './FailureDashboard';
import { WeakTopics } from './WeakTopics';
import { SubmissionHeatmap } from './SubmissionHeatmap';
import { TagClutchMoments } from './TagClutchMoments';
import { TimeWastedIndex } from './TimeWastedIndex';
import { UndefeatedProblems } from './UndefeatedProblems';
import { ConsistencyIndex } from './ConsistencyIndex';
import { ProfileBadges } from './ProfileBadges';
import { ProfileScore } from './ProfileScore';
import { DocumentationPDF } from './DocumentationPDF';
import { BarChart3, Target, TrendingUp, Code, Calendar, Award, Zap, Activity, Brain, BookOpen, Settings } from 'lucide-react';

interface UserProfileProps {
  user: User;
  ratingHistory: RatingChange[];
  submissions: Submission[];
  blogEntries: BlogEntry[];
  isDark?: boolean;
}

export function UserProfile({ 
  user, 
  ratingHistory, 
  submissions, 
  blogEntries, 
  isDark = false 
}: UserProfileProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'analytics' | 'practice' | 'insights' | 'tools'>('overview');

  const TabButton = ({ 
    id, 
    label, 
    icon: Icon, 
    isActive 
  }: { 
    id: string; 
    label: string; 
    icon: React.ElementType; 
    isActive: boolean; 
  }) => (
    <button
      onClick={() => setActiveTab(id as any)}
      className={`flex items-center gap-2 px-3 md:px-6 py-2 md:py-3 rounded-lg md:rounded-xl font-medium transition-all duration-300 text-sm md:text-base ${
        isActive
          ? 'bg-gradient-to-r from-primary-500 to-secondary-500 text-white shadow-lg transform scale-105'
          : 'bg-white/70 dark:bg-dark-800/70 text-gray-700 dark:text-dark-300 hover:bg-white/90 dark:hover:bg-dark-800/90 hover:scale-105 shadow-md'
      }`}
    >
      <Icon className="w-4 h-4 md:w-5 md:h-5" />
      <span className="hidden sm:inline">{label}</span>
    </button>
  );

  return (
    <div className="space-y-4 md:space-y-6">
      {/* User Info - Always visible */}
      <div className="w-full">
        <UserInfo user={user} />
      </div>
      
      {/* CFinsights Profile Score - Always visible */}
      <div className="w-full">
        <ProfileScore 
          user={user} 
          ratingHistory={ratingHistory} 
          submissions={submissions} 
          isDark={isDark} 
        />
      </div>
      
      {/* Upcoming Contests - Always visible */}
      <div className="w-full">
        <UpcomingContests />
      </div>

      {/* Tab Navigation */}
      <div className="flex flex-wrap justify-center gap-2 md:gap-4 px-4">
        <TabButton id="overview" label="Overview" icon={BarChart3} isActive={activeTab === 'overview'} />
        <TabButton id="analytics" label="Analytics" icon={TrendingUp} isActive={activeTab === 'analytics'} />
        <TabButton id="practice" label="Practice" icon={Target} isActive={activeTab === 'practice'} />
        <TabButton id="insights" label="Insights" icon={Brain} isActive={activeTab === 'insights'} />
        <TabButton id="tools" label="Tools" icon={Settings} isActive={activeTab === 'tools'} />
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="space-y-4 md:space-y-6">
          {/* Rating and Contest History */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
            <div className="w-full">
              <RatingChart ratingHistory={ratingHistory} handle={user.handle} isDark={isDark} />
            </div>
            <div className="w-full">
              <ContestHistory ratingHistory={ratingHistory} />
            </div>
          </div>
          
          {/* Problem Rating Analysis */}
          <div className="w-full">
            <ProblemRatingAnalysis submissions={submissions} user={user} isDark={isDark} />
          </div>
          
          {/* Submission Stats */}
          <div className="w-full">
            <SubmissionStats submissions={submissions} isDark={isDark} />
          </div>
        </div>
      )}

      {activeTab === 'analytics' && (
        <div className="space-y-4 md:space-y-6">
          {/* Tag Clutch Moments */}
          <div className="w-full">
            <TagClutchMoments submissions={submissions} />
          </div>
          
          {/* Problem Tags and Badges */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
            <div className="w-full">
              <ProblemTags submissions={submissions} isDark={isDark} />
            </div>
            <div className="w-full">
              <ProfileBadges submissions={submissions} user={user} />
            </div>
          </div>
          
          {/* Submission Heatmap */}
          <div className="w-full">
            <SubmissionHeatmap submissions={submissions} />
          </div>
          
          {/* Consistency Index */}
          <div className="w-full">
            <ConsistencyIndex submissions={submissions} isDark={isDark} />
          </div>
        </div>
      )}

      {activeTab === 'practice' && (
        <div className="space-y-4 md:space-y-6">
          {/* Weak Topics */}
          <div className="w-full">
            <WeakTopics submissions={submissions} />
          </div>
          
          {/* Undefeated Problems */}
          <div className="w-full">
            <UndefeatedProblems submissions={submissions} />
          </div>
          
          {/* Unsolved Problems */}
          <div className="w-full">
            <UnsolvedProblems submissions={submissions} />
          </div>
        </div>
      )}

      {activeTab === 'insights' && (
        <div className="space-y-4 md:space-y-6">
          {/* Time Wasted Index */}
          <div className="w-full">
            <TimeWastedIndex submissions={submissions} />
          </div>
          
          {/* Failure Dashboard */}
          <div className="w-full">
            <FailureDashboard submissions={submissions} isDark={isDark} />
          </div>
        </div>
      )}

      {activeTab === 'tools' && (
        <div className="space-y-4 md:space-y-6">
          {/* Complete Documentation */}
          <div className="w-full">
            <DocumentationPDF />
          </div>
        </div>
      )}
    </div>
  );
}