import React from 'react';
import { TrendingUp, Target, BookOpen, Lightbulb, RotateCcw, AlertTriangle, Brain, Zap, Clock, Calendar } from 'lucide-react';
import { Submission } from '../types/codeforces';

interface ImprovementSuggestionsProps {
  submissions: Submission[];
}

interface ProblemAnalysis {
  problem: any;
  totalAttempts: number;
  failedAttempts: number;
  errorPattern: string[];
  tags: string[];
  rating?: number;
  mostCommonError: string;
  errorCount: number;
}

export function ImprovementSuggestions({ submissions }: ImprovementSuggestionsProps) {
  // Analyze problems that took multiple attempts but were eventually solved
  const getProblemsWithMultipleAttempts = (): ProblemAnalysis[] => {
    const problemAttempts = new Map<string, Submission[]>();
    
    submissions.forEach(submission => {
      const problemKey = `${submission.problem.contestId}-${submission.problem.index}`;
      if (!problemAttempts.has(problemKey)) {
        problemAttempts.set(problemKey, []);
      }
      problemAttempts.get(problemKey)!.push(submission);
    });

    const multipleAttemptProblems = Array.from(problemAttempts.entries())
      .filter(([_, attempts]) => {
        const hasAccepted = attempts.some(a => a.verdict === 'OK');
        return hasAccepted && attempts.length > 1;
      })
      .map(([problemKey, attempts]) => {
        const sortedAttempts = attempts.sort((a, b) => a.creationTimeSeconds - b.creationTimeSeconds);
        const acceptedSubmission = sortedAttempts.find(a => a.verdict === 'OK')!;
        const failedAttempts = sortedAttempts.filter(a => a.verdict !== 'OK');
        
        // Count error frequencies
        const errorCount = new Map<string, number>();
        failedAttempts.forEach(a => {
          if (a.verdict) {
            errorCount.set(a.verdict, (errorCount.get(a.verdict) || 0) + 1);
          }
        });
        
        let mostCommonError = '';
        let maxCount = 0;
        errorCount.forEach((count, error) => {
          if (count > maxCount) {
            maxCount = count;
            mostCommonError = error;
          }
        });
        
        return {
          problem: acceptedSubmission.problem,
          totalAttempts: attempts.length,
          failedAttempts: failedAttempts.length,
          errorPattern: failedAttempts.map(a => a.verdict!).filter(Boolean),
          tags: acceptedSubmission.problem.tags,
          rating: acceptedSubmission.problem.rating,
          mostCommonError,
          errorCount: maxCount,
        };
      })
      .sort((a, b) => b.failedAttempts - a.failedAttempts)
      .slice(0, 5);

    return multipleAttemptProblems;
  };

  // Get practice recommendations based on solved problems
  const getPracticeRecommendations = () => {
    const solvedTags = new Map<string, number>();
    const acceptedSubmissions = submissions.filter(s => s.verdict === 'OK');
    
    acceptedSubmissions.forEach(submission => {
      submission.problem.tags.forEach(tag => {
        solvedTags.set(tag, (solvedTags.get(tag) || 0) + 1);
      });
    });

    const recommendations: { from: string; to: string[]; reason: string; priority: 'high' | 'medium' | 'low'; timeframe: string; strategy: string }[] = [
      {
        from: 'implementation',
        to: ['greedy', 'constructive algorithms'],
        reason: 'Build upon implementation skills with algorithmic thinking',
        priority: 'high',
        timeframe: '2-3 weeks',
        strategy: 'Solve 15-20 greedy problems, focus on pattern recognition'
      },
      {
        from: 'brute force',
        to: ['two pointers', 'binary search'],
        reason: 'Optimize brute force solutions with efficient techniques',
        priority: 'high',
        timeframe: '3-4 weeks',
        strategy: 'Practice 10 two-pointers + 10 binary search problems daily'
      },
      {
        from: 'math',
        to: ['number theory', 'combinatorics'],
        reason: 'Deepen mathematical problem-solving skills',
        priority: 'medium',
        timeframe: '4-5 weeks',
        strategy: 'Study theory first, then solve 5 problems daily'
      },
      {
        from: 'greedy',
        to: ['dp', 'graphs'],
        reason: 'Progress from greedy to more complex algorithmic paradigms',
        priority: 'high',
        timeframe: '5-6 weeks',
        strategy: 'Start with basic DP patterns, solve 3-4 problems daily'
      },
      {
        from: 'sortings',
        to: ['data structures', 'binary search'],
        reason: 'Apply sorting knowledge to advanced data structures',
        priority: 'medium',
        timeframe: '3-4 weeks',
        strategy: 'Learn STL containers, practice with 10-15 problems'
      },
      {
        from: 'strings',
        to: ['string algorithms', 'hashing'],
        reason: 'Master advanced string manipulation techniques',
        priority: 'medium',
        timeframe: '4-5 weeks',
        strategy: 'Focus on KMP, Z-algorithm, then rolling hash'
      },
      {
        from: 'graphs',
        to: ['trees', 'shortest paths'],
        reason: 'Explore specialized graph algorithms',
        priority: 'high',
        timeframe: '4-6 weeks',
        strategy: 'Master DFS/BFS first, then Dijkstra and tree DP'
      },
      {
        from: 'dp',
        to: ['bitmasks', 'trees'],
        reason: 'Combine DP with other advanced techniques',
        priority: 'high',
        timeframe: '6-8 weeks',
        strategy: 'Practice bitmask DP and tree DP separately'
      },
      {
        from: 'data structures',
        to: ['segment trees', 'dsu'],
        reason: 'Learn specialized data structures',
        priority: 'medium',
        timeframe: '5-7 weeks',
        strategy: 'Implement from scratch, solve 20+ problems each'
      },
    ];

    const applicableRecommendations = recommendations.filter(rec => {
      const fromCount = solvedTags.get(rec.from) || 0;
      return fromCount >= 3;
    });

    return applicableRecommendations.slice(0, 4);
  };

  const multipleAttemptProblems = getProblemsWithMultipleAttempts();
  const practiceRecommendations = getPracticeRecommendations();

  const getSpecificPracticeAdvice = (tags: string[], error: string) => {
    const mainTag = tags[0] || 'general';
    const advice: Record<string, Record<string, string>> = {
      'implementation': {
        'WRONG_ANSWER': 'Practice 10 implementation problems daily for 1 week. Focus on careful reading and edge case handling.',
        'TIME_LIMIT_EXCEEDED': 'Optimize your implementation. Practice writing cleaner, faster code for 2 weeks.',
        'default': 'Solve 15 implementation problems focusing on clean, bug-free code over 2 weeks.'
      },
      'math': {
        'WRONG_ANSWER': 'Review number theory basics. Solve 5 math problems daily for 3 weeks, double-check calculations.',
        'TIME_LIMIT_EXCEEDED': 'Learn efficient mathematical algorithms. Practice modular arithmetic for 2 weeks.',
        'default': 'Strengthen math fundamentals. Solve 8-10 math problems daily for 3 weeks.'
      },
      'greedy': {
        'WRONG_ANSWER': 'Study greedy proof techniques. Solve 12 greedy problems over 2 weeks, verify optimality.',
        'TIME_LIMIT_EXCEEDED': 'Focus on efficient greedy implementations. Practice for 10 days.',
        'default': 'Master greedy patterns. Solve 15 problems over 3 weeks, focus on proof understanding.'
      },
      'dp': {
        'WRONG_ANSWER': 'Review DP state definitions. Practice 8 DP problems daily for 4 weeks, trace through examples.',
        'TIME_LIMIT_EXCEEDED': 'Optimize DP transitions. Study space/time optimization for 3 weeks.',
        'default': 'Build DP intuition. Solve 10 problems daily for 5 weeks, start with classics.'
      },
      'graphs': {
        'WRONG_ANSWER': 'Review graph traversal algorithms. Practice 6 graph problems daily for 3 weeks.',
        'TIME_LIMIT_EXCEEDED': 'Optimize graph algorithms. Focus on efficient implementations for 2 weeks.',
        'default': 'Master graph fundamentals. Solve 8 problems daily for 4 weeks.'
      },
      'strings': {
        'WRONG_ANSWER': 'Practice string manipulation carefully. Solve 8 string problems daily for 2 weeks.',
        'TIME_LIMIT_EXCEEDED': 'Learn efficient string algorithms (KMP, Z). Practice for 3 weeks.',
        'default': 'Strengthen string skills. Solve 10 problems daily for 3 weeks.'
      }
    };

    const topicAdvice = advice[mainTag] || advice['implementation'];
    return topicAdvice[error] || topicAdvice['default'];
  };

  const getErrorIcon = (verdict: string) => {
    switch (verdict) {
      case 'WRONG_ANSWER': return <AlertTriangle className="w-4 h-4" />;
      case 'TIME_LIMIT_EXCEEDED': return <Zap className="w-4 h-4" />;
      case 'MEMORY_LIMIT_EXCEEDED': return <Brain className="w-4 h-4" />;
      case 'RUNTIME_ERROR': return <AlertTriangle className="w-4 h-4" />;
      default: return <RotateCcw className="w-4 h-4" />;
    }
  };

  const getPriorityColor = (priority: 'high' | 'medium' | 'low') => {
    switch (priority) {
      case 'high': return 'from-red-50 to-orange-50 dark:from-red-900/20 dark:to-orange-900/20 border-red-200/50 dark:border-red-700/50';
      case 'medium': return 'from-yellow-50 to-amber-50 dark:from-yellow-900/20 dark:to-amber-900/20 border-yellow-200/50 dark:border-yellow-700/50';
      case 'low': return 'from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200/50 dark:border-green-700/50';
    }
  };

  return (
    <div className="space-y-6">
      {/* Problems with Multiple Attempts */}
      <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
        <h3 className="text-xl font-bold text-gray-900 dark:text-dark-100 mb-6 flex items-center gap-2">
          <RotateCcw className="w-6 h-6 text-warning-500" />
          Problems That Required Multiple Attempts
        </h3>
        
        {multipleAttemptProblems.length === 0 ? (
          <div className="text-center py-8 text-gray-500 dark:text-dark-400">
            <Target className="w-12 h-12 mx-auto mb-3 text-gray-300 dark:text-dark-600" />
            <p className="text-lg font-medium mb-1">Excellent efficiency!</p>
            <p className="text-sm">No problems with multiple attempts found</p>
          </div>
        ) : (
          <div className="space-y-4">
            {multipleAttemptProblems.map((item, index) => {
              const practiceAdvice = getSpecificPracticeAdvice(item.tags, item.mostCommonError);
              
              return (
                <div
                  key={`${item.problem.contestId}-${item.problem.index}`}
                  className="bg-gradient-to-r from-warning-50 to-error-50 dark:from-warning-900/20 dark:to-error-900/20 rounded-xl p-4 border border-warning-200/50 dark:border-warning-700/50"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="text-lg font-semibold text-gray-900 dark:text-dark-100 mb-2">
                        {item.problem.contestId}{item.problem.index}. {item.problem.name}
                      </h4>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm mb-3">
                        <div className="flex items-center gap-2">
                          <RotateCcw className="w-4 h-4 text-warning-500" />
                          <span className="text-gray-600 dark:text-dark-300">
                            {item.totalAttempts} attempts ({item.failedAttempts} failed)
                          </span>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          {getErrorIcon(item.mostCommonError)}
                          <span className="text-gray-600 dark:text-dark-300">
                            Main issue: {item.mostCommonError.replace(/_/g, ' ')} ({item.errorCount}x)
                          </span>
                        </div>
                        
                        {item.rating && (
                          <div className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4 text-primary-500" />
                            <span className="text-gray-600 dark:text-dark-300">
                              Rating: {item.rating}
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Error Pattern Visualization */}
                      <div className="mb-3">
                        <p className="text-sm font-medium text-gray-700 dark:text-dark-300 mb-2">
                          Submission Pattern:
                        </p>
                        <div className="flex flex-wrap gap-1">
                          {item.errorPattern.map((error, idx) => (
                            <span
                              key={idx}
                              className="px-2 py-1 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 rounded text-xs font-medium"
                            >
                              {error.replace(/_/g, ' ')}
                            </span>
                          ))}
                          <span className="px-2 py-1 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 rounded text-xs font-medium">
                            ACCEPTED
                          </span>
                        </div>
                      </div>

                      {/* Topic Tags */}
                      <div className="mb-3">
                        <p className="text-sm font-medium text-gray-700 dark:text-dark-300 mb-2">
                          Topics:
                        </p>
                        <div className="flex flex-wrap gap-1">
                          {item.tags.slice(0, 4).map((tag) => (
                            <span
                              key={tag}
                              className="px-2 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded text-xs font-medium"
                            >
                              {tag.replace(/_/g, ' ')}
                            </span>
                          ))}
                          {item.tags.length > 4 && (
                            <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded text-xs">
                              +{item.tags.length - 4}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200/50 dark:border-blue-700/50">
                    <div className="flex items-start gap-2">
                      <div className="flex items-center gap-1 text-blue-500 mt-0.5">
                        <Clock className="w-4 h-4" />
                        <Calendar className="w-4 h-4" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-blue-700 dark:text-blue-300 mb-1">
                          Specific Practice Plan:
                        </p>
                        <p className="text-sm text-blue-600 dark:text-blue-400">
                          {practiceAdvice}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Practice Recommendations */}
      <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
        <h3 className="text-xl font-bold text-gray-900 dark:text-dark-100 mb-6 flex items-center gap-2">
          <BookOpen className="w-6 h-6 text-success-500" />
          Recommended Learning Path
        </h3>
        
        {practiceRecommendations.length === 0 ? (
          <div className="text-center py-8 text-gray-500 dark:text-dark-400">
            <BookOpen className="w-12 h-12 mx-auto mb-3 text-gray-300 dark:text-dark-600" />
            <p className="text-lg font-medium mb-1">Keep solving!</p>
            <p className="text-sm">Solve more problems to get personalized recommendations</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {practiceRecommendations.map((rec, index) => (
              <div
                key={index}
                className={`bg-gradient-to-r ${getPriorityColor(rec.priority)} rounded-xl p-4 border`}
              >
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-success-100 dark:bg-success-900/30 rounded-lg">
                    <TrendingUp className="w-5 h-5 text-success-600 dark:text-success-400" />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold text-gray-900 dark:text-dark-100">
                        {rec.from.replace(/_/g, ' ')} → {rec.to.join(', ').replace(/_/g, ' ')}
                      </h4>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        rec.priority === 'high' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300' :
                        rec.priority === 'medium' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300' :
                        'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300'
                      }`}>
                        {rec.priority} priority
                      </span>
                    </div>
                    
                    <p className="text-sm text-gray-600 dark:text-dark-300 mb-3">
                      {rec.reason}
                    </p>

                    {/* Time-bound Strategy */}
                    <div className="bg-white/50 dark:bg-dark-900/30 rounded-lg p-3 mb-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Clock className="w-4 h-4 text-primary-500" />
                        <span className="text-sm font-medium text-gray-700 dark:text-dark-300">
                          Timeline: {rec.timeframe}
                        </span>
                      </div>
                      <p className="text-xs text-gray-600 dark:text-dark-400">
                        {rec.strategy}
                      </p>
                    </div>
                    
                    <div className="flex flex-wrap gap-1">
                      {rec.to.map((topic) => (
                        <span
                          key={topic}
                          className="px-2 py-1 bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 rounded-full text-xs font-medium"
                        >
                          {topic.replace(/_/g, ' ')}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        
        <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-xl border border-blue-200/50 dark:border-blue-700/50">
          <div className="flex items-start gap-3">
            <Lightbulb className="w-5 h-5 text-blue-500 mt-0.5" />
            <div>
              <h4 className="font-semibold text-blue-700 dark:text-blue-300 mb-1">
                Strategic Learning Approach:
              </h4>
              <p className="text-sm text-blue-600 dark:text-blue-400">
                Follow the specific timelines and daily problem counts above. Set weekly goals, track progress, 
                and adjust difficulty based on your success rate. Consistency is more important than speed!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}