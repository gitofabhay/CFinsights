import React, { useState } from 'react';
import { AlertTriangle, Target, ExternalLink, Loader2, BookOpen, TrendingUp } from 'lucide-react';
import { Submission } from '../types/codeforces';
import { getPracticeProblems } from '../services/codeforcesApi';

interface WeakTopicsProps {
  submissions: Submission[];
}

interface WeakTopic {
  topic: string;
  failureCount: number;
  percentage: number;
}

interface PracticeProblem {
  contestId: number;
  index: string;
  name: string;
  rating: number;
  tags: string[];
  solvedCount: number;
}

export function WeakTopics({ submissions }: WeakTopicsProps) {
  const [practiceProblems, setPracticeProblems] = useState<Record<string, PracticeProblem[]>>({});
  const [loadingTopic, setLoadingTopic] = useState<string | null>(null);
  const [expandedTopic, setExpandedTopic] = useState<string | null>(null);

  // Analyze failed submissions to identify weak topics
  const getWeakTopics = (): WeakTopic[] => {
    const failedSubmissions = submissions
      .filter(s => s.verdict && s.verdict !== 'OK')
      .slice(0, 50); // Last 50 failed submissions

    if (failedSubmissions.length === 0) return [];

    const topicCounts = new Map<string, number>();
    
    failedSubmissions.forEach(submission => {
      submission.problem.tags.forEach(tag => {
        topicCounts.set(tag, (topicCounts.get(tag) || 0) + 1);
      });
    });

    const totalFailures = failedSubmissions.length;
    
    return Array.from(topicCounts.entries())
      .map(([topic, count]) => ({
        topic,
        failureCount: count,
        percentage: Math.round((count / totalFailures) * 100)
      }))
      .sort((a, b) => b.failureCount - a.failureCount)
      .slice(0, 5); // Top 5 weak topics
  };

  const weakTopics = getWeakTopics();

  const handlePracticeClick = async (topic: string) => {
    if (practiceProblems[topic]) {
      // Toggle expanded state if problems already loaded
      setExpandedTopic(expandedTopic === topic ? null : topic);
      return;
    }

    setLoadingTopic(topic);
    try {
      const problems = await getPracticeProblems(topic);
      setPracticeProblems(prev => ({
        ...prev,
        [topic]: problems
      }));
      setExpandedTopic(topic);
    } catch (error) {
      console.error('Failed to fetch practice problems:', error);
    } finally {
      setLoadingTopic(null);
    }
  };

  const getTopicColor = (index: number) => {
    const colors = [
      'from-red-50 to-orange-50 dark:from-red-900/20 dark:to-orange-900/20 border-red-200/50 dark:border-red-700/50',
      'from-orange-50 to-amber-50 dark:from-orange-900/20 dark:to-amber-900/20 border-orange-200/50 dark:border-orange-700/50',
      'from-amber-50 to-yellow-50 dark:from-amber-900/20 dark:to-yellow-900/20 border-amber-200/50 dark:border-amber-700/50',
      'from-yellow-50 to-lime-50 dark:from-yellow-900/20 dark:to-lime-900/20 border-yellow-200/50 dark:border-yellow-700/50',
      'from-lime-50 to-green-50 dark:from-lime-900/20 dark:to-green-900/20 border-lime-200/50 dark:border-lime-700/50',
    ];
    return colors[index] || colors[0];
  };

  const getTopicTextColor = (index: number) => {
    const colors = [
      'text-red-700 dark:text-red-300',
      'text-orange-700 dark:text-orange-300',
      'text-amber-700 dark:text-amber-300',
      'text-yellow-700 dark:text-yellow-300',
      'text-lime-700 dark:text-lime-300',
    ];
    return colors[index] || colors[0];
  };

  if (weakTopics.length === 0) {
    return (
      <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-6 border border-gray-200/50 dark:border-dark-700/50">
        <h3 className="text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 flex items-center gap-2">
          <Target className="w-6 h-6 text-success-500" />
          Weak Topics
        </h3>
        <div className="text-center py-8 text-gray-500 dark:text-dark-400">
          <div className="w-16 h-16 mx-auto mb-4 bg-success-100 dark:bg-success-900/30 rounded-full flex items-center justify-center">
            <Target className="w-8 h-8 text-success-500" />
          </div>
          <p className="text-lg font-medium mb-1">Great job!</p>
          <p className="text-sm">No weak topics identified from recent submissions</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
      <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 md:mb-6 flex items-center gap-2">
        <AlertTriangle className="w-5 h-5 md:w-6 md:h-6 text-warning-500" />
        <span className="text-sm md:text-base">Weak Topics</span>
        <span className="text-xs md:text-sm font-normal text-gray-500 dark:text-dark-400 ml-2 hidden sm:inline">
          (From last 50 failed submissions)
        </span>
      </h3>

      <div className="space-y-3 md:space-y-4">
        {weakTopics.map((weakTopic, index) => (
          <div key={weakTopic.topic} className="space-y-3">
            <div className={`bg-gradient-to-r ${getTopicColor(index)} rounded-xl p-3 md:p-4 border`}>
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex-1 min-w-0 w-full">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:gap-3 mb-2 md:mb-3">
                    <h4 className={`text-base md:text-lg font-semibold ${getTopicTextColor(index)} truncate`}>
                      {weakTopic.topic.replace(/_/g, ' ').toUpperCase()}
                    </h4>
                    <span className="px-2 py-1 bg-white/70 dark:bg-dark-800/70 rounded-full text-xs font-medium text-gray-700 dark:text-dark-300 whitespace-nowrap">
                      #{index + 1} weakness
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 md:gap-3 text-xs md:text-sm">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-3 h-3 md:w-4 md:h-4 text-error-500 flex-shrink-0" />
                      <span className="text-gray-600 dark:text-dark-300">
                        <span className="font-semibold">{weakTopic.failureCount}</span> failed submissions
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-3 h-3 md:w-4 md:h-4 text-warning-500 flex-shrink-0" />
                      <span className="text-gray-600 dark:text-dark-300">
                        <span className="font-semibold">{weakTopic.percentage}%</span> of recent failures
                      </span>
                    </div>
                  </div>
                </div>
                
                <button
                  onClick={() => handlePracticeClick(weakTopic.topic)}
                  disabled={loadingTopic === weakTopic.topic}
                  className="w-full sm:w-auto px-3 md:px-4 py-2 bg-primary-500 hover:bg-primary-600 disabled:bg-primary-400 text-white rounded-lg font-medium transition-all duration-200 flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transform hover:scale-105 disabled:transform-none text-sm md:text-base"
                >
                  {loadingTopic === weakTopic.topic ? (
                    <>
                      <Loader2 className="w-3 h-3 md:w-4 md:h-4 animate-spin" />
                      <span>Loading...</span>
                    </>
                  ) : (
                    <>
                      <BookOpen className="w-3 h-3 md:w-4 md:h-4" />
                      <span>Practice</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Practice Problems Section */}
            {expandedTopic === weakTopic.topic && practiceProblems[weakTopic.topic] && (
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-xl p-3 md:p-4 border border-blue-200/50 dark:border-blue-700/50 ml-0 sm:ml-4">
                <h5 className="font-semibold text-blue-700 dark:text-blue-300 mb-3 md:mb-4 flex items-center gap-2 text-sm md:text-base">
                  <Target className="w-4 h-4 md:w-5 md:h-5" />
                  <span className="truncate">Practice Problems for {weakTopic.topic.replace(/_/g, ' ')}</span>
                  <span className="text-xs md:text-sm font-normal whitespace-nowrap">
                    ({practiceProblems[weakTopic.topic].length} problems)
                  </span>
                </h5>
                
                {practiceProblems[weakTopic.topic].length === 0 ? (
                  <div className="text-center py-4 text-gray-500 dark:text-dark-400">
                    <p className="text-sm">No practice problems found for this topic in the 800-1700 rating range.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-3">
                    {practiceProblems[weakTopic.topic].map((problem, problemIndex) => (
                      <div
                        key={`${problem.contestId}-${problem.index}`}
                        className="bg-white/70 dark:bg-dark-800/70 rounded-lg p-3 border border-blue-200/30 dark:border-blue-700/30 hover:shadow-md transition-all duration-200"
                      >
                        <div className="flex flex-col sm:flex-row items-start justify-between gap-2">
                          <div className="flex-1 min-w-0 w-full">
                            <h6 className="font-medium text-gray-900 dark:text-dark-100 mb-2 text-sm md:text-base line-clamp-2">
                              {problem.contestId}{problem.index}. {problem.name}
                            </h6>
                            
                            <div className="flex flex-wrap items-center gap-2 md:gap-3 text-xs text-gray-600 dark:text-dark-300 mb-2">
                              <span className="px-2 py-1 bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 rounded-full font-medium">
                                {problem.rating}
                              </span>
                              <span className="flex items-center gap-1">
                                <TrendingUp className="w-3 h-3" />
                                {problem.solvedCount.toLocaleString()} solved
                              </span>
                            </div>
                            
                            <div className="flex flex-wrap gap-1">
                              {problem.tags.slice(0, 3).map((tag) => (
                                <span
                                  key={tag}
                                  className="px-1.5 py-0.5 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded text-xs"
                                >
                                  {tag.replace(/_/g, ' ')}
                                </span>
                              ))}
                              {problem.tags.length > 3 && (
                                <span className="px-1.5 py-0.5 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded text-xs">
                                  +{problem.tags.length - 3}
                                </span>
                              )}
                            </div>
                          </div>
                          
                          <a
                            href={`https://codeforces.com/problemset/problem/${problem.contestId}/${problem.index}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-shrink-0 p-1.5 text-gray-400 hover:text-blue-500 transition-colors"
                            title="Solve problem"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                
                <div className="mt-4 p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg border border-blue-200/50 dark:border-blue-700/50">
                  <div className="flex items-start gap-2">
                    <BookOpen className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                    <div className="text-sm">
                      <p className="font-medium text-blue-700 dark:text-blue-300 mb-1">
                        Practice Strategy:
                      </p>
                      <p className="text-blue-600 dark:text-blue-400">
                        Start with the lowest-rated problems and work your way up. 
                        These problems are selected based on high solve counts, making them ideal for building confidence and understanding core concepts.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-4 md:mt-6 p-3 md:p-4 bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-900/20 dark:to-red-900/20 rounded-xl border border-orange-200/50 dark:border-orange-700/50">
        <div className="flex items-start gap-2 md:gap-3">
          <AlertTriangle className="w-4 h-4 md:w-5 md:h-5 text-orange-500 mt-0.5 flex-shrink-0" />
          <div>
            <h4 className="font-semibold text-orange-700 dark:text-orange-300 mb-1 text-sm md:text-base">
              Focus Strategy:
            </h4>
            <p className="text-xs md:text-sm text-orange-600 dark:text-orange-400">
              These topics show the highest failure rates in your recent submissions. 
              Click "Practice" to get 10 carefully selected problems (rating 800-1700) that will help you build confidence and master the fundamentals.
              Start with the easiest problems and gradually increase difficulty.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}