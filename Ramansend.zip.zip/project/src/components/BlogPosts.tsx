import React from 'react';
import { ExternalLink, MessageSquare, Calendar } from 'lucide-react';
import { BlogEntry } from '../types/codeforces';
import { formatUnixTime } from '../utils/dateUtils';

interface BlogPostsProps {
  blogEntries: BlogEntry[];
}

export function BlogPosts({ blogEntries }: BlogPostsProps) {
  if (blogEntries.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Blog Posts</h3>
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          No blog posts found
        </div>
      </div>
    );
  }

  const sortedEntries = [...blogEntries]
    .sort((a, b) => b.creationTimeSeconds - a.creationTimeSeconds)
    .slice(0, 5);

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Recent Blog Posts</h3>
      
      <div className="space-y-4">
        {sortedEntries.map((entry) => (
          <div
            key={entry.id}
            className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-2 line-clamp-2">
                  {entry.title}
                </h4>
                
                <div className="flex items-center space-x-4 text-xs text-gray-500 dark:text-gray-400">
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-3 h-3" />
                    <span>{formatUnixTime(entry.creationTimeSeconds)}</span>
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    <MessageSquare className="w-3 h-3" />
                    <span>Rating: {entry.rating}</span>
                  </div>
                  
                  {entry.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {entry.tags.slice(0, 2).map((tag) => (
                        <span
                          key={tag}
                          className="px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full text-xs"
                        >
                          {tag}
                        </span>
                      ))}
                      {entry.tags.length > 2 && (
                        <span className="text-gray-500">+{entry.tags.length - 2}</span>
                      )}
                    </div>
                  )}
                </div>
              </div>
              
              <a
                href={`https://codeforces.com/blog/entry/${entry.id}`}
                target="_blank"
                rel="noopener noreferrer"
                className="ml-3 p-1 text-gray-400 hover:text-blue-500 transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        ))}
      </div>
      
      {blogEntries.length > 5 && (
        <div className="mt-4 text-center">
          <span className="text-sm text-gray-500 dark:text-gray-400">
            Showing 5 of {blogEntries.length} blog posts
          </span>
        </div>
      )}
    </div>
  );
}