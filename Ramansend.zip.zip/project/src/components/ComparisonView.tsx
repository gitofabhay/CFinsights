import React, { useState, useMemo } from 'react';
import { Line, Bar, Doughnut, Radar } from 'react-chartjs-2';
import { User, RatingChange, Submission } from '../types/codeforces';
import { UserInfo } from './UserInfo';
import { ProblemTypeComparison } from './ProblemTypeComparison';
import { ContestProgressAnalysis } from './ContestProgressAnalysis';
import { ProfileScoreComparison } from './ProfileScoreComparison';
import { formatUnixTime } from '../utils/dateUtils';
import { getRankColor } from '../utils/chartUtils';
import { TrendingUp, TrendingDown, Trophy, Target, Calendar, Code, BarChart3, Activity, AlertTriangle, Zap, Clock, Star, Filter, Download, Brain, Award, Eye, ChevronDown, ChevronUp, Calculator } from 'lucide-react';

interface ComparisonViewProps {
  users: User[];
  ratingHistories: RatingChange[][];
  submissions: Submission[][];
  isDark?: boolean;
}

interface AfterXAnalysis {
  contestsAnalyzed: number;
  finalRating: number;
  avgRatingChange: number;
  avgRank: number;
  ratingProgression: number[];
  problemsSolved: number;
  totalSubmissions: number;
  acceptanceRate: number;
}

export function ComparisonView({ 
  users, 
  ratingHistories, 
  submissions, 
  isDark = false 
}: ComparisonViewProps) {
  const [user1, user2] = users;
  const [ratings1, ratings2] = ratingHistories;
  const [subs1, subs2] = submissions;
  const [contestFilter, setContestFilter] = useState<number>(5);
  const [activeTab, setActiveTab] = useState<'overview' | 'problems' | 'progress' | 'afterX' | 'verdict'>('overview');

  // Memoized calculations for better performance
  const comparisonData = useMemo(() => {
    const getComparisonStats = (user: User, ratings: RatingChange[], subs: Submission[]) => {
      const acceptedSubs = subs.filter(s => s.verdict === 'OK');
      const uniqueProblems = new Set(acceptedSubs.map(s => `${s.problem.contestId}-${s.problem.index}`));
      
      return {
        contests: ratings.length,
        problemsSolved: uniqueProblems.size,
        totalSubmissions: subs.length,
        acceptanceRate: subs.length > 0 ? (acceptedSubs.length / subs.length * 100).toFixed(1) : 0,
        avgRatingChange: ratings.length > 0 ? 
          Math.round(ratings.reduce((sum, r) => sum + (r.newRating - r.oldRating), 0) / ratings.length) : 0,
        bestRank: ratings.length > 0 ? Math.min(...ratings.map(r => r.rank)) : 0,
        worstRank: ratings.length > 0 ? Math.max(...ratings.map(r => r.rank)) : 0,
        ratingGrowth: ratings.length > 1 ? ratings[ratings.length - 1].newRating - ratings[0].newRating : 0,
      };
    };

    return {
      stats1: getComparisonStats(user1, ratings1, subs1),
      stats2: getComparisonStats(user2, ratings2, subs2)
    };
  }, [user1, user2, ratings1, ratings2, subs1, subs2]);

  // Enhanced "After X Contests" analysis with problems solved
  const afterXAnalysis = useMemo(() => {
    if (contestFilter === 0) return null;

    const analyzeAfterX = (
      ratings: RatingChange[], 
      submissions: Submission[],
      contestCount: number, 
      userHandle: string
    ): AfterXAnalysis | null => {
      console.log(`\n=== Analysis for ${userHandle} after ${contestCount} contests ===`);
      
      if (ratings.length < contestCount) {
        console.log(`❌ ${userHandle} has only ${ratings.length} contests, need ${contestCount}`);
        return null;
      }

      // Sort ratings chronologically and get first X contests
      const sortedRatings = [...ratings].sort((a, b) => a.ratingUpdateTimeSeconds - b.ratingUpdateTimeSeconds);
      const firstXContests = sortedRatings.slice(0, contestCount);

      // Get the timestamp of the Xth contest
      const xthContestTime = firstXContests[firstXContests.length - 1].ratingUpdateTimeSeconds;

      // Count problems solved up to the Xth contest
      const submissionsUpToX = submissions.filter(s => s.creationTimeSeconds <= xthContestTime);
      const acceptedSubmissionsUpToX = submissionsUpToX.filter(s => s.verdict === 'OK');
      const uniqueProblemsUpToX = new Set(acceptedSubmissionsUpToX.map(s => `${s.problem.contestId}-${s.problem.index}`));

      // Calculate metrics
      const finalRating = firstXContests[firstXContests.length - 1].newRating;
      const avgRatingChange = Math.round(
        firstXContests.reduce((sum, c) => sum + (c.newRating - c.oldRating), 0) / firstXContests.length
      );
      const avgRank = Math.round(
        firstXContests.reduce((sum, c) => sum + c.rank, 0) / firstXContests.length
      );
      const ratingProgression = firstXContests.map(c => c.newRating);
      const problemsSolved = uniqueProblemsUpToX.size;
      const totalSubmissions = submissionsUpToX.length;
      const acceptanceRate = totalSubmissions > 0 ? Math.round((acceptedSubmissionsUpToX.length / totalSubmissions) * 100) : 0;

      console.log(`Final rating: ${finalRating}, Problems solved: ${problemsSolved}, Acceptance rate: ${acceptanceRate}%`);

      return {
        contestsAnalyzed: contestCount,
        finalRating,
        avgRatingChange,
        avgRank,
        ratingProgression,
        problemsSolved,
        totalSubmissions,
        acceptanceRate
      };
    };

    const user1Data = analyzeAfterX(ratings1, subs1, contestFilter, user1.handle);
    const user2Data = analyzeAfterX(ratings2, subs2, contestFilter, user2.handle);

    return {
      user1Data,
      user2Data,
      user1HasData: user1Data !== null,
      user2HasData: user2Data !== null,
      user1ContestCount: ratings1.length,
      user2ContestCount: ratings2.length,
      maxAvailableContests: Math.min(ratings1.length, ratings2.length)
    };
  }, [ratings1, ratings2, subs1, subs2, contestFilter, user1.handle, user2.handle]);

  // Optimized rating chart data
  const chartData = useMemo(() => {
    const maxLength = Math.max(ratings1.length, ratings2.length);
    const sortedRatings1 = [...ratings1].sort((a, b) => a.ratingUpdateTimeSeconds - b.ratingUpdateTimeSeconds);
    const sortedRatings2 = [...ratings2].sort((a, b) => a.ratingUpdateTimeSeconds - b.ratingUpdateTimeSeconds);

    return {
      labels: Array.from({ length: maxLength }, (_, i) => `Contest ${i + 1}`),
      datasets: [
        {
          label: user1.handle,
          data: sortedRatings1.map(r => r.newRating),
          borderColor: '#3B82F6',
          backgroundColor: 'rgba(59, 130, 246, 0.1)',
          tension: 0.4,
          pointRadius: 4,
          pointHoverRadius: 6,
          borderWidth: 3,
          pointBackgroundColor: '#3B82F6',
          pointBorderColor: '#ffffff',
          pointBorderWidth: 2,
        },
        {
          label: user2.handle,
          data: sortedRatings2.map(r => r.newRating),
          borderColor: '#F59E0B',
          backgroundColor: 'rgba(245, 158, 11, 0.1)',
          tension: 0.4,
          pointRadius: 4,
          pointHoverRadius: 6,
          borderWidth: 3,
          pointBackgroundColor: '#F59E0B',
          pointBorderColor: '#ffffff',
          pointBorderWidth: 2,
        },
      ],
    };
  }, [ratings1, ratings2, user1.handle, user2.handle]);

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      title: {
        display: true,
        text: 'Rating Progress Comparison',
        color: isDark ? 'rgba(241, 245, 249, 0.9)' : 'rgba(17, 24, 39, 0.9)',
        font: {
          size: 16,
          weight: 'bold' as const,
        },
      },
      legend: {
        labels: {
          color: isDark ? 'rgba(241, 245, 249, 0.8)' : 'rgba(17, 24, 39, 0.8)',
          usePointStyle: true,
          padding: 20,
        },
      },
      tooltip: {
        backgroundColor: isDark ? 'rgba(15, 23, 42, 0.95)' : 'rgba(255, 255, 255, 0.95)',
        titleColor: isDark ? 'rgba(241, 245, 249, 1)' : 'rgba(17, 24, 39, 1)',
        bodyColor: isDark ? 'rgba(241, 245, 249, 0.8)' : 'rgba(17, 24, 39, 0.8)',
        borderColor: isDark ? 'rgba(51, 65, 85, 0.8)' : 'rgba(156, 163, 175, 0.3)',
        borderWidth: 1,
      },
    },
    scales: {
      y: {
        beginAtZero: false,
        grid: {
          color: isDark ? 'rgba(51, 65, 85, 0.4)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(241, 245, 249, 0.7)' : 'rgba(156, 163, 175, 0.8)',
        },
      },
      x: {
        grid: {
          color: isDark ? 'rgba(51, 65, 85, 0.4)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(241, 245, 249, 0.7)' : 'rgba(156, 163, 175, 0.8)',
        },
      },
    },
  };

  const StatComparison = ({ 
    label, 
    value1, 
    value2, 
    suffix = '',
    higherIsBetter = true,
    icon: Icon
  }: {
    label: string;
    value1: number | string;
    value2: number | string;
    suffix?: string;
    higherIsBetter?: boolean;
    icon: React.ElementType;
  }) => {
    const num1 = typeof value1 === 'string' ? parseFloat(value1) : value1;
    const num2 = typeof value2 === 'string' ? parseFloat(value2) : value2;
    
    const getBetterClass = (val: number, other: number) => {
      if (val === other) return 'text-gray-600 dark:text-dark-400';
      const isBetter = higherIsBetter ? val > other : val < other;
      return isBetter ? 'text-success-600 dark:text-success-400 font-bold' : 'text-error-600 dark:text-error-400';
    };

    const getDifferenceIcon = (val: number, other: number) => {
      if (val === other) return null;
      const isBetter = higherIsBetter ? val > other : val < other;
      return isBetter ? <TrendingUp className="w-3 h-3 md:w-4 md:h-4" /> : <TrendingDown className="w-3 h-3 md:w-4 md:h-4" />;
    };

    return (
      <div className="bg-white/70 dark:bg-dark-800/70 backdrop-blur-sm rounded-xl p-3 md:p-4 border border-gray-200/50 dark:border-dark-700/50 shadow-lg dark:shadow-primary-500/5">
        <div className="flex items-center justify-center mb-2 md:mb-3">
          <Icon className="w-4 h-4 md:w-5 md:h-5 text-primary-500 mr-2" />
          <div className="text-xs md:text-sm font-medium text-gray-700 dark:text-dark-300 text-center">{label}</div>
        </div>
        <div className="grid grid-cols-2 gap-2 md:gap-4">
          <div className="text-center">
            <div className={`text-sm md:text-lg font-bold flex items-center justify-center gap-1 ${getBetterClass(num1, num2)}`}>
              {getDifferenceIcon(num1, num2)}
              <span className="truncate">{value1}{suffix}</span>
            </div>
            <div className="text-xs text-gray-500 dark:text-dark-400 truncate">{user1.handle}</div>
          </div>
          <div className="text-center">
            <div className={`text-sm md:text-lg font-bold flex items-center justify-center gap-1 ${getBetterClass(num2, num1)}`}>
              {getDifferenceIcon(num2, num1)}
              <span className="truncate">{value2}{suffix}</span>
            </div>
            <div className="text-xs text-gray-500 dark:text-dark-400 truncate">{user2.handle}</div>
          </div>
        </div>
      </div>
    );
  };

  const TabButton = ({ 
    id, 
    label, 
    icon: Icon, 
    isActive 
  }: { 
    id: string; 
    label: string; 
    icon: React.ElementType; 
    isActive: boolean; 
  }) => (
    <button
      onClick={() => setActiveTab(id as any)}
      className={`flex items-center gap-2 px-3 md:px-6 py-2 md:py-3 rounded-lg md:rounded-xl font-medium transition-all duration-300 text-sm md:text-base ${
        isActive
          ? 'bg-gradient-to-r from-primary-500 to-secondary-500 text-white shadow-lg transform scale-105'
          : 'bg-white/70 dark:bg-dark-800/70 text-gray-700 dark:text-dark-300 hover:bg-white/90 dark:hover:bg-dark-800/90 hover:scale-105 shadow-md'
      }`}
    >
      <Icon className="w-4 h-4 md:w-5 md:h-5" />
      <span className="hidden sm:inline">{label}</span>
    </button>
  );

  return (
    <div className="space-y-6 md:space-y-8">
      <div className="text-center">
        <h2 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-primary-600 to-secondary-600 dark:from-primary-400 dark:to-secondary-400 bg-clip-text text-transparent mb-2">
          Profile Comparison
        </h2>
        <p className="text-gray-600 dark:text-dark-300 text-sm md:text-lg px-4">
          {user1.handle} vs {user2.handle}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        <UserInfo user={user1} />
        <UserInfo user={user2} />
      </div>

      {/* Tab Navigation */}
      <div className="flex flex-wrap justify-center gap-2 md:gap-4 px-4">
        <TabButton id="overview" label="Overview" icon={BarChart3} isActive={activeTab === 'overview'} />
        <TabButton id="verdict" label="Verdict Comparison" icon={Calculator} isActive={activeTab === 'verdict'} />
        <TabButton id="problems" label="Problems" icon={Code} isActive={activeTab === 'problems'} />
        <TabButton id="progress" label="Progress" icon={Activity} isActive={activeTab === 'progress'} />
        <TabButton id="afterX" label="After X Contests" icon={Target} isActive={activeTab === 'afterX'} />
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="space-y-6 md:space-y-8">
          <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
            <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 md:mb-6 text-center flex items-center justify-center gap-2">
              <Trophy className="w-5 h-5 md:w-6 md:h-6 text-primary-500" />
              <span className="text-sm md:text-base">Rating Progress Comparison</span>
            </h3>
            <div className="h-64 md:h-96">
              <Line data={chartData} options={chartOptions} />
            </div>
          </div>

          <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
            <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-6 md:mb-8 text-center flex items-center justify-center gap-2">
              <Code className="w-5 h-5 md:w-6 md:h-6 text-success-500" />
              <span className="text-sm md:text-base">Detailed Statistics Comparison</span>
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
              <StatComparison
                label="Current Rating"
                value1={user1.rating || 0}
                value2={user2.rating || 0}
                icon={TrendingUp}
              />
              
              <StatComparison
                label="Max Rating"
                value1={user1.maxRating || 0}
                value2={user2.maxRating || 0}
                icon={Trophy}
              />
              
              <StatComparison
                label="Contests"
                value1={comparisonData.stats1.contests}
                value2={comparisonData.stats2.contests}
                icon={Calendar}
              />
              
              <StatComparison
                label="Problems Solved"
                value1={comparisonData.stats1.problemsSolved}
                value2={comparisonData.stats2.problemsSolved}
                icon={Target}
              />
              
              <StatComparison
                label="Acceptance Rate"
                value1={comparisonData.stats1.acceptanceRate}
                value2={comparisonData.stats2.acceptanceRate}
                suffix="%"
                icon={TrendingUp}
              />
              
              <StatComparison
                label="Best Rank"
                value1={comparisonData.stats1.bestRank}
                value2={comparisonData.stats2.bestRank}
                higherIsBetter={false}
                icon={Trophy}
              />
              
              <StatComparison
                label="Rating Growth"
                value1={comparisonData.stats1.ratingGrowth}
                value2={comparisonData.stats2.ratingGrowth}
                icon={TrendingUp}
              />
              
              <StatComparison
                label="Avg Change"
                value1={comparisonData.stats1.avgRatingChange}
                value2={comparisonData.stats2.avgRatingChange}
                icon={TrendingUp}
              />
              
              <StatComparison
                label="Worst Rank"
                value1={comparisonData.stats1.worstRank}
                value2={comparisonData.stats2.worstRank}
                higherIsBetter={false}
                icon={TrendingDown}
              />
            </div>
          </div>
        </div>
      )}

      {/* New Verdict Comparison Tab */}
      {activeTab === 'verdict' && (
        <ProfileScoreComparison
          users={users}
          ratingHistories={ratingHistories}
          submissions={submissions}
          isDark={isDark}
        />
      )}

      {/* Enhanced After X Contests Tab */}
      {activeTab === 'afterX' && (
        <div className="space-y-6 md:space-y-8">
          <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
            <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 md:mb-6 text-center flex items-center justify-center gap-2">
              <Target className="w-5 h-5 md:w-6 md:h-6 text-secondary-500" />
              <span className="text-sm md:text-base">After X Contests Analysis</span>
            </h3>
            
            <div className="mb-4 md:mb-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-dark-300 mb-2">
                Analyze performance after first X contests:
              </label>
              <div className="flex flex-wrap gap-2">
                {[5, 10, 15, 20, 25, 30, 50].map(num => {
                  const isDisabled = !afterXAnalysis || 
                    (afterXAnalysis.user1ContestCount < num && afterXAnalysis.user2ContestCount < num);
                  
                  return (
                    <button
                      key={num}
                      onClick={() => setContestFilter(num)}
                      disabled={isDisabled}
                      className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 text-sm ${
                        contestFilter === num
                          ? 'bg-gradient-to-r from-primary-500 to-secondary-500 text-white shadow-lg'
                          : isDisabled
                          ? 'bg-gray-200 dark:bg-gray-700 text-gray-400 dark:text-gray-500 cursor-not-allowed'
                          : 'bg-white/70 dark:bg-dark-800/70 text-gray-700 dark:text-dark-300 hover:bg-white/90 dark:hover:bg-dark-800/90 shadow-md'
                      }`}
                    >
                      {num} contests
                    </button>
                  );
                })}
              </div>
              
              {afterXAnalysis && (
                <div className="mt-2 text-xs text-gray-500 dark:text-dark-400">
                  Available: {user1.handle} ({afterXAnalysis.user1ContestCount} contests), {user2.handle} ({afterXAnalysis.user2ContestCount} contests)
                </div>
              )}
            </div>

            {/* Contest Count Warning */}
            {afterXAnalysis && (!afterXAnalysis.user1HasData || !afterXAnalysis.user2HasData) && (
              <div className="mb-6 p-4 bg-gradient-to-r from-warning-50/80 to-orange-50/80 dark:from-warning-900/40 dark:to-orange-900/40 border border-warning-200/50 dark:border-warning-700/50 rounded-xl backdrop-blur-sm">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-warning-500 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-warning-700 dark:text-warning-300 mb-1">
                      Insufficient Contest Data
                    </h4>
                    <div className="text-sm text-warning-600 dark:text-warning-400 space-y-1">
                      {!afterXAnalysis.user1HasData && (
                        <p>• <strong>{user1.handle}</strong> has only {afterXAnalysis.user1ContestCount} contest{afterXAnalysis.user1ContestCount !== 1 ? 's' : ''}, can't compare after {contestFilter} contests</p>
                      )}
                      {!afterXAnalysis.user2HasData && (
                        <p>• <strong>{user2.handle}</strong> has only {afterXAnalysis.user2ContestCount} contest{afterXAnalysis.user2ContestCount !== 1 ? 's' : ''}, can't compare after {contestFilter} contests</p>
                      )}
                      <p className="mt-2 text-xs">
                        Try selecting {afterXAnalysis.maxAvailableContests} or fewer contests for comparison.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {afterXAnalysis && afterXAnalysis.user1Data && afterXAnalysis.user2Data && (
              <div className="space-y-6">
                {/* Core Metrics Comparison */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                  <div className="text-center p-4 bg-primary-50 dark:bg-primary-900/30 rounded-xl border dark:border-primary-800/50">
                    <h4 className="font-semibold text-primary-700 dark:text-primary-300 mb-2 text-sm md:text-base truncate">{user1.handle}</h4>
                    <div className="grid grid-cols-2 gap-3 text-xs md:text-sm">
                      <div>
                        <div className="text-lg md:text-xl font-bold text-primary-600 dark:text-primary-400">
                          {afterXAnalysis.user1Data.finalRating}
                        </div>
                        <div className="text-gray-600 dark:text-dark-400">Rating</div>
                      </div>
                      <div>
                        <div className="text-lg md:text-xl font-bold text-success-600 dark:text-success-400">
                          {afterXAnalysis.user1Data.problemsSolved}
                        </div>
                        <div className="text-gray-600 dark:text-dark-400">Problems</div>
                      </div>
                    </div>
                    <div className="text-xs text-gray-600 dark:text-dark-400 mt-2">
                      After {contestFilter} contest{contestFilter !== 1 ? 's' : ''}
                    </div>
                  </div>
                  
                  <div className="text-center p-4 bg-secondary-50 dark:bg-secondary-900/30 rounded-xl border dark:border-secondary-800/50">
                    <h4 className="font-semibold text-secondary-700 dark:text-secondary-300 mb-2 text-sm md:text-base truncate">{user2.handle}</h4>
                    <div className="grid grid-cols-2 gap-3 text-xs md:text-sm">
                      <div>
                        <div className="text-lg md:text-xl font-bold text-secondary-600 dark:text-secondary-400">
                          {afterXAnalysis.user2Data.finalRating}
                        </div>
                        <div className="text-gray-600 dark:text-dark-400">Rating</div>
                      </div>
                      <div>
                        <div className="text-lg md:text-xl font-bold text-success-600 dark:text-success-400">
                          {afterXAnalysis.user2Data.problemsSolved}
                        </div>
                        <div className="text-gray-600 dark:text-dark-400">Problems</div>
                      </div>
                    </div>
                    <div className="text-xs text-gray-600 dark:text-dark-400 mt-2">
                      After {contestFilter} contest{contestFilter !== 1 ? 's' : ''}
                    </div>
                  </div>
                </div>

                {/* Enhanced Metrics Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <StatComparison
                    label="Problems Solved"
                    value1={afterXAnalysis.user1Data.problemsSolved}
                    value2={afterXAnalysis.user2Data.problemsSolved}
                    icon={Target}
                  />
                  
                  <StatComparison
                    label="Acceptance Rate"
                    value1={afterXAnalysis.user1Data.acceptanceRate}
                    value2={afterXAnalysis.user2Data.acceptanceRate}
                    suffix="%"
                    icon={TrendingUp}
                  />
                  
                  <StatComparison
                    label="Total Submissions"
                    value1={afterXAnalysis.user1Data.totalSubmissions}
                    value2={afterXAnalysis.user2Data.totalSubmissions}
                    icon={Code}
                  />
                  
                  <StatComparison
                    label="Avg Rating Change"
                    value1={afterXAnalysis.user1Data.avgRatingChange}
                    value2={afterXAnalysis.user2Data.avgRatingChange}
                    icon={TrendingUp}
                  />
                  
                  <StatComparison
                    label="Avg Rank"
                    value1={afterXAnalysis.user1Data.avgRank}
                    value2={afterXAnalysis.user2Data.avgRank}
                    higherIsBetter={false}
                    icon={Trophy}
                  />
                  
                  <StatComparison
                    label="Final Rating"
                    value1={afterXAnalysis.user1Data.finalRating}
                    value2={afterXAnalysis.user2Data.finalRating}
                    icon={Star}
                  />
                </div>

                {/* Rating Progression Chart */}
                <div className="bg-white/70 dark:bg-dark-700/70 backdrop-blur-sm rounded-xl p-4 border border-gray-200/30 dark:border-dark-700/30">
                  <h4 className="font-semibold text-gray-900 dark:text-dark-100 mb-4">Rating Progression Over First {contestFilter} Contests</h4>
                  <div className="h-64">
                    <Line 
                      data={{
                        labels: Array.from({ length: contestFilter }, (_, i) => `Contest ${i + 1}`),
                        datasets: [
                          {
                            label: user1.handle,
                            data: afterXAnalysis.user1Data.ratingProgression,
                            borderColor: '#3B82F6',
                            backgroundColor: 'rgba(59, 130, 246, 0.1)',
                            tension: 0.4,
                            pointRadius: 4,
                            borderWidth: 3,
                          },
                          {
                            label: user2.handle,
                            data: afterXAnalysis.user2Data.ratingProgression,
                            borderColor: '#F59E0B',
                            backgroundColor: 'rgba(245, 158, 11, 0.1)',
                            tension: 0.4,
                            pointRadius: 4,
                            borderWidth: 3,
                          },
                        ],
                      }}
                      options={chartOptions}
                    />
                  </div>
                </div>

                {/* Enhanced Summary */}
                <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-xl p-4 border border-blue-200/50 dark:border-blue-700/50">
                  <h4 className="font-semibold text-blue-700 dark:text-blue-300 mb-3 flex items-center gap-2">
                    <Award className="w-5 h-5" />
                    📊 Comprehensive Summary After {contestFilter} Contests
                  </h4>
                  <div className="text-blue-600 dark:text-blue-400 text-sm space-y-2">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-white/50 dark:bg-dark-800/30 rounded-lg p-3">
                        <h5 className="font-semibold text-blue-700 dark:text-blue-300 mb-2">🏆 Rating Performance</h5>
                        <p>
                          <strong>{afterXAnalysis.user1Data.finalRating > afterXAnalysis.user2Data.finalRating ? user1.handle : user2.handle}</strong> was ahead by{' '}
                          <span className="font-bold">{Math.abs(afterXAnalysis.user1Data.finalRating - afterXAnalysis.user2Data.finalRating)}</span> rating points.
                        </p>
                        <div className="mt-2 text-xs space-y-1">
                          <p><strong>{user1.handle}</strong>: {afterXAnalysis.user1Data.avgRatingChange > 0 ? '+' : ''}{afterXAnalysis.user1Data.avgRatingChange} avg change, rank {afterXAnalysis.user1Data.avgRank}</p>
                          <p><strong>{user2.handle}</strong>: {afterXAnalysis.user2Data.avgRatingChange > 0 ? '+' : ''}{afterXAnalysis.user2Data.avgRatingChange} avg change, rank {afterXAnalysis.user2Data.avgRank}</p>
                        </div>
                      </div>
                      
                      <div className="bg-white/50 dark:bg-dark-800/30 rounded-lg p-3">
                        <h5 className="font-semibold text-blue-700 dark:text-blue-300 mb-2">🎯 Problem Solving</h5>
                        <p>
                          <strong>{afterXAnalysis.user1Data.problemsSolved > afterXAnalysis.user2Data.problemsSolved ? user1.handle : user2.handle}</strong> solved{' '}
                          <span className="font-bold">{Math.abs(afterXAnalysis.user1Data.problemsSolved - afterXAnalysis.user2Data.problemsSolved)}</span> more problems.
                        </p>
                        <div className="mt-2 text-xs space-y-1">
                          <p><strong>{user1.handle}</strong>: {afterXAnalysis.user1Data.problemsSolved} problems, {afterXAnalysis.user1Data.acceptanceRate}% acceptance</p>
                          <p><strong>{user2.handle}</strong>: {afterXAnalysis.user2Data.problemsSolved} problems, {afterXAnalysis.user2Data.acceptanceRate}% acceptance</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-white/50 dark:bg-dark-800/30 rounded-lg p-3 mt-3">
                      <h5 className="font-semibold text-blue-700 dark:text-blue-300 mb-2">📈 Overall Assessment</h5>
                      <p>
                        {afterXAnalysis.user1Data.problemsSolved > afterXAnalysis.user2Data.problemsSolved && afterXAnalysis.user1Data.finalRating > afterXAnalysis.user2Data.finalRating
                          ? `${user1.handle} dominated both in rating and problem-solving during the first ${contestFilter} contests.`
                          : afterXAnalysis.user2Data.problemsSolved > afterXAnalysis.user1Data.problemsSolved && afterXAnalysis.user2Data.finalRating > afterXAnalysis.user1Data.finalRating
                          ? `${user2.handle} dominated both in rating and problem-solving during the first ${contestFilter} contests.`
                          : `Mixed performance: ${afterXAnalysis.user1Data.finalRating > afterXAnalysis.user2Data.finalRating ? user1.handle : user2.handle} had better rating, while ${afterXAnalysis.user1Data.problemsSolved > afterXAnalysis.user2Data.problemsSolved ? user1.handle : user2.handle} solved more problems.`
                        }
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {(!afterXAnalysis || (!afterXAnalysis.user1Data && !afterXAnalysis.user2Data)) && (
              <div className="text-center py-8 text-gray-500 dark:text-dark-400">
                <AlertTriangle className="w-12 h-12 mx-auto mb-3 text-gray-300 dark:text-dark-600" />
                <p className="text-lg font-medium mb-1">Insufficient Data</p>
                <p className="text-sm">Both users don't have enough contest history for this analysis.</p>
                <p className="text-xs mt-2 text-gray-400 dark:text-dark-500">
                  {user1.handle}: {afterXAnalysis?.user1ContestCount || 0} contests, {user2.handle}: {afterXAnalysis?.user2ContestCount || 0} contests
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'problems' && (
        <ProblemTypeComparison
          submissions1={subs1}
          submissions2={subs2}
          user1Handle={user1.handle}
          user2Handle={user2.handle}
          isDark={isDark}
        />
      )}

      {activeTab === 'progress' && (
        <ContestProgressAnalysis
          user1Handle={user1.handle}
          user2Handle={user2.handle}
          ratings1={ratings1}
          ratings2={ratings2}
          submissions1={subs1}
          submissions2={subs2}
          isDark={isDark}
        />
      )}
    </div>
  );
}