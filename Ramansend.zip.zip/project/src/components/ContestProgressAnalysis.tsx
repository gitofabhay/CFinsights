import React, { useState } from 'react';
import { Line } from 'react-chartjs-2';
import { RatingChange, Submission } from '../types/codeforces';
import { Calendar, Trophy, Target, TrendingUp } from 'lucide-react';

interface ContestProgressAnalysisProps {
  user1Handle: string;
  user2Handle: string;
  ratings1: RatingChange[];
  ratings2: RatingChange[];
  submissions1: Submission[];
  submissions2: Submission[];
  isDark?: boolean;
}

export function ContestProgressAnalysis({
  user1Handle,
  user2Handle,
  ratings1,
  ratings2,
  submissions1,
  submissions2,
  isDark = false
}: ContestProgressAnalysisProps) {
  const [analysisType, setAnalysisType] = useState<'rating' | 'performance'>('rating');

  const sortedRatings1 = [...ratings1].sort((a, b) => a.ratingUpdateTimeSeconds - b.ratingUpdateTimeSeconds);
  const sortedRatings2 = [...ratings2].sort((a, b) => a.ratingUpdateTimeSeconds - b.ratingUpdateTimeSeconds);

  // Get average rank after each contest
  const getAverageRankAfterContests = (ratings: RatingChange[]) => {
    const result: number[] = [];
    
    ratings.forEach((_, index) => {
      const contestsUpToNow = ratings.slice(0, index + 1);
      const avgRank = contestsUpToNow.reduce((sum, r) => sum + r.rank, 0) / contestsUpToNow.length;
      result.push(Math.round(avgRank));
    });
    
    return result;
  };

  const avgRanks1 = getAverageRankAfterContests(sortedRatings1);
  const avgRanks2 = getAverageRankAfterContests(sortedRatings2);

  const maxContests = Math.max(sortedRatings1.length, sortedRatings2.length);
  const contestLabels = Array.from({ length: maxContests }, (_, i) => `Contest ${i + 1}`);

  const getChartData = () => {
    switch (analysisType) {
      case 'rating':
        return {
          labels: contestLabels,
          datasets: [
            {
              label: `${user1Handle} Rating`,
              data: sortedRatings1.map(r => r.newRating),
              borderColor: '#3B82F6', // Blue
              backgroundColor: 'rgba(59, 130, 246, 0.1)',
              tension: 0.4,
              pointRadius: 4,
              borderWidth: 3,
            },
            {
              label: `${user2Handle} Rating`,
              data: sortedRatings2.map(r => r.newRating),
              borderColor: '#F59E0B', // Amber/Orange
              backgroundColor: 'rgba(245, 158, 11, 0.1)',
              tension: 0.4,
              pointRadius: 4,
              borderWidth: 3,
            },
          ],
        };
      case 'performance':
        return {
          labels: contestLabels,
          datasets: [
            {
              label: `${user1Handle} Avg Rank`,
              data: avgRanks1,
              borderColor: '#EF4444', // Red
              backgroundColor: 'rgba(239, 68, 68, 0.1)',
              tension: 0.4,
              pointRadius: 4,
              borderWidth: 3,
            },
            {
              label: `${user2Handle} Avg Rank`,
              data: avgRanks2,
              borderColor: '#8B5CF6', // Violet
              backgroundColor: 'rgba(139, 92, 246, 0.1)',
              tension: 0.4,
              pointRadius: 4,
              borderWidth: 3,
            },
          ],
        };
      default:
        return { labels: [], datasets: [] };
    }
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        labels: {
          color: isDark ? 'rgba(229, 231, 235, 0.8)' : 'rgba(17, 24, 39, 0.8)',
          usePointStyle: true,
          padding: 20,
        },
      },
      tooltip: {
        backgroundColor: isDark ? 'rgba(17, 24, 39, 0.9)' : 'rgba(255, 255, 255, 0.9)',
        titleColor: isDark ? 'rgba(229, 231, 235, 1)' : 'rgba(17, 24, 39, 1)',
        bodyColor: isDark ? 'rgba(229, 231, 235, 0.8)' : 'rgba(17, 24, 39, 0.8)',
        borderColor: isDark ? 'rgba(75, 85, 99, 0.5)' : 'rgba(156, 163, 175, 0.3)',
        borderWidth: 1,
      },
    },
    scales: {
      y: {
        beginAtZero: analysisType === 'problems',
        reverse: analysisType === 'performance',
        grid: {
          color: isDark ? 'rgba(75, 85, 99, 0.3)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(229, 231, 235, 0.7)' : 'rgba(156, 163, 175, 0.8)',
        },
      },
      x: {
        grid: {
          color: isDark ? 'rgba(75, 85, 99, 0.3)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(229, 231, 235, 0.7)' : 'rgba(156, 163, 175, 0.8)',
        },
      },
    },
  };

  // Milestone analysis
  const getMilestones = (contestCount: number) => {
    const milestones = [];
    
    if (contestCount >= 5) {
      const rating1After5 = sortedRatings1[4]?.newRating;
      const rating2After5 = sortedRatings2[4]?.newRating;
      
      milestones.push({
        contest: 5,
        user1Rating: rating1After5,
        user2Rating: rating2After5,
      });
    }
    
    if (contestCount >= 10) {
      const rating1After10 = sortedRatings1[9]?.newRating;
      const rating2After10 = sortedRatings2[9]?.newRating;
      
      milestones.push({
        contest: 10,
        user1Rating: rating1After10,
        user2Rating: rating2After10,
      });
    }
    
    if (contestCount >= 25) {
      const rating1After25 = sortedRatings1[24]?.newRating;
      const rating2After25 = sortedRatings2[24]?.newRating;
      
      milestones.push({
        contest: 25,
        user1Rating: rating1After25,
        user2Rating: rating2After25,
      });
    }
    
    return milestones;
  };

  const milestones = getMilestones(maxContests);

  return (
    <div className="space-y-6 md:space-y-8">
      <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-gray-700/50">
        <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-white mb-4 md:mb-6 text-center flex items-center justify-center gap-2">
          <TrendingUp className="w-5 h-5 md:w-6 md:h-6 text-primary-500" />
          <span className="text-sm md:text-base">Contest Progress Analysis</span>
        </h3>
        
        <div className="mb-4 md:mb-6">
          <div className="flex flex-wrap gap-2 justify-center">
            <button
              onClick={() => setAnalysisType('rating')}
              className={`px-3 md:px-4 py-2 rounded-lg font-medium transition-all duration-200 text-sm md:text-base ${
                analysisType === 'rating'
                  ? 'bg-primary-500 text-white shadow-lg'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              <Trophy className="w-3 h-3 md:w-4 md:h-4 inline mr-1 md:mr-2" />
              <span className="hidden sm:inline">Rating Progress</span>
              <span className="sm:hidden">Rating</span>
            </button>
            <button
              onClick={() => setAnalysisType('performance')}
              className={`px-3 md:px-4 py-2 rounded-lg font-medium transition-all duration-200 text-sm md:text-base ${
                analysisType === 'performance'
                  ? 'bg-warning-500 text-white shadow-lg'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              <Calendar className="w-3 h-3 md:w-4 md:h-4 inline mr-1 md:mr-2" />
              <span className="hidden sm:inline">Average Rank</span>
              <span className="sm:hidden">Rank</span>
            </button>
          </div>
        </div>

        <div className="h-64 md:h-96">
          <Line data={getChartData()} options={chartOptions} />
        </div>
      </div>

      {milestones.length > 0 && (
        <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-gray-700/50">
          <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-white mb-4 md:mb-6 text-center flex items-center justify-center gap-2">
            <Trophy className="w-5 h-5 md:w-6 md:h-6 text-secondary-500" />
            <span className="text-sm md:text-base">Progress Milestones</span>
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
            {milestones.map((milestone) => (
              <div key={milestone.contest} className="bg-gradient-to-br from-primary-50 to-secondary-50 dark:from-primary-900/20 dark:to-secondary-900/20 rounded-xl p-3 md:p-4 border border-primary-200/50 dark:border-primary-700/50">
                <h4 className="text-sm md:text-lg font-bold text-center mb-3 md:mb-4 text-primary-700 dark:text-primary-300">
                  After {milestone.contest} Contests
                </h4>
                
                <div className="space-y-2 md:space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-xs md:text-sm text-gray-600 dark:text-gray-400">Rating:</span>
                    <div className="flex gap-1 md:gap-2 text-xs md:text-sm">
                      <span className="font-semibold text-primary-600 dark:text-primary-400 truncate">
                        {milestone.user1Rating || 'N/A'}
                      </span>
                      <span className="text-gray-400">vs</span>
                      <span className="font-semibold text-secondary-600 dark:text-secondary-400 truncate">
                        {milestone.user2Rating || 'N/A'}
                      </span>
                    </div>
                  </div>
                  
                  {milestone.user1Rating && milestone.user2Rating && (
                    <div className="text-center pt-2 border-t border-gray-200 dark:border-gray-600">
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        {milestone.user1Rating > milestone.user2Rating ? user1Handle : user2Handle} was ahead by{' '}
                        <span className="font-bold">
                          {Math.abs(milestone.user1Rating - milestone.user2Rating)} points
                        </span>
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}