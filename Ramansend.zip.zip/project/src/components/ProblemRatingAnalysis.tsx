import React from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ChartOptions,
} from 'chart.js';
import annotationPlugin from 'chartjs-plugin-annotation';
import { BarChart3, Target, TrendingUp, Award } from 'lucide-react';
import { Submission, User } from '../types/codeforces';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  annotationPlugin
);

interface ProblemRatingAnalysisProps {
  submissions: Submission[];
  user: User;
  isDark?: boolean;
}

export function ProblemRatingAnalysis({ submissions, user, isDark = false }: ProblemRatingAnalysisProps) {
  const userRating = user.rating || 1200;

  // Optimized: Process only unique solved problems
  const solvedProblems = new Map<string, Submission>();
  submissions
    .filter(s => s.verdict === 'OK' && s.problem.rating)
    .forEach(submission => {
      const problemKey = `${submission.problem.contestId}-${submission.problem.index}`;
      if (!solvedProblems.has(problemKey)) {
        solvedProblems.set(problemKey, submission);
      }
    });

  const solvedProblemsArray = Array.from(solvedProblems.values());

  // Optimized rating histogram with fewer buckets
  const ratingCounts = new Map<number, number>();
  const minRating = 800;
  const maxRating = 3500;
  const step = 200; // Increased step for fewer buckets

  for (let rating = minRating; rating <= maxRating; rating += step) {
    ratingCounts.set(rating, 0);
  }

  solvedProblemsArray.forEach(submission => {
    const rating = submission.problem.rating!;
    const bucket = Math.floor(rating / step) * step;
    if (bucket >= minRating && bucket <= maxRating) {
      ratingCounts.set(bucket, (ratingCounts.get(bucket) || 0) + 1);
    }
  });

  const ratingLabels = Array.from(ratingCounts.keys()).sort((a, b) => a - b);
  const ratingData = ratingLabels.map(rating => ratingCounts.get(rating) || 0);

  // Updated difficulty categorization
  const getDifficultyCategory = (problemRating: number) => {
    if (problemRating < 1100) return 'Very Easy';
    if (problemRating >= 1100 && problemRating < 1400) return 'Easy';
    if (problemRating >= 1400 && problemRating < 1700) return 'Moderate';
    if (problemRating >= 1700 && problemRating < 2000) return 'Hard';
    if (problemRating >= 2000) return 'Very Hard';
    return null;
  };

  const difficultyCounts = {
    'Very Easy': 0,
    'Easy': 0,
    'Moderate': 0,
    'Hard': 0,
    'Very Hard': 0
  };

  solvedProblemsArray.forEach(submission => {
    const category = getDifficultyCategory(submission.problem.rating!);
    if (category) {
      difficultyCounts[category as keyof typeof difficultyCounts]++;
    }
  });

  const histogramData = {
    labels: ratingLabels.map(r => `${r}-${r + step - 1}`),
    datasets: [
      {
        label: 'Problems Solved',
        data: ratingData,
        backgroundColor: ratingLabels.map(rating => {
          if (rating < 1100) return 'rgba(34, 197, 94, 0.8)';
          if (rating >= 1100 && rating < 1400) return 'rgba(59, 130, 246, 0.8)';
          if (rating >= 1400 && rating < 1700) return 'rgba(245, 158, 11, 0.8)';
          if (rating >= 1700 && rating < 2000) return 'rgba(239, 68, 68, 0.8)';
          if (rating >= 2000) return 'rgba(168, 85, 247, 0.8)';
          return 'rgba(156, 163, 175, 0.5)';
        }),
        borderColor: ratingLabels.map(rating => {
          if (rating < 1100) return 'rgba(34, 197, 94, 1)';
          if (rating >= 1100 && rating < 1400) return 'rgba(59, 130, 246, 1)';
          if (rating >= 1400 && rating < 1700) return 'rgba(245, 158, 11, 1)';
          if (rating >= 1700 && rating < 2000) return 'rgba(239, 68, 68, 1)';
          if (rating >= 2000) return 'rgba(168, 85, 247, 1)';
          return 'rgba(156, 163, 175, 0.8)';
        }),
        borderWidth: 2,
      },
    ],
  };

  const difficultyData = {
    labels: ['Very Easy', 'Easy', 'Moderate', 'Hard', 'Very Hard'],
    datasets: [
      {
        label: 'Problems Solved',
        data: [difficultyCounts['Very Easy'], difficultyCounts.Easy, difficultyCounts.Moderate, difficultyCounts.Hard, difficultyCounts['Very Hard']],
        backgroundColor: [
          'rgba(34, 197, 94, 0.8)',
          'rgba(59, 130, 246, 0.8)',
          'rgba(245, 158, 11, 0.8)',
          'rgba(239, 68, 68, 0.8)',
          'rgba(168, 85, 247, 0.8)',
        ],
        borderColor: [
          'rgba(34, 197, 94, 1)',
          'rgba(59, 130, 246, 1)',
          'rgba(245, 158, 11, 1)',
          'rgba(239, 68, 68, 1)',
          'rgba(168, 85, 247, 1)',
        ],
        borderWidth: 2,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: isDark ? 'rgba(15, 23, 42, 0.95)' : 'rgba(255, 255, 255, 0.95)',
        titleColor: isDark ? 'rgba(241, 245, 249, 1)' : 'rgba(17, 24, 39, 1)',
        bodyColor: isDark ? 'rgba(241, 245, 249, 0.8)' : 'rgba(17, 24, 39, 0.8)',
        borderColor: isDark ? 'rgba(51, 65, 85, 0.8)' : 'rgba(156, 163, 175, 0.3)',
        borderWidth: 1,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: isDark ? 'rgba(51, 65, 85, 0.4)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(241, 245, 249, 0.7)' : 'rgba(156, 163, 175, 0.8)',
        },
      },
      x: {
        grid: {
          color: isDark ? 'rgba(51, 65, 85, 0.4)' : 'rgba(156, 163, 175, 0.2)',
        },
        ticks: {
          color: isDark ? 'rgba(241, 245, 249, 0.7)' : 'rgba(156, 163, 175, 0.8)',
          maxRotation: 45,
        },
      },
    },
  };

  const totalCategorizedProblems = Object.values(difficultyCounts).reduce((sum, count) => sum + count, 0);
  const totalSolvedProblems = solvedProblemsArray.length;

  return (
    <div className="space-y-4 md:space-y-6">
      <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-xl md:rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
        <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 md:mb-6 flex items-center gap-2">
          <BarChart3 className="w-5 h-5 md:w-6 md:h-6 text-primary-500" />
          <span className="text-sm md:text-base">Problem Rating Distribution</span>
        </h3>
        
        <div className="mb-4 grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4 text-xs md:text-sm">
          <div className="text-center p-2 md:p-3 bg-primary-50 dark:bg-primary-900/30 rounded-lg border dark:border-primary-800/50">
            <div className="text-lg md:text-2xl font-bold text-primary-600 dark:text-primary-400">{totalSolvedProblems}</div>
            <div className="text-gray-600 dark:text-dark-300 text-xs md:text-sm">Total Solved</div>
          </div>
          <div className="text-center p-2 md:p-3 bg-secondary-50 dark:bg-secondary-900/30 rounded-lg border dark:border-secondary-800/50">
            <div className="text-lg md:text-2xl font-bold text-secondary-600 dark:text-secondary-400">{userRating}</div>
            <div className="text-gray-600 dark:text-dark-300 text-xs md:text-sm">Your Rating</div>
          </div>
          <div className="text-center p-2 md:p-3 bg-success-50 dark:bg-success-900/30 rounded-lg border dark:border-success-800/50">
            <div className="text-lg md:text-2xl font-bold text-success-600 dark:text-success-400">
              {solvedProblemsArray.filter(s => s.problem.rating! >= userRating).length}
            </div>
            <div className="text-gray-600 dark:text-dark-300 text-xs md:text-sm">Above Rating</div>
          </div>
          <div className="text-center p-2 md:p-3 bg-warning-50 dark:bg-warning-900/30 rounded-lg border dark:border-warning-800/50">
            <div className="text-lg md:text-2xl font-bold text-warning-600 dark:text-warning-400">
              {Math.max(...solvedProblemsArray.map(s => s.problem.rating!))}
            </div>
            <div className="text-gray-600 dark:text-dark-300 text-xs md:text-sm">Highest Solved</div>
          </div>
        </div>

        <div className="h-64 md:h-80">
          <Bar data={histogramData} options={chartOptions} />
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-center gap-3 md:gap-6 text-xs text-gray-500 dark:text-dark-400">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-500 rounded"></div>
            <span>Very Easy (&lt; 1100)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-blue-500 rounded"></div>
            <span>Easy (1100-1399)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-amber-500 rounded"></div>
            <span>Moderate (1400-1699)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-red-500 rounded"></div>
            <span>Hard (1700-1999)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-purple-500 rounded"></div>
            <span>Very Hard (≥2000)</span>
          </div>
        </div>
      </div>

      <div className="bg-white/90 dark:bg-dark-800/90 backdrop-blur-sm rounded-xl md:rounded-2xl shadow-xl p-4 md:p-6 border border-gray-200/50 dark:border-dark-700/50 dark:shadow-2xl dark:shadow-primary-500/10">
        <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-dark-100 mb-4 md:mb-6 flex items-center gap-2">
          <Target className="w-5 h-5 md:w-6 md:h-6 text-success-500" />
          <span className="text-sm md:text-base">Difficulty Category Analysis</span>
        </h3>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
          <div className="h-64 md:h-80">
            <Bar data={difficultyData} options={chartOptions} />
          </div>

          <div className="space-y-3 md:space-y-4">
            <div className="grid grid-cols-1 gap-2 md:gap-3">
              {Object.entries(difficultyCounts).map(([category, count], index) => {
                const colors = [
                  'from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200/50 dark:border-green-700/50',
                  'from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-blue-200/50 dark:border-blue-700/50',
                  'from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 border-amber-200/50 dark:border-amber-700/50',
                  'from-red-50 to-pink-50 dark:from-red-900/20 dark:to-pink-900/20 border-red-200/50 dark:border-red-700/50',
                  'from-purple-50 to-violet-50 dark:from-purple-900/20 dark:to-violet-900/20 border-purple-200/50 dark:border-purple-700/50',
                ];
                const textColors = [
                  'text-green-600 dark:text-green-400',
                  'text-blue-600 dark:text-blue-400',
                  'text-amber-600 dark:text-amber-400',
                  'text-red-600 dark:text-red-400',
                  'text-purple-600 dark:text-purple-400',
                ];

                return (
                  <div
                    key={category}
                    className={`bg-gradient-to-r ${colors[index]} rounded-lg md:rounded-xl p-3 md:p-4 border`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className={`text-lg md:text-xl font-bold ${textColors[index]}`}>
                          {count}
                        </div>
                        <div className="text-xs md:text-sm font-medium text-gray-700 dark:text-dark-300">
                          {category}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs text-gray-500 dark:text-dark-400">
                          {totalCategorizedProblems > 0 
                            ? `${Math.round((count / totalCategorizedProblems) * 100)}%`
                            : '0%'
                          }
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20 rounded-lg md:rounded-xl p-3 md:p-4 border border-purple-200/50 dark:border-purple-700/50">
              <h4 className="font-semibold text-purple-700 dark:text-purple-300 mb-2 md:mb-3 flex items-center gap-2">
                <Award className="w-4 h-4 md:w-5 md:h-5" />
                <span className="text-sm md:text-base">Difficulty Analysis</span>
              </h4>
              
              <div className="space-y-1 md:space-y-2 text-xs md:text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-dark-300">Problems in difficulty bands:</span>
                  <span className="font-semibold text-gray-900 dark:text-dark-100">
                    {totalCategorizedProblems} / {totalSolvedProblems}
                  </span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-dark-300">Coverage:</span>
                  <span className="font-semibold text-gray-900 dark:text-dark-100">
                    {totalSolvedProblems > 0 
                      ? `${Math.round((totalCategorizedProblems / totalSolvedProblems) * 100)}%`
                      : '0%'
                    }
                  </span>
                </div>

                {difficultyCounts['Very Hard'] > 0 && (
                  <div className="pt-2 border-t border-purple-200/50 dark:border-purple-700/50">
                    <div className="flex items-center gap-2 text-purple-600 dark:text-purple-400">
                      <TrendingUp className="w-3 h-3 md:w-4 md:h-4" />
                      <span className="font-medium text-xs md:text-sm">
                        Great job solving {difficultyCounts['Very Hard']} very hard problems!
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}