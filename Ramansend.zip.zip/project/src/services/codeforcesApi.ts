import { User, RatingChange, Submission, BlogEntry, ApiResponse, Contest } from '../types/codeforces';

const BASE_URL = 'https://codeforces.com/api';

class CodeforcesApiError extends Error {
  constructor(message: string, public status?: string) {
    super(message);
    this.name = 'CodeforcesApiError';
  }
}

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

async function apiCall<T>(endpoint: string, retries = 3): Promise<T> {
  for (let i = 0; i < retries; i++) {
    try {
      const response = await fetch(`${BASE_URL}${endpoint}`);
      
      if (!response.ok) {
        let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
        
        // Provide more specific error messages for common cases
        if (response.status === 400) {
          if (!response.statusText || response.statusText.trim() === '') {
            errorMessage = 'Bad Request. This often means the Codeforces handle is invalid or malformed.';
          } else {
            errorMessage = `Bad Request: ${response.statusText}`;
          }
        } else if (response.status === 429) {
          errorMessage = 'Too Many Requests. You have exceeded the API rate limit. Please wait a minute before trying again.';
        }
        
        throw new CodeforcesApiError(errorMessage, response.status.toString());
      }
      
      const data: ApiResponse<T> = await response.json();
      
      if (data.status !== 'OK') {
        throw new CodeforcesApiError(`API Error: ${data.comment || data.status}`);
      }
      
      return data.result;
    } catch (error) {
      console.error(`API call failed (attempt ${i + 1}):`, error);
      if (i === retries - 1) {
        // On the last retry, ensure we throw a CodeforcesApiError
        if (error instanceof CodeforcesApiError) {
          throw error;
        } else {
          throw new CodeforcesApiError(`Network or API error: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
      }
      await delay(1000 * (i + 1)); // Exponential backoff
    }
  }
  throw new Error('Max retries exceeded');
}

export async function getUserInfo(handle: string): Promise<User> {
  const users = await apiCall<User[]>(`/user.info?handles=${handle}`);
  if (users.length === 0) {
    throw new CodeforcesApiError(`User "${handle}" not found`);
  }
  return users[0];
}

export async function getUserRating(handle: string): Promise<RatingChange[]> {
  try {
    return await apiCall<RatingChange[]>(`/user.rating?handle=${handle}`);
  } catch (error) {
    // User might not have participated in rated contests
    return [];
  }
}

export async function getUserSubmissions(handle: string, count = 10000): Promise<Submission[]> {
  try {
    return await apiCall<Submission[]>(`/user.status?handle=${handle}&from=1&count=${count}`);
  } catch (error) {
    return [];
  }
}

export async function getUserBlogEntries(handle: string): Promise<BlogEntry[]> {
  try {
    return await apiCall<BlogEntry[]>(`/user.blogEntries?handle=${handle}`);
  } catch (error) {
    // Log the error for debugging purposes
    console.error('Failed to fetch user blog entries:', error);
    // Always return empty array on any error
    return [];
  }
}

export async function getUpcomingContests(): Promise<Contest[]> {
  try {
    const contests = await apiCall<Contest[]>('/contest.list?gym=false');
    const now = Math.floor(Date.now() / 1000);
    
    console.log('All contests:', contests.length);
    console.log('Current timestamp:', now);
    
    // Filter for truly upcoming contests
    const upcomingContests = contests.filter(contest => {
      const isUpcoming = contest.phase === 'BEFORE';
      const isFuture = contest.startTimeSeconds > now;
      const isCodeforces = contest.type === 'CF' || contest.type === 'ICPC'; // Include both CF and ICPC contests
      
      console.log(`Contest ${contest.name}:`, {
        phase: contest.phase,
        startTime: contest.startTimeSeconds,
        now: now,
        isUpcoming,
        isFuture,
        isCodeforces,
        type: contest.type
      });
      
      return isUpcoming && isFuture && isCodeforces;
    });
    
    console.log('Filtered upcoming contests:', upcomingContests.length);
    
    // Sort by start time and return top 5
    const sortedContests = upcomingContests
      .sort((a, b) => a.startTimeSeconds - b.startTimeSeconds)
      .slice(0, 5);
    
    console.log('Final contests to show:', sortedContests.map(c => ({
      name: c.name,
      startTime: new Date(c.startTimeSeconds * 1000).toISOString(),
      phase: c.phase,
      type: c.type
    })));
    
    return sortedContests;
  } catch (error) {
    console.error('Failed to fetch upcoming contests:', error);
    return [];
  }
}

// New function to get practice problems
export async function getPracticeProblems(tag: string): Promise<any[]> {
  try {
    const response = await apiCall<{ problems: any[]; problemStatistics: any[] }>('/problemset.problems');
    const { problems, problemStatistics } = response;
    
    // Filter problems by tag and rating range (800-1700)
    const filteredProblems = problems
      .filter(problem => 
        problem.tags.includes(tag) &&
        problem.rating >= 800 && 
        problem.rating <= 1700
      )
      .map(problem => {
        // Find corresponding statistics
        const stats = problemStatistics.find(stat => 
          stat.contestId === problem.contestId && stat.index === problem.index
        );
        return {
          ...problem,
          solvedCount: stats ? stats.solvedCount : 0
        };
      });

    // Group by rating and pick the most solved problem from each rating level
    const problemsByRating = new Map<number, any[]>();
    
    filteredProblems.forEach(problem => {
      const rating = problem.rating;
      if (!problemsByRating.has(rating)) {
        problemsByRating.set(rating, []);
      }
      problemsByRating.get(rating)!.push(problem);
    });

    // Select the most solved problem from each rating level
    const selectedProblems: any[] = [];
    
    for (let rating = 800; rating <= 1700; rating += 100) {
      const problemsAtRating = problemsByRating.get(rating) || [];
      if (problemsAtRating.length > 0) {
        // Sort by solved count (descending) and pick the most solved
        const mostSolved = problemsAtRating.sort((a, b) => b.solvedCount - a.solvedCount)[0];
        selectedProblems.push(mostSolved);
      }
    }

    // If we don't have enough problems, fill with next most solved problems
    if (selectedProblems.length < 10) {
      const remainingProblems = filteredProblems
        .filter(p => !selectedProblems.some(sp => sp.contestId === p.contestId && sp.index === p.index))
        .sort((a, b) => b.solvedCount - a.solvedCount)
        .slice(0, 10 - selectedProblems.length);
      
      selectedProblems.push(...remainingProblems);
    }

    return selectedProblems.slice(0, 10);
  } catch (error) {
    console.error('Failed to fetch practice problems:', error);
    return [];
  }
}

export { CodeforcesApiError };