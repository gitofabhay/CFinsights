import axios from 'axios';

const CF_API_BASE = process.env.CF_API_BASE || 'https://codeforces.com/api';

class CodeforcesService {
    async getUserInfo(handle) {
        try {
            const response = await axios.get(`${CF_API_BASE}/user.info?handles=${handle}`);
            if (response.data.status !== 'OK') {
                throw new Error(response.data.comment || 'Failed to fetch user info');
            }
            return response.data.result[0];
        } catch (error) {
            throw new Error(`Failed to fetch user info: ${error.message}`);
        }
    }

    async getUserSubmissions(handle, count = 10000) {
        try {
            const response = await axios.get(`${CF_API_BASE}/user.status?handle=${handle}&from=1&count=${count}`);
            if (response.data.status !== 'OK') {
                throw new Error(response.data.comment || 'Failed to fetch submissions');
            }
            return response.data.result;
        } catch (error) {
            throw new Error(`Failed to fetch submissions: ${error.message}`);
        }
    }

    async getProblems() {
        try {
            const response = await axios.get(`${CF_API_BASE}/problemset.problems`);
            if (response.data.status !== 'OK') {
                throw new Error(response.data.comment || 'Failed to fetch problems');
            }
            return response.data.result;
        } catch (error) {
            throw new Error(`Failed to fetch problems: ${error.message}`);
        }
    }

    async getRandomVerificationProblem() {
        try {
            const { problems } = await this.getProblems();
            
            // Filter problems with rating 800-1200 for verification
            const verificationProblems = problems.filter(p => 
                p.rating >= 800 && 
                p.rating <= 1200 && 
                p.contestId && 
                p.index
            );

            if (verificationProblems.length === 0) {
                throw new Error('No suitable verification problems found');
            }

            const randomIndex = Math.floor(Math.random() * verificationProblems.length);
            return verificationProblems[randomIndex];
        } catch (error) {
            throw new Error(`Failed to get verification problem: ${error.message}`);
        }
    }

    async verifySubmission(handle, problemContestId, problemIndex, timeWindow = 10) {
        try {
            const submissions = await this.getUserSubmissions(handle, 10);
            const cutoffTime = Date.now() / 1000 - (timeWindow * 60); // 10 minutes ago

            // Find the most recent submission for the assigned problem
            const recentSubmission = submissions.find(sub => 
                sub.problem.contestId === problemContestId &&
                sub.problem.index === problemIndex &&
                sub.creationTimeSeconds >= cutoffTime
            );

            return !!recentSubmission;
        } catch (error) {
            throw new Error(`Failed to verify submission: ${error.message}`);
        }
    }
}

export default new CodeforcesService();