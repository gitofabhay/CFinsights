import db from '../config/database.js';
import codeforcesService from './codeforcesService.js';

class ReportService {
    async generateDailyReport(cfHandle, date = new Date()) {
        const dateStr = date.toISOString().split('T')[0];
        const startOfDay = new Date(date);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(date);
        endOfDay.setHours(23, 59, 59, 999);

        const startTimestamp = Math.floor(startOfDay.getTime() / 1000);
        const endTimestamp = Math.floor(endOfDay.getTime() / 1000);

        // Get submissions for the day
        const submissions = await db.all(
            `SELECT * FROM submissions 
             WHERE cf_handle = ? AND creation_time BETWEEN ? AND ?
             ORDER BY creation_time DESC`,
            [cfHandle, startTimestamp, endTimestamp]
        );

        const problemsAttempted = new Set();
        const problemsSolved = new Set();
        const unsolvedProblems = [];
        const topicAccuracy = {};

        submissions.forEach(sub => {
            const problemKey = `${sub.problem_contest_id}-${sub.problem_index}`;
            problemsAttempted.add(problemKey);

            if (sub.verdict === 'OK') {
                problemsSolved.add(problemKey);
            } else {
                // Add to unsolved if not already solved
                if (!problemsSolved.has(problemKey)) {
                    const existing = unsolvedProblems.find(p => 
                        p.contestId === sub.problem_contest_id && p.index === sub.problem_index
                    );
                    if (!existing) {
                        unsolvedProblems.push({
                            contestId: sub.problem_contest_id,
                            index: sub.problem_index,
                            name: sub.problem_name,
                            rating: sub.problem_rating,
                            tags: JSON.parse(sub.problem_tags || '[]'),
                            lastAttempt: sub.creation_time,
                            verdict: sub.verdict
                        });
                    }
                }
            }

            // Track topic accuracy
            const tags = JSON.parse(sub.problem_tags || '[]');
            tags.forEach(tag => {
                if (!topicAccuracy[tag]) {
                    topicAccuracy[tag] = { solved: 0, attempted: 0 };
                }
                topicAccuracy[tag].attempted++;
                if (sub.verdict === 'OK') {
                    topicAccuracy[tag].solved++;
                }
            });
        });

        // Calculate score (out of 10)
        const score = this.calculateDailyScore(problemsAttempted.size, problemsSolved.size, topicAccuracy);

        // Limit unsolved problems to 6
        const limitedUnsolved = unsolvedProblems.slice(0, 6);

        const reportData = {
            date: dateStr,
            problemsAttempted: problemsAttempted.size,
            problemsSolved: problemsSolved.size,
            unsolvedProblems: limitedUnsolved,
            score,
            topicAccuracy,
            totalSubmissions: submissions.length
        };

        // Cache the report
        await db.run(
            `INSERT OR REPLACE INTO daily_dashboard 
             (cf_handle, date, problems_attempted, problems_solved, unsolved_problems, score, topic_accuracy)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
                cfHandle,
                dateStr,
                reportData.problemsAttempted,
                reportData.problemsSolved,
                JSON.stringify(reportData.unsolvedProblems),
                reportData.score,
                JSON.stringify(reportData.topicAccuracy)
            ]
        );

        return reportData;
    }

    calculateDailyScore(attempted, solved, topicAccuracy) {
        if (attempted === 0) return 0;

        const solveRate = solved / attempted;
        const baseScore = solveRate * 6; // Max 6 points for solve rate

        // Bonus points for variety and difficulty
        const topicCount = Object.keys(topicAccuracy).length;
        const varietyBonus = Math.min(topicCount * 0.5, 2); // Max 2 points for variety

        // Efficiency bonus
        const avgAccuracy = Object.values(topicAccuracy).reduce((sum, topic) => 
            sum + (topic.solved / topic.attempted), 0) / Object.keys(topicAccuracy).length;
        const efficiencyBonus = avgAccuracy * 2; // Max 2 points for efficiency

        return Math.min(baseScore + varietyBonus + efficiencyBonus, 10);
    }

    async generateWeeklyReport(cfHandle, weekStart) {
        // Implementation for weekly report
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekEnd.getDate() + 6);

        // Get daily reports for the week
        const dailyReports = await db.all(
            `SELECT * FROM daily_dashboard 
             WHERE cf_handle = ? AND date BETWEEN ? AND ?
             ORDER BY date`,
            [cfHandle, weekStart.toISOString().split('T')[0], weekEnd.toISOString().split('T')[0]]
        );

        const weeklyData = {
            weekStart: weekStart.toISOString().split('T')[0],
            weekEnd: weekEnd.toISOString().split('T')[0],
            dailyReports: dailyReports.map(report => ({
                ...report,
                unsolved_problems: JSON.parse(report.unsolved_problems || '[]'),
                topic_accuracy: JSON.parse(report.topic_accuracy || '{}')
            })),
            totalProblemsAttempted: dailyReports.reduce((sum, r) => sum + r.problems_attempted, 0),
            totalProblemsSolved: dailyReports.reduce((sum, r) => sum + r.problems_solved, 0),
            averageScore: dailyReports.length > 0 ? 
                dailyReports.reduce((sum, r) => sum + r.score, 0) / dailyReports.length : 0,
            activeDays: dailyReports.filter(r => r.problems_attempted > 0).length
        };

        return weeklyData;
    }

    async generateMonthlyReport(cfHandle, month, year) {
        // Implementation for monthly report
        const startDate = new Date(year, month - 1, 1);
        const endDate = new Date(year, month, 0);

        const submissions = await db.all(
            `SELECT * FROM submissions 
             WHERE cf_handle = ? AND creation_time BETWEEN ? AND ?
             ORDER BY creation_time`,
            [cfHandle, Math.floor(startDate.getTime() / 1000), Math.floor(endDate.getTime() / 1000)]
        );

        // Analyze monthly trends, growth, tag coverage, etc.
        const monthlyData = {
            month,
            year,
            totalSubmissions: submissions.length,
            uniqueProblems: new Set(submissions.filter(s => s.verdict === 'OK')
                .map(s => `${s.problem_contest_id}-${s.problem_index}`)).size,
            // Add more monthly analytics
        };

        return monthlyData;
    }
}

export default new ReportService();