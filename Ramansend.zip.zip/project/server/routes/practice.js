import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import db from '../config/database.js';
import codeforcesService from '../services/codeforcesService.js';

const router = express.Router();

// Generate practice problems for a tag
router.post('/generate/:tag', authenticateToken, async (req, res) => {
    try {
        const { tag } = req.params;
        const { rating, count = 10 } = req.body;

        // Get problems from Codeforces API
        const { problems, problemStatistics } = await codeforcesService.getProblems();

        // Filter problems by tag and rating
        let filteredProblems = problems.filter(problem => 
            problem.tags.includes(tag) &&
            problem.rating >= (rating - 200) && 
            problem.rating <= (rating + 200) &&
            problem.contestId &&
            problem.index
        );

        // Add solve count from statistics
        filteredProblems = filteredProblems.map(problem => {
            const stats = problemStatistics.find(stat => 
                stat.contestId === problem.contestId && stat.index === problem.index
            );
            return {
                ...problem,
                solvedCount: stats ? stats.solvedCount : 0
            };
        });

        // Sort by solve count (most solved first for better learning)
        filteredProblems.sort((a, b) => b.solvedCount - a.solvedCount);

        // Take requested count
        const selectedProblems = filteredProblems.slice(0, count);

        // Store practice session
        await db.run(
            `INSERT INTO practice_sessions (user_id, tag, problems_assigned)
             VALUES (?, ?, ?)`,
            [req.user.id, tag, JSON.stringify(selectedProblems)]
        );

        res.json({
            tag,
            problems: selectedProblems,
            totalAvailable: filteredProblems.length
        });

    } catch (error) {
        console.error('Practice generation error:', error);
        res.status(500).json({ error: 'Failed to generate practice problems' });
    }
});

// Mark problem as solved
router.post('/mark-solved', authenticateToken, async (req, res) => {
    try {
        const { contestId, index } = req.body;

        // Get latest practice session
        const session = await db.get(
            `SELECT * FROM practice_sessions 
             WHERE user_id = ? ORDER BY created_at DESC LIMIT 1`,
            [req.user.id]
        );

        if (!session) {
            return res.status(404).json({ error: 'No active practice session found' });
        }

        const completedProblems = JSON.parse(session.problems_completed || '[]');
        const problemId = `${contestId}-${index}`;

        if (!completedProblems.includes(problemId)) {
            completedProblems.push(problemId);
            
            await db.run(
                'UPDATE practice_sessions SET problems_completed = ? WHERE id = ?',
                [JSON.stringify(completedProblems), session.id]
            );
        }

        res.json({ message: 'Problem marked as solved', completedCount: completedProblems.length });

    } catch (error) {
        console.error('Mark solved error:', error);
        res.status(500).json({ error: 'Failed to mark problem as solved' });
    }
});

// Get weak areas analysis
router.get('/weak-areas', authenticateToken, async (req, res) => {
    try {
        // Get recent failed submissions
        const failedSubmissions = await db.all(
            `SELECT problem_tags, verdict FROM submissions 
             WHERE cf_handle = ? AND verdict != 'OK' AND verdict IS NOT NULL
             ORDER BY creation_time DESC LIMIT 100`,
            [req.user.cf_handle]
        );

        const tagFailures = {};
        
        failedSubmissions.forEach(sub => {
            const tags = JSON.parse(sub.problem_tags || '[]');
            tags.forEach(tag => {
                tagFailures[tag] = (tagFailures[tag] || 0) + 1;
            });
        });

        // Get top 5 weak areas
        const weakAreas = Object.entries(tagFailures)
            .sort(([,a], [,b]) => b - a)
            .slice(0, 5)
            .map(([tag, failures]) => ({
                tag,
                failures,
                percentage: Math.round((failures / failedSubmissions.length) * 100)
            }));

        res.json(weakAreas);

    } catch (error) {
        console.error('Weak areas error:', error);
        res.status(500).json({ error: 'Failed to analyze weak areas' });
    }
});

export default router;