import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import db from '../config/database.js';
import reportService from '../services/reportService.js';

const router = express.Router();

// Get daily dashboard
router.get('/daily/:date?', authenticateToken, async (req, res) => {
    try {
        const date = req.params.date ? new Date(req.params.date) : new Date();
        const dateStr = date.toISOString().split('T')[0];

        // Check if report exists in cache
        let dashboard = await db.get(
            'SELECT * FROM daily_dashboard WHERE cf_handle = ? AND date = ?',
            [req.user.cf_handle, dateStr]
        );

        if (!dashboard) {
            // Generate new report
            dashboard = await reportService.generateDailyReport(req.user.cf_handle, date);
        } else {
            // Parse JSON fields
            dashboard.unsolved_problems = JSON.parse(dashboard.unsolved_problems || '[]');
            dashboard.topic_accuracy = JSON.parse(dashboard.topic_accuracy || '{}');
        }

        res.json(dashboard);
    } catch (error) {
        console.error('Dashboard error:', error);
        res.status(500).json({ error: 'Failed to generate dashboard' });
    }
});

// Get weekly report
router.get('/weekly/:weekStart', authenticateToken, async (req, res) => {
    try {
        const weekStart = new Date(req.params.weekStart);
        const report = await reportService.generateWeeklyReport(req.user.cf_handle, weekStart);
        res.json(report);
    } catch (error) {
        console.error('Weekly report error:', error);
        res.status(500).json({ error: 'Failed to generate weekly report' });
    }
});

// Get monthly report
router.get('/monthly/:year/:month', authenticateToken, async (req, res) => {
    try {
        const year = parseInt(req.params.year);
        const month = parseInt(req.params.month);
        const report = await reportService.generateMonthlyReport(req.user.cf_handle, month, year);
        res.json(report);
    } catch (error) {
        console.error('Monthly report error:', error);
        res.status(500).json({ error: 'Failed to generate monthly report' });
    }
});

// Get heatmap data
router.get('/heatmap/:type/:period?', authenticateToken, async (req, res) => {
    try {
        const { type, period } = req.params; // type: daily, weekly, monthly, yearly
        
        let startDate, endDate;
        const now = new Date();

        switch (type) {
            case 'daily':
                startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 365);
                endDate = now;
                break;
            case 'weekly':
                startDate = new Date(now.getFullYear(), now.getMonth() - 12, 1);
                endDate = now;
                break;
            case 'monthly':
                startDate = new Date(now.getFullYear() - 2, 0, 1);
                endDate = now;
                break;
            case 'yearly':
                startDate = new Date(now.getFullYear() - 5, 0, 1);
                endDate = now;
                break;
            default:
                return res.status(400).json({ error: 'Invalid heatmap type' });
        }

        const submissions = await db.all(
            `SELECT creation_time, verdict, problem_tags FROM submissions 
             WHERE cf_handle = ? AND creation_time BETWEEN ? AND ?`,
            [req.user.cf_handle, Math.floor(startDate.getTime() / 1000), Math.floor(endDate.getTime() / 1000)]
        );

        // Process submissions into heatmap data
        const heatmapData = this.processHeatmapData(submissions, type);

        res.json(heatmapData);
    } catch (error) {
        console.error('Heatmap error:', error);
        res.status(500).json({ error: 'Failed to generate heatmap' });
    }
});

export default router;