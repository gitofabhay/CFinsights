import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import db from '../config/database.js';

const router = express.Router();

// Add bookmark
router.post('/', authenticateToken, async (req, res) => {
    try {
        const { contestId, index, name, rating, tags } = req.body;

        if (!contestId || !index) {
            return res.status(400).json({ error: 'Contest ID and index are required' });
        }

        await db.run(
            `INSERT OR IGNORE INTO bookmarks 
             (user_id, problem_contest_id, problem_index, problem_name, problem_rating, problem_tags)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [req.user.id, contestId, index, name, rating, JSON.stringify(tags || [])]
        );

        res.json({ message: 'Bookmark added successfully' });

    } catch (error) {
        console.error('Bookmark add error:', error);
        res.status(500).json({ error: 'Failed to add bookmark' });
    }
});

// Get all bookmarks
router.get('/', authenticateToken, async (req, res) => {
    try {
        const bookmarks = await db.all(
            `SELECT problem_contest_id, problem_index, problem_name, problem_rating, problem_tags, created_at
             FROM bookmarks WHERE user_id = ? ORDER BY created_at DESC`,
            [req.user.id]
        );

        const formattedBookmarks = bookmarks.map(bookmark => ({
            contestId: bookmark.problem_contest_id,
            index: bookmark.problem_index,
            name: bookmark.problem_name,
            rating: bookmark.problem_rating,
            tags: JSON.parse(bookmark.problem_tags || '[]'),
            createdAt: bookmark.created_at
        }));

        res.json(formattedBookmarks);

    } catch (error) {
        console.error('Bookmarks fetch error:', error);
        res.status(500).json({ error: 'Failed to fetch bookmarks' });
    }
});

// Remove bookmark
router.delete('/:contestId/:index', authenticateToken, async (req, res) => {
    try {
        const { contestId, index } = req.params;

        await db.run(
            'DELETE FROM bookmarks WHERE user_id = ? AND problem_contest_id = ? AND problem_index = ?',
            [req.user.id, contestId, index]
        );

        res.json({ message: 'Bookmark removed successfully' });

    } catch (error) {
        console.error('Bookmark remove error:', error);
        res.status(500).json({ error: 'Failed to remove bookmark' });
    }
});

export default router;