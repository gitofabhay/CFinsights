import express from 'express';
import bcrypt from 'bcryptjs';
import { generateToken } from '../middleware/auth.js';
import db from '../config/database.js';
import codeforcesService from '../services/codeforcesService.js';

const router = express.Router();

// Register endpoint
router.post('/register', async (req, res) => {
    try {
        const { username, cfHandle, password } = req.body;

        // Validation
        if (!username || !cfHandle || !password) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        if (username.length < 3 || username.length > 20) {
            return res.status(400).json({ error: 'Username must be 3-20 characters' });
        }

        if (password.length < 6) {
            return res.status(400).json({ error: 'Password must be at least 6 characters' });
        }

        // Check if username or cf_handle already exists
        const existingUser = await db.get(
            'SELECT id FROM users WHERE username = ? OR cf_handle = ?',
            [username, cfHandle]
        );

        if (existingUser) {
            return res.status(400).json({ error: 'Username or Codeforces handle already registered' });
        }

        // Verify CF handle exists
        try {
            await codeforcesService.getUserInfo(cfHandle);
        } catch (error) {
            return res.status(400).json({ error: 'Invalid Codeforces handle' });
        }

        // Get random verification problem
        const verificationProblem = await codeforcesService.getRandomVerificationProblem();
        const verificationCode = Math.random().toString(36).substring(2, 15);
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

        // Hash password
        const passwordHash = await bcrypt.hash(password, 12);

        // Create user (unverified)
        const result = await db.run(
            'INSERT INTO users (username, password_hash, cf_handle, verified) VALUES (?, ?, ?, 0)',
            [username, passwordHash, cfHandle]
        );

        // Store verification challenge
        await db.run(
            `INSERT INTO cf_verifications 
             (username, cf_handle, assigned_problem_id, assigned_problem_name, verification_code, expires_at)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [
                username,
                cfHandle,
                `${verificationProblem.contestId}${verificationProblem.index}`,
                verificationProblem.name,
                verificationCode,
                expiresAt.toISOString()
            ]
        );

        res.status(201).json({
            message: 'Registration initiated. Please complete verification.',
            verificationChallenge: {
                problemId: `${verificationProblem.contestId}${verificationProblem.index}`,
                problemName: verificationProblem.name,
                contestId: verificationProblem.contestId,
                index: verificationProblem.index,
                expiresAt: expiresAt.toISOString(),
                instructions: `Please submit any solution to problem ${verificationProblem.contestId}${verificationProblem.index} on Codeforces within 10 minutes, then click "Verify Submission".`
            }
        });

    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Verify submission endpoint
router.post('/verify-submission', async (req, res) => {
    try {
        const { username } = req.body;

        if (!username) {
            return res.status(400).json({ error: 'Username is required' });
        }

        // Get verification challenge
        const verification = await db.get(
            `SELECT * FROM cf_verifications 
             WHERE username = ? AND completed = 0 AND expires_at > datetime('now')
             ORDER BY created_at DESC LIMIT 1`,
            [username]
        );

        if (!verification) {
            return res.status(400).json({ error: 'No active verification found or verification expired' });
        }

        // Extract contest ID and index from problem ID
        const problemId = verification.assigned_problem_id;
        const contestId = parseInt(problemId.slice(0, -1));
        const index = problemId.slice(-1);

        // Verify submission exists
        const submissionExists = await codeforcesService.verifySubmission(
            verification.cf_handle,
            contestId,
            index,
            10 // 10 minutes window
        );

        if (!submissionExists) {
            return res.status(400).json({ 
                error: 'No recent submission found for the assigned problem. Please submit and try again.' 
            });
        }

        // Mark verification as completed
        await db.run(
            'UPDATE cf_verifications SET completed = 1 WHERE id = ?',
            [verification.id]
        );

        // Mark user as verified
        await db.run(
            'UPDATE users SET verified = 1 WHERE username = ?',
            [username]
        );

        // Get user for token generation
        const user = await db.get(
            'SELECT id, username, cf_handle FROM users WHERE username = ?',
            [username]
        );

        const token = generateToken(user.id);

        res.json({
            message: 'Verification successful! Welcome to CFInsights Alpha.',
            token,
            user: {
                id: user.id,
                username: user.username,
                cfHandle: user.cf_handle
            }
        });

    } catch (error) {
        console.error('Verification error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Login endpoint
router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ error: 'Username and password are required' });
        }

        // Get user
        const user = await db.get(
            'SELECT id, username, password_hash, cf_handle, verified FROM users WHERE username = ?',
            [username]
        );

        if (!user) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        if (!user.verified) {
            return res.status(401).json({ error: 'Account not verified. Please complete registration.' });
        }

        // Verify password
        const passwordValid = await bcrypt.compare(password, user.password_hash);
        if (!passwordValid) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        // Update last login
        await db.run(
            'UPDATE users SET last_login = datetime("now") WHERE id = ?',
            [user.id]
        );

        const token = generateToken(user.id);

        res.json({
            message: 'Login successful',
            token,
            user: {
                id: user.id,
                username: user.username,
                cfHandle: user.cf_handle
            }
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

export default router;