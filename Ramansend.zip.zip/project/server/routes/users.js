import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import db from '../config/database.js';

const router = express.Router();

// Get current user info
router.get('/me', authenticateToken, async (req, res) => {
    try {
        const user = await db.get(
            'SELECT id, username, cf_handle, email, created_at, last_login FROM users WHERE id = ?',
            [req.user.id]
        );

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json(user);
    } catch (error) {
        console.error('Get user error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Update user preferences
router.put('/preferences', authenticateToken, async (req, res) => {
    try {
        const { preferences } = req.body;

        if (!preferences) {
            return res.status(400).json({ error: 'Preferences are required' });
        }

        await db.run(
            'UPDATE users SET preferences = ? WHERE id = ?',
            [JSON.stringify(preferences), req.user.id]
        );

        res.json({ message: 'Preferences updated successfully' });
    } catch (error) {
        console.error('Update preferences error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Change password
router.put('/password', authenticateToken, async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;

        if (!currentPassword || !newPassword) {
            return res.status(400).json({ error: 'Current and new passwords are required' });
        }

        if (newPassword.length < 6) {
            return res.status(400).json({ error: 'New password must be at least 6 characters' });
        }

        // Get current user with password
        const user = await db.get(
            'SELECT password_hash FROM users WHERE id = ?',
            [req.user.id]
        );

        // Verify current password
        const isValid = await bcrypt.compare(currentPassword, user.password_hash);
        if (!isValid) {
            return res.status(401).json({ error: 'Current password is incorrect' });
        }

        // Hash new password
        const newPasswordHash = await bcrypt.hash(newPassword, 12);

        // Update password
        await db.run(
            'UPDATE users SET password_hash = ? WHERE id = ?',
            [newPasswordHash, req.user.id]
        );

        res.json({ message: 'Password updated successfully' });
    } catch (error) {
        console.error('Change password error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Get user activity log
router.get('/activity', authenticateToken, async (req, res) => {
    try {
        const { limit = 20, offset = 0 } = req.query;

        const activities = await db.all(
            `SELECT action, details, timestamp FROM activity_log 
             WHERE user_id = ? ORDER BY timestamp DESC LIMIT ? OFFSET ?`,
            [req.user.id, limit, offset]
        );

        const formattedActivities = activities.map(activity => ({
            ...activity,
            details: JSON.parse(activity.details || '{}')
        }));

        res.json(formattedActivities);
    } catch (error) {
        console.error('Activity log error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

export default router;