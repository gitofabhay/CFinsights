import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import db from '../config/database.js';

const router = express.Router();

// Add or update note for a problem
router.post('/', authenticateToken, async (req, res) => {
    try {
        const { contestId, index, content } = req.body;

        if (!contestId || !index || !content) {
            return res.status(400).json({ error: 'Contest ID, index, and content are required' });
        }

        await db.run(
            `INSERT OR REPLACE INTO notes (user_id, problem_contest_id, problem_index, content, updated_at)
             VALUES (?, ?, ?, ?, datetime('now'))`,
            [req.user.id, contestId, index, content]
        );

        res.json({ message: 'Note saved successfully' });

    } catch (error) {
        console.error('Note save error:', error);
        res.status(500).json({ error: 'Failed to save note' });
    }
});

// Get note for a problem
router.get('/:contestId/:index', authenticateToken, async (req, res) => {
    try {
        const { contestId, index } = req.params;

        const note = await db.get(
            'SELECT content, created_at, updated_at FROM notes WHERE user_id = ? AND problem_contest_id = ? AND problem_index = ?',
            [req.user.id, contestId, index]
        );

        res.json(note || null);

    } catch (error) {
        console.error('Note fetch error:', error);
        res.status(500).json({ error: 'Failed to fetch note' });
    }
});

// Delete note
router.delete('/:contestId/:index', authenticateToken, async (req, res) => {
    try {
        const { contestId, index } = req.params;

        await db.run(
            'DELETE FROM notes WHERE user_id = ? AND problem_contest_id = ? AND problem_index = ?',
            [req.user.id, contestId, index]
        );

        res.json({ message: 'Note deleted successfully' });

    } catch (error) {
        console.error('Note delete error:', error);
        res.status(500).json({ error: 'Failed to delete note' });
    }
});

export default router;