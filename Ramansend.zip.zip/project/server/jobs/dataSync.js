import cron from 'node-cron';
import db from '../config/database.js';
import codeforcesService from '../services/codeforcesService.js';
import reportService from '../services/reportService.js';

class DataSyncJobs {
    constructor() {
        this.setupJobs();
    }

    setupJobs() {
        // Pull submissions from CF API (5:55 PM IST daily)
        cron.schedule('25 12 * * *', async () => { // 12:25 UTC = 5:55 PM IST
            console.log('Starting daily submission sync...');
            await this.syncAllUserSubmissions();
        });

        // Generate daily reports (6:00 PM IST daily)
        cron.schedule('30 12 * * *', async () => { // 12:30 UTC = 6:00 PM IST
            console.log('Starting daily report generation...');
            await this.generateDailyReports();
        });

        // Generate weekly reports (Sunday)
        cron.schedule('0 13 * * 0', async () => { // 1:00 PM UTC on Sunday
            console.log('Starting weekly report generation...');
            await this.generateWeeklyReports();
        });

        // Generate monthly reports (1st of month)
        cron.schedule('0 14 1 * *', async () => { // 2:00 PM UTC on 1st
            console.log('Starting monthly report generation...');
            await this.generateMonthlyReports();
        });
    }

    async syncAllUserSubmissions() {
        try {
            const users = await db.all('SELECT cf_handle FROM users WHERE verified = 1');
            
            for (const user of users) {
                try {
                    await this.syncUserSubmissions(user.cf_handle);
                    // Add delay to respect rate limits
                    await new Promise(resolve => setTimeout(resolve, 2000));
                } catch (error) {
                    console.error(`Failed to sync submissions for ${user.cf_handle}:`, error);
                }
            }
            
            console.log(`✓ Synced submissions for ${users.length} users`);
        } catch (error) {
            console.error('Submission sync error:', error);
        }
    }

    async syncUserSubmissions(cfHandle) {
        try {
            const submissions = await codeforcesService.getUserSubmissions(cfHandle);
            
            for (const submission of submissions) {
                await db.run(
                    `INSERT OR IGNORE INTO submissions 
                     (cf_handle, submission_id, problem_contest_id, problem_index, problem_name, 
                      problem_rating, problem_tags, verdict, programming_language, creation_time,
                      time_consumed_millis, memory_consumed_bytes)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [
                        cfHandle,
                        submission.id,
                        submission.problem.contestId,
                        submission.problem.index,
                        submission.problem.name,
                        submission.problem.rating,
                        JSON.stringify(submission.problem.tags),
                        submission.verdict,
                        submission.programmingLanguage,
                        submission.creationTimeSeconds,
                        submission.timeConsumedMillis,
                        submission.memoryConsumedBytes
                    ]
                );
            }
        } catch (error) {
            throw new Error(`Failed to sync submissions for ${cfHandle}: ${error.message}`);
        }
    }

    async generateDailyReports() {
        try {
            const users = await db.all('SELECT cf_handle FROM users WHERE verified = 1');
            const today = new Date();
            
            for (const user of users) {
                try {
                    await reportService.generateDailyReport(user.cf_handle, today);
                } catch (error) {
                    console.error(`Failed to generate daily report for ${user.cf_handle}:`, error);
                }
            }
            
            console.log(`✓ Generated daily reports for ${users.length} users`);
        } catch (error) {
            console.error('Daily report generation error:', error);
        }
    }

    async generateWeeklyReports() {
        try {
            const users = await db.all('SELECT cf_handle FROM users WHERE verified = 1');
            const weekStart = new Date();
            weekStart.setDate(weekStart.getDate() - 6); // Start of current week
            
            for (const user of users) {
                try {
                    await reportService.generateWeeklyReport(user.cf_handle, weekStart);
                } catch (error) {
                    console.error(`Failed to generate weekly report for ${user.cf_handle}:`, error);
                }
            }
            
            console.log(`✓ Generated weekly reports for ${users.length} users`);
        } catch (error) {
            console.error('Weekly report generation error:', error);
        }
    }

    async generateMonthlyReports() {
        try {
            const users = await db.all('SELECT cf_handle FROM users WHERE verified = 1');
            const now = new Date();
            const lastMonth = now.getMonth() === 0 ? 12 : now.getMonth();
            const year = now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear();
            
            for (const user of users) {
                try {
                    await reportService.generateMonthlyReport(user.cf_handle, lastMonth, year);
                } catch (error) {
                    console.error(`Failed to generate monthly report for ${user.cf_handle}:`, error);
                }
            }
            
            console.log(`✓ Generated monthly reports for ${users.length} users`);
        } catch (error) {
            console.error('Monthly report generation error:', error);
        }
    }
}

export default DataSyncJobs;