/*
  # CFInsights Alpha Database Schema

  1. New Tables
    - `users` - User credentials and verification status
    - `cf_verifications` - Handle verification challenges  
    - `submissions` - Cached submission data
    - `report_cache` - Generated reports storage
    - `notes` - User problem notes
    - `bookmarks` - Saved problems
    - `weak_tags` - Weakness analysis
    - `daily_dashboard` - Daily performance cache
    - `practice_sessions` - Practice problem sets
    - `activity_log` - User activity tracking

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to access their own data
*/

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    cf_handle TEXT UNIQUE NOT NULL,
    verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    last_login TIMESTAMPTZ,
    email TEXT,
    preferences JSONB DEFAULT '{}'::jsonb
);

-- CF Handle verification table
CREATE TABLE IF NOT EXISTS cf_verifications (
    id SERIAL PRIMARY KEY,
    username TEXT NOT NULL,
    cf_handle TEXT NOT NULL,
    assigned_problem_id TEXT NOT NULL,
    assigned_problem_name TEXT NOT NULL,
    verification_code TEXT NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    completed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT fk_cf_verifications_username FOREIGN KEY (username) REFERENCES users(username)
);

-- Cached submissions table
CREATE TABLE IF NOT EXISTS submissions (
    id SERIAL PRIMARY KEY,
    cf_handle TEXT NOT NULL,
    submission_id BIGINT NOT NULL,
    problem_contest_id INTEGER,
    problem_index TEXT,
    problem_name TEXT,
    problem_rating INTEGER,
    problem_tags JSONB DEFAULT '[]'::jsonb,
    verdict TEXT,
    programming_language TEXT,
    creation_time BIGINT,
    time_consumed_millis INTEGER,
    memory_consumed_bytes BIGINT,
    cached_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT unique_submission UNIQUE(cf_handle, submission_id),
    CONSTRAINT fk_submissions_cf_handle FOREIGN KEY (cf_handle) REFERENCES users(cf_handle)
);

-- Report cache table
CREATE TABLE IF NOT EXISTS report_cache (
    id SERIAL PRIMARY KEY,
    cf_handle TEXT NOT NULL,
    report_type TEXT NOT NULL CHECK (report_type IN ('daily', 'weekly', 'monthly', 'quarterly', 'yearly')),
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    data JSONB NOT NULL,
    generated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT unique_report UNIQUE(cf_handle, report_type, period_start),
    CONSTRAINT fk_report_cache_cf_handle FOREIGN KEY (cf_handle) REFERENCES users(cf_handle)
);

-- User notes for problems
CREATE TABLE IF NOT EXISTS notes (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    problem_contest_id INTEGER NOT NULL,
    problem_index TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT unique_note UNIQUE(user_id, problem_contest_id, problem_index),
    CONSTRAINT fk_notes_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- User bookmarks for problems
CREATE TABLE IF NOT EXISTS bookmarks (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    problem_contest_id INTEGER NOT NULL,
    problem_index TEXT NOT NULL,
    problem_name TEXT,
    problem_rating INTEGER,
    problem_tags JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT unique_bookmark UNIQUE(user_id, problem_contest_id, problem_index),
    CONSTRAINT fk_bookmarks_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Weak tags analysis cache
CREATE TABLE IF NOT EXISTS weak_tags (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    tag TEXT NOT NULL,
    failure_count INTEGER NOT NULL,
    total_attempts INTEGER NOT NULL,
    accuracy REAL NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT unique_weak_tag UNIQUE(user_id, tag),
    CONSTRAINT fk_weak_tags_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Daily dashboard cache
CREATE TABLE IF NOT EXISTS daily_dashboard (
    id SERIAL PRIMARY KEY,
    cf_handle TEXT NOT NULL,
    date DATE NOT NULL,
    problems_attempted INTEGER DEFAULT 0,
    problems_solved INTEGER DEFAULT 0,
    unsolved_problems JSONB DEFAULT '[]'::jsonb,
    score REAL DEFAULT 0,
    topic_accuracy JSONB DEFAULT '{}'::jsonb,
    generated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT unique_daily_dashboard UNIQUE(cf_handle, date),
    CONSTRAINT fk_daily_dashboard_cf_handle FOREIGN KEY (cf_handle) REFERENCES users(cf_handle)
);

-- Practice sessions
CREATE TABLE IF NOT EXISTS practice_sessions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    tag TEXT NOT NULL,
    problems_assigned JSONB NOT NULL,
    problems_completed JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT fk_practice_sessions_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- User activity log
CREATE TABLE IF NOT EXISTS activity_log (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    details JSONB,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT fk_activity_log_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Indexes for better performance
CREATE INDEX IF NOT EXISTS idx_submissions_cf_handle ON submissions(cf_handle);
CREATE INDEX IF NOT EXISTS idx_submissions_creation_time ON submissions(creation_time);
CREATE INDEX IF NOT EXISTS idx_submissions_verdict ON submissions(verdict);
CREATE INDEX IF NOT EXISTS idx_submissions_problem_rating ON submissions(problem_rating);
CREATE INDEX IF NOT EXISTS idx_report_cache_handle_type ON report_cache(cf_handle, report_type);
CREATE INDEX IF NOT EXISTS idx_daily_dashboard_handle_date ON daily_dashboard(cf_handle, date);
CREATE INDEX IF NOT EXISTS idx_activity_log_user_timestamp ON activity_log(user_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_cf_verifications_handle ON cf_verifications(cf_handle);
CREATE INDEX IF NOT EXISTS idx_cf_verifications_expires ON cf_verifications(expires_at);
CREATE INDEX IF NOT EXISTS idx_notes_user_id ON notes(user_id);
CREATE INDEX IF NOT EXISTS idx_bookmarks_user_id ON bookmarks(user_id);
CREATE INDEX IF NOT EXISTS idx_weak_tags_user_id ON weak_tags(user_id);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE cf_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookmarks ENABLE ROW LEVEL SECURITY;
ALTER TABLE weak_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_dashboard ENABLE ROW LEVEL SECURITY;
ALTER TABLE practice_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;

-- RLS Policies for users table
CREATE POLICY "Users can read own profile"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid()::text = id::text);

CREATE POLICY "Users can update own profile"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = id::text);

-- RLS Policies for submissions table
CREATE POLICY "Users can read own submissions"
  ON submissions
  FOR SELECT
  TO authenticated
  USING (cf_handle IN (SELECT cf_handle FROM users WHERE auth.uid()::text = id::text));

CREATE POLICY "System can insert submissions"
  ON submissions
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for report_cache table
CREATE POLICY "Users can read own reports"
  ON report_cache
  FOR SELECT
  TO authenticated
  USING (cf_handle IN (SELECT cf_handle FROM users WHERE auth.uid()::text = id::text));

CREATE POLICY "System can manage reports"
  ON report_cache
  FOR ALL
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for notes table
CREATE POLICY "Users can manage own notes"
  ON notes
  FOR ALL
  TO authenticated
  USING (user_id IN (SELECT id FROM users WHERE auth.uid()::text = id::text))
  WITH CHECK (user_id IN (SELECT id FROM users WHERE auth.uid()::text = id::text));

-- RLS Policies for bookmarks table
CREATE POLICY "Users can manage own bookmarks"
  ON bookmarks
  FOR ALL
  TO authenticated
  USING (user_id IN (SELECT id FROM users WHERE auth.uid()::text = id::text))
  WITH CHECK (user_id IN (SELECT id FROM users WHERE auth.uid()::text = id::text));

-- RLS Policies for weak_tags table
CREATE POLICY "Users can read own weak tags"
  ON weak_tags
  FOR SELECT
  TO authenticated
  USING (user_id IN (SELECT id FROM users WHERE auth.uid()::text = id::text));

CREATE POLICY "System can manage weak tags"
  ON weak_tags
  FOR ALL
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for daily_dashboard table
CREATE POLICY "Users can read own dashboard"
  ON daily_dashboard
  FOR SELECT
  TO authenticated
  USING (cf_handle IN (SELECT cf_handle FROM users WHERE auth.uid()::text = id::text));

CREATE POLICY "System can manage dashboard"
  ON daily_dashboard
  FOR ALL
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for practice_sessions table
CREATE POLICY "Users can manage own practice sessions"
  ON practice_sessions
  FOR ALL
  TO authenticated
  USING (user_id IN (SELECT id FROM users WHERE auth.uid()::text = id::text))
  WITH CHECK (user_id IN (SELECT id FROM users WHERE auth.uid()::text = id::text));

-- RLS Policies for activity_log table
CREATE POLICY "Users can read own activity"
  ON activity_log
  FOR SELECT
  TO authenticated
  USING (user_id IN (SELECT id FROM users WHERE auth.uid()::text = id::text));

CREATE POLICY "System can log activity"
  ON activity_log
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for cf_verifications table (public access for registration)
CREATE POLICY "Public can manage verifications"
  ON cf_verifications
  FOR ALL
  TO anon, authenticated
  WITH CHECK (true);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for notes table
CREATE TRIGGER update_notes_updated_at
    BEFORE UPDATE ON notes
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Create function to clean up expired verifications
CREATE OR REPLACE FUNCTION cleanup_expired_verifications()
RETURNS void AS $$
BEGIN
    DELETE FROM cf_verifications 
    WHERE expires_at < NOW() AND completed = false;
END;
$$ language 'plpgsql';